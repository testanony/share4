"""Solving the DnnSAT CSP by Z3
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
import json
import time
from z3 import *
from multiprocessing.pool import ThreadPool
from dnnsat.gen_solver_constraint import *
from dnnsat.gen_solver_variable import *
from logger import logger
from dnnsat.statistics import statistics_networks
from dnnsat.statistics import statistics_search_spaces
from dnnsat.param import *
from dnnsat.unsat_core import *
from init_var_sym import *
from dnnsat.type.tensor import NetSpec
from dnnsat.layers.Operators import * 


class LayerSpec:
    def __init__(self, name, layer_dict):
        self.name = name
        self.layertype = layer_dict["type"]
        self.layer_op  = self.layertype
        if "tensor" in layer_dict:
            self.inputs = layer_dict["tensor"]
        for k,v in layer_dict.items():
            setattr(self, k, v)
            
    def __str__(self):
        ret = "name: {}".format(self.name)
        attrs = vars(self)
        attr_str = ', '.join("%s: %s" % item for item in attrs.items())
        return ret + attr_str
    
class ConstraintLayer:
    def __init__(self, name):
        self.name                 = name
        self.symbol_table         = dict()
        self.symbol_range_value   = dict()
        self.symbol_choice_value  = dict()
        self.symbol_default_value = dict()
        
    def __str__(self):
        pass
    
    def initialize(self, layer_spec, layer_search_space):
        pass
    
def read_search_space_file(path="nets/vgg16.json"):
    """
    Read search space and construct json dic
    
    Keyword Arguments:
        path {str} -- [path] (default: {"nets/search_space.json"})
    
    Returns:
        [type] -- [search space dic]
    """
    print(path)
    with open(path, "r") as f:
        search_space = json.load(f)
        assert search_space is not None
        return search_space


def reformat_search_space(search_space):
    """ 
    reformat the search space 
    
    Args:
        search_space : search space file
    """
    # "constraint": {"mem": {"size": 1024000000, "op": "lt"}}
    if len(search_space) == 0:
        return search_space
    constraints = search_space["constraints"]
    cons_json = {}
    cons_json["constraint"] = {}
    for constraint in constraints:
        constraint_type = constraint["constraint"]
        cons_json["constraint"][constraint_type] = {}
        if "max" in constraint:
            cons_json["constraint"][constraint_type]["op"] = "lt"
            cons_json["constraint"][constraint_type]["size"] = constraint[
                "max"]
        if "min" in constraint:
            cons_json["constraint"][constraint_type]["op"] = "gt"
            cons_json["constraint"][constraint_type]["size"] = constraint[
                "min"]
    search_space["constraint"] = cons_json["constraint"]
    return search_space


def check(layer_list, device_spec, search_space):
    """
    interactive mode

    Args:
        layer_list : 
        device_spec : 
        search_space_path : 
    """

    if reformat_search_space:
        search_space = reformat_search_space(search_space)

    mainctx = main_ctx()
    return build_and_solve(device_spec,
                           mainctx,
                           ".",
                           search_space,
                           layer_list,
                           0,
                           mode="interactive")


def constraint_solving(output_folder, layer_list, device_spec,
                       search_space_path, for_rnn = False):
    """ 
    DnnSAT solving generated z3 CSP

    Arguments:
        output_folder  -- results generated folder
        layer_list -- layer specification list

    Keyword Arguments:
        search_space_path -- search space file path
    """
    all_start_time = time.time()
    if search_space_path is None:
        search_space = dict()
    else:
        search_space = read_search_space_file(path=search_space_path)
    if reformat_search_space:
        search_space = reformat_search_space(search_space)

    ss_path = "{}/dnnsat_global_statistic.txt".format(output_folder)
    with open(ss_path, "w") as \
            ss_outputfile:
        statistics_networks(layer_list, ss_outputfile)
        statistics_search_spaces(search_space, ss_outputfile)

        logger.debug("search space: {}\n path: {}\n".format(
            search_space, search_space_path))
        search_space_list, splitted_interval_list, splitted_interval_info,\
            split_meta = parallel_search_space_analysis(search_space, degree=1)

        if len(search_space_list) > 0:
            thread_num = len(search_space_list)
        else:
            thread_num = 1

        if use_parallel:
            pool = ThreadPool(thread_num)
            logger.debug("search_space_list {}\n".format(search_space_list))
            set_param('parallel.enable', True)

        mainctx = main_ctx()

        for i in range(thread_num):
            # search_space = {}
            if len(search_space_list) > 0:
                search_space = search_space_list[i]

            if not use_parallel:
                # (1) sequential solving
                i_context = mainctx
                if for_rnn:
                    build_and_solve_for_rnn(device_spec, 
                                            i_context,
                                            output_folder,
                                            search_space,
                                            layer_list,
                                            i,
                                            mode="prune")
                else:
                    build_and_solve(device_spec,
                                i_context,
                                output_folder,
                                search_space,
                                layer_list,
                                i,
                                mode="prune")
            else:
                i_context = Context()
                # (2) multi-thread parallel solving
                pool.apply_async(build_and_solve, [
                    i_context, output_folder, search_space,
                    copy.deepcopy(layer_list), i, "prune"
                ])

        if use_parallel:
            pool.close()
            pool.join()
        all_end_time = time.time()
        logger.debug("E2E solving seconds {}".format(all_end_time -
                                                     all_start_time))
        statistic_for_all(output_folder, ss_outputfile, ss_path, thread_num)

    return


def statistic_for_all(root_path, ss_outputfile, ss_path, degree):
    """
    statistic csp solving results

    Args:
        root_path : 
        ss_outputfile : search space output file
        ss_path : search space path
        degree : parallel degree
    """
    solutions_count = 0

    def file_name(file_dir):
        L = []
        for root, dirs, files in os.walk(file_dir):
            for file in files:
                if "sub_search_space" in str(file):
                    L.append(os.path.join(root, file))
        return L

    files = file_name(root_path)

    for path in files:
        if os.path.exists(path):
            with open(path, 'r') as f:
                text_list = f.readlines()
                for l in text_list:
                    if "solutions count" in l:
                        words = l.split(" ")
                        solutions_count += int(words[len(words) - 1])
                        logger.debug(
                            "SAT solutions count {}".format(solutions_count))

    ss_count = 1
    ss_outputfile.flush()

    with open(ss_path, 'r') as f:
        text_list = f.readlines()
        logger.debug("analysis search space {} \n {}".format(
            ss_path, text_list))
        for l in text_list:
            if "search space size" in l:
                words = l.split(" ")
                ss_count = int(words[len(words) - 1])
                logger.debug("search space size {}".format(ss_count))

    ss_outputfile.write(
        "search space pruning rate {}\n".format(1 -
                                                solutions_count / ss_count))
    ss_outputfile.write("SAT solutions count {}\n".format(solutions_count))
    ss_outputfile.write("search space size {}\n".format(ss_count))

def build_and_solve_for_rnn(device_spec,
                    ctx,
                    output_folder,
                    search_space,
                    layer_list,
                    degree,
                    mode="prune"):

    layer_id = -1
    sym_layer_list = []
    sym_name_dic   = {}
    opt = get_solver_opt(ctx=ctx)
    opt.push()
    net_arch = NetSpec(len(layer_list))
    enc_seq_len = 0
    dec_seq_len = 0
    batch_size = 0
    for layer_spec in layer_list:
        layer_spec = LayerSpec(layer_spec, layer_list[layer_spec])
        print(layer_spec)
        layer_id += 1
        layer_type = layer_spec.layertype.lower()
        layer_name = layer_spec.name
        net_arch.add(layer_id, layer_name, 4)
        if layer_name == "src_input":
            enc_seq_len  = layer_spec.inputs[0]
            batch_size    = layer_spec.inputs[1]
        elif layer_name == "trg_input":
            dec_seq_len  = layer_spec.inputs[0]
        logger.debug("{}: layer op {} ".format(layer_id, layer_name))
        sym_op = construct_solver_variable_rnn(op_name=layer_name,
                                               op_type = layer_type,
                                               op_spec = layer_spec,
                                               opt = opt,
                                               ctx = ctx,
                                               layer_id=layer_id)
        sym_name_dic[layer_name] = sym_op
        sym_layer_list.append(sym_op)
        if layer_type == "input":
            try:
                gen_input_op_constraint(op_symbol_dic=sym_op,
                                        layer_spec=layer_spec,
                                        search_space=search_space,
                                        opt=opt,
                                        ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))
        else:
            try:
                if layer_name == "encoder":
                    gen_rnn_op_constraint(op_symbol_dic=sym_op,
                                          seq_len=enc_seq_len,
                                          batch_size=batch_size,
                                          layer_spec=layer_spec,
                                          search_space=search_space,
                                          opt=opt,
                                          ctx=ctx)
                else:
                    gen_rnn_op_constraint(op_symbol_dic=sym_op,
                                          seq_len=dec_seq_len,
                                          batch_size=batch_size,
                                          layer_spec=layer_spec,
                                          search_space=search_space,
                                          opt=opt,
                                          ctx=ctx)
                    
            except Exception as e:
                raise AssertionError("{}".format(e))
    if use_shape_rule:
        opt.add(sym_name_dic["encoder"]["n_layers"] == sym_name_dic["encoder"]["n_layers"])
        opt.add(sym_name_dic["encoder"]["hidden_dim"] == sym_name_dic["encoder"]["hidden_dim"])
    
    if use_resource_constraint:
        construct_resource_constraint(search_space, 
                                    opt, 
                                    ctx, 
                                    layer_list, 
                                    sym_layer_list, 
                                    sym_name_dic)

    # solving
    init_solver_variable("memory_symbol", ctx)
    if mode == "prune":
        search_space_var_dic = init_search_space_var_dic(search_space)
        print(search_space)
        # interval_filtering = False
        if interval_filtering_flag and "data" in search_space["layers"] and \
            "tensor" in search_space["layers"]["data"] and \
                "randint" in search_space["layers"]["data"]["tensor"]["_type"]:
            interval_filtering(search_space, opt, ctx, output_folder, degree,
                               search_space_var_dic)
        if tiny_search_space:
            tiny_search_space(search_space, opt, ctx, output_folder, degree,
                              search_space_var_dic, net_arch)
        else:
            allsat_solving(opt, ctx, output_folder, degree,
                           search_space_var_dic, net_arch)
    elif mode == "interactive":  # interactive mode
        start = time.time()
        result = opt.check()
        end = time.time()
        print("interactive 1 solution check time {}".format(end - start))
        return result
    opt.pop()


def recursive_solve(layer_list, layer_id, operators_list, net_arch, \
                    search_space, sym_layer_list, sym_name_dic, output_folder, \
                    layer_rank_dic, rank_layer_dic, error_op_dic, opt, ctx):
    s_count = 0
    if layer_id == len(layer_list):
        logger.debug("layer_id {} == len(layer_list) {}".format(layer_id, layer_list))
        return s_count
    else:
        layer_spec = layer_list[layer_id]
        layer = layer_spec.layer_op
        layer_type = layer.layertype
        layer_name = layer.name
        logger.debug("sym_name_dic {} layer_name {}, layer id {}" \
                     .format(sym_name_dic, layer_name, layer_id))

        if refty_diagnosis_multi_error:
            # if parents error, for multi error, parent error, child is also as error 
            for parent in layer.parents:
                if parent in error_op_dic:
                    error_op_dic[layer_name] = True
                    # parent contains error, skip this child 
                    return s_count

        # construct operator         
        operator = OperatorFactory.construct_operator(op_type = layer_type, \
                                                      op_spec = layer_spec, \
                                                      opt = opt, \
                                                      ctx = ctx, \
                                                      layer_id = layer_id, \
                                                      search_space = search_space)
        
        sym_op = operator.init_symbols()
        operator.push_constraints(solver = opt)

        net_arch.add(layer_id, layer_type, 4)
        sym_layer_list.append(sym_op)
        sym_name_dic[layer_name] = sym_op
        operators_list.append(operator)

        if len(layer.parents) > 0:
            parents = gen_op_parents_symbol(sym_name_dic=sym_name_dic, \
                                            layer=layer, \
                                            search_space=search_space)
            logger.debug("layer.name {} parents {} ".format(layer.name, parents))
            parents_count_array = gen_1to1_child_input_parent_output_shape_constraint(\
                                  sym_op, \
                                  parents, \
                                  opt, \
                                  ctx)
            sym_op["edge_counts"] = parents_count_array 
            
        if use_refty_diagnosis_mode:
            logger.debug("recursive_solve at operator {}".format(layer_name))
            logger.debug("current layer graph = {}".format(operators_list))
            # clean this layer's attached solutions clause after solving then
            # search next operators
            msg_show_in_log = "recursive_solve at operator {}\n" \
                              .format(layer_name)
            operator.push_constraints(solver = opt)
            solutions_count = operator.solve(output_folder = output_folder, \
                                             net_arch = net_arch, \
                                             allsat_callback = allsat_solving, \
                                             log_mode = "a", \
                                             msg_show_in_log = msg_show_in_log)
            s_count += solutions_count
            operator.pop_constraints()

            if solutions_count == 0:
                if not refty_diagnosis_multi_error:
                    # currently: simple diagnosis, exit when touch the first error
                    return s_count
                else:
                    error_op_dic[layer_name] = True
                    operator.pop_constraints() # clean this operator, not affect same rank other operators
                    
                    if layer_id + 1 < len(layer_list):
                        next_layer_name = layer_list[layer_id + 1].layer_op.name
                        if layer_rank_dic[layer_name] != layer_rank_dic[next_layer_name]:
                            return s_count # this layer is the same rank last operator, not check child

        elif layer_id == len(layer_list) - 1:
            solutions_count = operator.solve(output_folder = output_folder, \
                                net_arch = net_arch, \
                                allsat_callback = allsat_solving)
            s_count += solutions_count

        solutions_count = recursive_solve(layer_list, layer_id + 1, operators_list, net_arch, \
                        search_space, sym_layer_list, sym_name_dic, \
                        output_folder, layer_rank_dic = layer_rank_dic, \
                        rank_layer_dic = rank_layer_dic, \
                        error_op_dic = error_op_dic, opt = opt, ctx = ctx)
        s_count += solutions_count
        return s_count 


def parallel_rank_analysis(layer_list):
    layer_rank_dic = {}
    rank_layer_dic = {}
    layer_name_spec_dic = {}
    for layer_spec in layer_list:
        layer = layer_spec.layer_op
        name = layer.name
        layer_name_spec_dic[name] = layer_spec

    for layer_spec in layer_list:
        layer = layer_spec.layer_op
        parents = layer.parents
        
        if len(parents) == 0:
            rank = 0
        else:
            max = 0
            for parent in parents:
                p_rank = layer_rank_dic[parent]
                if p_rank > max:
                    max = p_rank
            rank = max + 1
        layer_rank_dic[layer.name] = rank

        if rank in rank_layer_dic:
            rank_layer_dic[rank].append(layer_spec)
        else:
            rank_layer_dic[rank] = [layer_spec]

    logger.debug("layer rank dic {}, {}".format(layer_rank_dic, rank_layer_dic))
    return layer_rank_dic, layer_name_spec_dic, rank_layer_dic


def refty_op_topo_solving(device_spec,
                          ctx,
                          output_folder,
                          search_space,
                          layer_list,
                          degree,
                          mode="prune"):
    """
    Single thread solving CSP

    Arguments:
        ctx -- Z3 context
        output_folder -- results generated folder
        search_space -- search spaces
        layer_list -- layer specification list
        degree -- parallel thread index

    Raises:
        AssertionError: 
    """
    layer_rank_dic, layer_name_spec_dic, rank_layer_dic = parallel_rank_analysis(layer_list)
    logger.debug("refty solve layer_list {}, thread {}".format(layer_list, degree))
    return recursive_solve(layer_list = layer_list, layer_id = 0, operators_list = [], \
                    net_arch = NetSpec(len(layer_list)), \
                    search_space = search_space, sym_layer_list = [], \
                    sym_name_dic = {}, output_folder = output_folder, \
                    layer_rank_dic = layer_rank_dic, rank_layer_dic = rank_layer_dic, \
                    error_op_dic = {}, opt = get_solver_opt(ctx=ctx), ctx = ctx)


def build_and_solve(device_spec,
                    ctx,
                    output_folder,
                    search_space,
                    layer_list,
                    degree,
                    mode="prune"):
    """
    Single thread solving CSP

    Arguments:
        ctx -- Z3 context
        output_folder -- results generated folder
        search_space -- search spaces
        layer_list -- layer specification list
        degree -- parallel thread index

    Raises:
        AssertionError: 
    """
    if use_refty_op_topo_solving:
        print("in refty_op_topo_solving: ", use_refty_op_topo_solving)
        return refty_op_topo_solving(device_spec,
                              ctx,
                              output_folder,
                              search_space,
                              layer_list,
                              degree,
                              mode=mode)
        
    sym_layer_list = []
    sym_name_dic = {}
    # assert ctx != main_ctx()
    opt = get_solver_opt(ctx=ctx)
    opt.push()
    logger.debug("layer_list {}, thread {}".format(layer_list, degree))
    start = time.time()
    # construct solver equation
    layer_id = -1
    layer_stop = len(layer_list)
    print("layer stop: ", layer_stop)
    print("layer list: ",layer_list)
    #layer_stop = 126
    #layer_stop = 17
    net_arch = NetSpec(layer_stop)
    for layer_spec in layer_list:
        layer_id += 1
        if layer_stop == layer_id:
            break
        layer = layer_spec.layer_op
        layer_type = layer.layertype
        layer_name = layer.name
        print("{}:layer op {} inputs {}".format(layer_id, layer, layer.inputs))
        # initialize variables and shape inference
        op_var_start = time.time()
        print("current layer: {}:{}".format(layer_id, layer_type))
        # sym_op = construct_solver_variable(op_name=layer_type,
        #                                    op_type=layer_type,
        #                                    op_spec=layer,
        #                                    opt=opt,
        #                                    ctx=ctx,
        #                                    layer_id=layer_id)

        sym_op = construct_solver_variable(op_name=layer_name,
                                           op_type=layer_type,
                                           op_spec=layer,
                                           opt=opt,
                                           ctx=ctx,
                                           layer_id=layer_id)
        net_arch.add(layer_id, layer_type, 4) 

        sym_name_dic[layer_name] = sym_op
        sym_layer_list.append(sym_op)
        op_var_end = time.time()
        # print("op var init {} time, {}".format(op_var_end - op_var_start, layer.name))
        op_constraint_start = time.time()
        # add operator level constraints
        if layer_type == "input":
            try:
                gen_input_op_constraint(op_symbol_dic=sym_op,
                                        layer_spec=layer,
                                        search_space=search_space,
                                        opt=opt,
                                        ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))
        if layer_type in ["softmax", "innerproduct", "generic_Accuracy"]:
            try:
                gen_softmax_op_constraint(op_symbol_dic=sym_op,
                                          layer_spec=layer_spec,
                                          search_space=search_space,
                                          opt=opt,
                                          ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))
        if layer_type == "dropout":
            try:
                gen_dropout_op_constraint(op_symbol_dic=sym_op,
                                          layer_spec=layer_spec,
                                          search_space=search_space,
                                          opt=opt,
                                          ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))
        if layer_type in ["batchnorm2d", "generic_BatchNorm"]:
            try:
                gen_batchnorm_op_constraint(op_symbol_dic=sym_op,
                                            layer_spec=layer_spec,
                                            search_space=search_space,
                                            opt=opt,
                                            ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))
        if layer_type == "elementwise":
            try:
                gen_elementwise_op_constraint(op_symbol_dic=sym_op,
                                              layer_spec=layer_spec,
                                              search_space=search_space,
                                              opt=opt,
                                              ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))
        if layer_type == "reshape":
            #print("layer spec hhhh: ", layer_spec.layer_op.outputs)
            gen_reshape_constraint(sym_op, layer_spec, search_space, opt, ctx)
        if layer_type == "conv2d":
            try:
               gen_conv2d_op_constraint(op_symbol_dic=sym_op,
                                        layer_spec=layer_spec,
                                        search_space=search_space,
                                        opt=opt,
                                        ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))
        if "pool" in layer_type and layer_name != "InceptionV3/Logits/AvgPool_1a_8x8/AvgPool":
            try:
                gen_pool2d_op_constraint(op_symbol_dic=sym_op,
                                         layer_spec=layer_spec,
                                         search_space=search_space,
                                         opt=opt,
                                         ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))

        if layer_type in ir_op_set.rnn:
            try:
                gen_rnn_op_constraint(op_symbol_dic=sym_op,
                                      layer_spec=layer_spec,
                                      search_space=search_space,
                                      opt=opt,
                                      ctx=ctx)
            except Exception as e:
                raise AssertionError("{}".format(e))

        # construct input output constraint
        logger.debug(
            "layer_list {} layer {} and layer.parents {}, len(layer.parents)".
            format(layer_list, layer, layer.parents, len(layer.parents)))

        # add operator input with parents outputs value constraints
        if len(layer.parents) > 0:
            use_edge_constraint = False
            if use_edge_constraint:
                sym_op = gen_op_edge_constraints(op_symbol_dic=sym_op,
                                                 layer_spec=layer_spec,
                                                 search_space=search_space,
                                                 opt=opt,
                                                 ctx=ctx)
                # bug for edge constraint
            sym_name_dic[layer_name] = sym_op
            parents = gen_op_parents_symbol(sym_name_dic=sym_name_dic,
                                            layer=layer,
                                            search_space=search_space)

            logger.debug("layer.name {} parents {} ".format(
                layer.name, parents))
            parents_count_array = \
                gen_1to1_child_input_parent_output_shape_constraint(sym_op,
                                                                    parents,
                                                                    opt,
                                                                    ctx)
            sym_op["edge_counts"] = parents_count_array

        op_constraint_end = time.time()
        # print("op var constraint init time {}, {}".format(op_constraint_end - op_constraint_start, layer.name))

    end = time.time()
    # print("var init time {}".format(end - start))
    if use_resource_constraint:
        construct_resource_constraint(search_space, \
                                    opt, \
                                    ctx, \
                                    layer_list, \
                                    sym_layer_list, \
                                    sym_name_dic)

    # solving
    init_solver_variable("memory_symbol", ctx)

    if mode == "prune":
        search_space_var_dic = init_search_space_var_dic(search_space)
        #print(search_space)
        # interval_filtering = False
        if len(search_space) == 0:
            allsat_solving(opt, ctx, output_folder, degree,
                           search_space_var_dic, net_arch)
            return
        logger.debug("interval_filtering {}".format(interval_filtering))
        if interval_filtering_flag and "data" in search_space["layers"] and \
            "tensor" in search_space["layers"]["data"] and \
                "randint" in search_space["layers"]["data"]["tensor"]["_type"]:
            interval_filtering(search_space, opt, ctx, output_folder, degree,
                               search_space_var_dic)
        if tiny_search_space:
            tiny_search_space(search_space, opt, ctx, output_folder, degree,
                              search_space_var_dic, net_arch)
        else:
            allsat_solving(opt, ctx, output_folder, degree,
                           search_space_var_dic, net_arch)
    elif mode == "interactive":  # interactive mode
        start = time.time()
        result = opt.check()
        end = time.time()
        print("interactive 1 solution check time {}".format(end - start))
        return result
    opt.pop()


def interval_filtering(search_space, opt, ctx, output_folder, degree,
                       search_space_var_dic):
    """
    Speedup solving with interval contraction

    Arguments:
        opt -- z3 solver/ optimizer
        ctx -- z3 context
        output_folder -- results output folder
        degree -- parallel degree
        search_space_var_dic -- search space variable dic
    """
    logger.debug("enter interval_filtering")
    init_solver_variable('{}_{}_{}'.format("data", "input", "0"), ctx)
    batch_splitting_list = parse_monotonic_params(search_space)

    for i in range(len(batch_splitting_list)):
        opt.push()
        hyperparam_min = int(batch_splitting_list[i][0])
        hyperparam_max = int(batch_splitting_list[i][1])
        logger.debug("left boundary {} right boundary {}".format(
            hyperparam_min, hyperparam_max))
        pruned_flag, sat_flag = interval_filtering_for_hyper_param(
            opt, symbol_val, hyperparam_min, hyperparam_max)

        if pruned_flag:
            logger.debug("interval_filtering_pruned left boundary {} \
                right boundary {}".format(hyperparam_min, hyperparam_max))
            continue
        else:
            opt.add(symbol_val >= hyperparam_min)
            opt.add(symbol_val <= hyperparam_max)
            logger.debug("add constraint: {} <= {} {} >= {}".format(
                symbol_val, hyperparam_max, symbol_val, hyperparam_min))

            count = allsat_solving(opt, ctx, output_folder, degree,
                                   search_space_var_dic)
            opt.pop()


def print_model(opt):
    m = opt.model()
    for i in m:
        logger.debug("{} = {}\n".format(i, m[i]))


def interval_filtering_for_hyper_param(opt, hyperparam, hyperparam_min,
                                       hyperparam_max):
    """
    check unsat bounds

    Args:
        opt :
        hyperparam : 
        hyperparam_min :
    """
    opt.push()
    opt.add(hyperparam == hyperparam_min)
    sat_flag1 = opt.check()

    if sat_flag1 == sat:
        m = opt.model()
    opt.pop()
    opt.push()
    opt.add(hyperparam == hyperparam_max)

    sat_flag2 = opt.check()
    if sat_flag2 == sat:
        m = opt.model()
    opt.pop()
    logger.debug("sat flag 1 {} sat flag 2 {}".format(sat_flag1, sat_flag2))

    # pruning the unsat interval
    if sat_flag1 == unsat and sat_flag2 == unsat:
        logger.debug("all unsat start >= {}  end <= {}".format(
            hyperparam_min, hyperparam_max))
        return True, unsat
    else:
        logger.debug("not all unsat, sat_flag1 {} sat_flag2 {}".format(
            sat_flag1, sat_flag2))
        return False, None


def tiny_search_space(search_space, opt, ctx, output_folder, degree,
                      search_space_var_dic, net_arch):
    """
    Speedup solving with constraint periodic cleaning

    Arguments:
        opt -- z3 solver/ optimizer
        ctx -- z3 context
        output_folder -- results output folder
        degree -- parallel degree
        search_space_var_dic -- search space variable dic

    """
    # perodic clean constraint optimization policies
    search_space_list, splitted_interval_list, max_param, split_meta = \
        parallel_search_space_analysis(search_space, \
            degree=constraint_split_degree)

    if len(search_space_list) > 1 and (max_param is not None
                                       and split_meta["parallel_degree"] > 1):
        start = splitted_interval_list[0]
        end = splitted_interval_list[1]
        interval = end - start
        logger.debug("end {}, start {}, split_meta {}".format(
            end, start, split_meta))
        offset = split_meta["offset"]
        temp_split = start + offset

        symbol_val = init_solver_variables(
            '{}_{}_{}'.format(max_param["layer_name"], max_param["hyperparam"],
                              max_param["randint_max_degree_index"]), ctx)
        logger.debug(
            "len(splitted_interval_list) {}, splitted_interval_list {}".format(
                len(splitted_interval_list), splitted_interval_list))
        for i in range(len(search_space_list)):
            with open(
                    "{}/solving_speed_{}_{}.txt".format(
                        output_folder, degree, i), "w") as speed_output:
                speed_output.write(
                    "index,time,total_time,per_throughput,throughput\n")
                opt.push()
                opt.add(symbol_val >= temp_split - offset)
                logger.debug("add constraint {} >= {}".format(
                    symbol_val, temp_split - offset))

                if i == len(search_space_list) - 1:
                    temp_split = end
                    logger.debug("temp_split {}".format(temp_split))

                opt.add(symbol_val <= temp_split)
                logger.debug("add constraint {} <= {}".format(
                    symbol_val, temp_split))
                allsat_solving(opt,
                               ctx,
                               output_folder,
                               "{}_{}".format(degree, i),
                               search_space_var_dic,
                               speed_output=speed_output)
                opt.pop()
                temp_split += offset + 1
    else:
        allsat_solving(opt, ctx, output_folder, degree, search_space_var_dic,net_arch=net_arch)


def allsat_solving(opt,
                   ctx,
                   output_folder,
                   degree,
                   search_space_var_dic,
                   net_arch,
                   speed_output=None,
                   log_mode = "w",
                   msg_show_in_log = ""):
    """
    Solving the ALLSAT problem

    Arguments:
        opt -- z3 solver/ optimizer
        ctx -- z3 context
        output_folder -- results output folder
        degree -- parallel degree
        search_space_var_dic -- search space variable dic
    """
    count = 0
    logger.debug("thread {} start solving {} ".format(degree,  output_folder))

    with open(
            "{}/sub_search_space_{}_solutions.txt".format(
                output_folder, degree), log_mode) as z3_output:
        with open(
            "{}/sub_search_space_{}_statistics.txt".format(
                output_folder, degree), log_mode) as z3_statitics_output:

            write_statistic(z3_statitics_output, opt)
            start = time.time()
            temp_start = time.time()
            sat_flag = opt.check()
            end = time.time()

            while sat_flag == sat:
                m = opt.model()
                count += 1
                z3_output.write("\n [test z3 solving] *** return the {} model *** \
                        throughputs {} solutions / seconds {} seonds used\n ".
                                format(count, count / (end - start), end - start))
                if speed_output is None:
                    speed_output = open(
                        "{}/solving_speed_of_sub_searh_space_{}.txt".format(
                            output_folder, degree), log_mode)
                    speed_output.write(
                        "index,time,total_time,per_throughput,throughput\n")

                speed_output.write("{},{},{},{},{}\n".format(
                    count, end - temp_start, end - start, 1 / (end - temp_start),
                    count / (end - start)))
                layer_arch = dict()
                max_cnt = 0
                z3_output.write("model: len {}\n".format(len(m)))
                #print("model: ", m)
                # net_arch is limited by the fixed max len of graph, just comment
                # if needed, should make it flexible to support diagnosis mode

                if not use_refty_op_topo_solving:
                    # solution = net_arch.to_solution(m)
                    # z3_output.write(solution)
                    pass


                solutions_list = []
                
                for op in m:
                    if op.name() != "div0" and op.name() != "mod0":
                        solutions_list.append(op)
                
                def get_layer_id(name):
                    #print("get layer id: ", name)
                    items = str(name).split(':')
                    return int(items[0]), items[3], items[4]

                solutions_list.sort(key=get_layer_id)
            
                for mi in solutions_list:
                    z3_output.write("{}={}\n".format(mi,m[mi])) 
                
                #print("decls: ", m.decls())
                cons_lst = []
                for sym in m.decls():
                    if sym.name() != "div0" and sym.name() != "mod0":
                        cons_lst.append(sym() == m[sym])   
                opt.add(Not(And(cons_lst, ctx)))

                temp_start = time.time()
                sat_flag = opt.check()
                end = time.time()

        end = time.time()
        print_unsat_core(z3_output, opt)
        z3_output.write("this thread total solved time {} \
            seconds, solutions count {}\n".format(end - start, count))
        z3_output.write(msg_show_in_log)
    compare_file = "{}/cmp.json".format(output_folder)
    cmp_dict = {
            "real_count": 0,
            "check_count": 0,
        }
    try:
        with open(compare_file, 'w') as f:
            cmp_dict["check_count"] = count
            json.dump(cmp_dict, f)
    except Exception as e:
        print("{} doesn't exist".format(compare_file))
    return count


def periodic_removal_of_constraints(opt, ctx, output_folder,
                                    search_space_var_dic):
    """
    summary
    # TODO:
    # push pop constraint range after solving. then begin new ranges
    # to keep the solving throughputs stable and not slow down too significant
    """
    degree = num_parallel_degree
    count = 0
    with open("{}/z3_solving_results_{}.txt".format(output_folder, degree),
              "w") as z3_output:
        write_statistic(z3_output, opt)

        start = time.time()
        for i in search_spaces_ranges:
            opt.push()
            opt.add(i.left)
            opt.add(i.right)
            while opt.check() == sat:
                m = opt.model()
                end = time.time()
                count += 1
                z3_output.write(
                    "\n [test z3 solving] *** return the {} model *** \
                        throughputs {} solutions / seconds {} seonds used\n ".
                    format(count, 1 / (end - start), end - start))
                m = opt.model()
                clause = []
                for sym in m.decls():
                    if check_SAT_search_space_constraints(
                            sym, search_space_var_dic):
                        clause.append(sym() == m[sym])

                logger.debug("add constraints {}".format(clause))
                assert len(clause) > 0
                opt.add(simplify(Not(And(clause, ctx))))
            opt.pop()
            opt.add(And(Not(i.left), Not(i.right)))
    return


def init_search_space_var_dic(search_space):
    """
    Here need take care and contains risk to miss some hyperparameters
    Arguments:
        search_space -- 
    """
    search_space_var_dic = {}

    if "layers" in search_space:
        for layer_name in search_space["layers"]:
            search_space_var_dic.update({"{}".format(layer_name): 1})

    return search_space_var_dic


def check_SAT_search_space_constraints(sym, search_space_var_dic):
    """
    Speedup Optimization: If here only add search space constraints 
    will clear the constraints clause and speedup to avoid the constraint 
    contains all the clauses

    Arguments:
        sym -- description
        search_space_var_dic -- description
    """
    if str(sym).split("_")[0] in search_space_var_dic:
        return True
    else:
        False


def print_unsat_core(f, opt):
    c = opt.unsat_core()
    f.write("UNSAT core: \n".format())
    for i in c:
        f.write("{} \n".format(i))


def print_statistic(opt):
    logger.debug('+---------------------------------------------------------+')
    logger.debug("show Z3 SMT solver constriaints:\n")
    logger.debug('+---------------------------------------------------------+')
    logger.debug("return all added constraints: \n{}\n".format(opt.__repr__()))
    logger.debug('+---------------------------------------------------------+')
    logger.debug("return all added rules and constraints: \n{}\n".format(
        opt.sexpr()))
    logger.debug('+---------------------------------------------------------+')
    logger.debug("return statistic of last check: \n{}\n".format(
        opt.statistics()))
    logger.debug('+---------------------------------------------------------+')


def write_statistic(f, opt):
    f.write("debugging solver constriaints:\n")
    count = 0
    as_count = 0
    # m = opt.__repr__().split(" ")
    m = opt.sexpr().split(" ")

    for i in m:
        if "declare-fun" in str(i):
            count += 1
        elif "assert" in str(i):
            as_count += 1

    f.write(
        "\nstatistics: \n symbols count {} \n constraint count {} \n".format(
            count, as_count))
    f.write("\nreturn statistic of last check: \n{}".format(opt.statistics()))
    f.write("\nreturn all added symbols: \n{}".format(opt.__repr__()))
    f.write("\nreturn all added rules and constraints (asserts): \n {}".format(
        opt.sexpr()))
