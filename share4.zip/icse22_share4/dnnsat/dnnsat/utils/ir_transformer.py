"""MMdnn IR file to DnnSAT IR convertor"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import json
import click

import os
import sys
import inspect
currentdir = os.path.dirname(
    os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)


class MMdnnIROperatorSet():
    """[Define the supported IR operator set.]
    """
    def __init__(self):
        """[Init the IR operator set]
        """

        # classification of the layer types.
        # Sum = 70 OP supported for memory estimation.
        # (1) in place op
        self.in_place_op = ["Relu", "Tanh", "Erf", "Div", "Acos", "Acosh", \
                "Asin", "Asinh", "Atan", "Atanh", "Cos", "Cosh", "Elu", "Exp", \
                "Sign", "Relu", "Selu", "Sigmoid", "Sign", "Sin", "Sinh", \
                "Sqrt", "PRelu", "Round" "Tan", "Tanh", "Softplus", "Softsign",\
                "Softmax"] #+ ir_op_set.activation # count = 28
        # (2) join op
        self.op_elimentwise_join = ["Add", "MatMul", "Sub", "Div", "Or", \
            "And", "Sub", "Mul"] #+ ir_op_set.elementwise # count = 8
        # To
        self.op_join = ["Concat", "Concatenate"]  # count = 1
        # (3) shape transpose op
        # these type of opschange the shape of tensor
        self.op_shape_transpose_fix = ["Reshape", "Transpose", "Flatten", \
            "Dropout"] #  count = 13
        self.op_shape_transpose_pool = ["Pool", "AveragePool", \
            "GlobalAveragePool", "GlobalLpPool", "GlobalMaxPool", "LpPool", \
            "MaxPool", "MaxRoiPool", "MaxUnpool"] # count = 9
        self.op_shape_transpose_reduce = []
        # self.op_shape_transpose_reduce = ["ReduceMean", "Crop", "Slice", \
        #     "Cast", "Unsqueeze", "Squeeze"] #  count = 6
        # (4) weight op
        self.op_gemm_weight = ["Conv", "FullyConnected", "Embedding", \
            "BatchNorm"]
        # count = 4. note: these op assumption use cuDNN op
        # To do: op_gemm_weight: "ConvTranspose", "RNN", "LSTM",
        # "GRU"
        # (5) constant op
        self.op_constant = ["DataInput", "Constant"]  # count = 2
        # (6) controlflow op
        self.op_controlflow = ["Loop", "If"]  # count = 2 simulate some tiny op
        # (7) debugging op
        self.op_misc = ["Assert", "Ignore", "Weight"]  # count = 3

    def summary_op(self):
        """[Statistics IR set]
        """
        sum_count = len(self.op_elimentwise_join) + \
            len(self.op_shape_transpose_fix) + \
            len(self.op_shape_transpose_reduce) + \
            len(self.op_join) + len(self.op_gemm_weight) + \
            len(self.op_constant) + len(self.op_controlflow) + \
            len(self.op_misc)
        print("op sum counts{}".format(sum_count))
        print("op op_elimentwise_map sum counts{}".format(len(\
            self.op_elimentwise_join)))
        print("op op_shape_transpose sum counts{}".format(len(\
            self.op_shape_transpose_fix) \
            + len(self.op_shape_transpose_reduce)))
        print("op op_join sum counts{}".format(len(self.op_join)))
        print("op op_gemm_weight sum counts{}".format(len(\
            self.op_gemm_weight)))
        print("op op_constant sum counts{}".format(len(\
            self.op_constant)))
        print("op op_controlflow sum counts{}".format(len(\
            self.op_controlflow)))
        print("op op_misc sum counts{}".format(len(self.op_misc)))


ir_op_set = MMdnnIROperatorSet()


def sum_all_output_size(layer):
    """[Sum of tensor's output shape to tensor size]
    
    Arguments:
        layer {[type]} -- [layer spec]
    
    Returns:
        [type] -- [output size]
    """
    # parse output dim
    shape = layer["attr"]["_output_shapes"]["list"]["shape"][0]["dim"]
    out_dims = 1
    for dim in shape:
        if int(dim["size"]) != -1:
            out_dims = out_dims * int(dim["size"])
    return out_dims


def convert_data(layer, input_layers, batchsize=16):
    """[Convert input data layer spec]
    
    Arguments:
        layer {[type]} -- [layer spec]
        input_layers {[type]} -- [description]
    
    Keyword Arguments:
        batchsize {int} -- [batch size] (default: {16})
    
    Returns:
        [type] -- [Converted layer spec]
    """
    # NOTE, it does not contains Batchsize, need tag it later
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = "Input"
    layer_meta["parents"] = []
    dims = layer["attr"]["shape"]["shape"]["dim"]
    darray = []
    darray.append(batchsize)
    for dim in dims:
        if dim["size"] == -1 or "-1" in dim["size"]:
            continue
        darray.append(int(dim["size"]))
    layer_meta["tensor"] = darray
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_fc(layer, input_layers):
    """[Convert fully connected layer]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Converted layer spec]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = "Convolution"
    layer_meta["parents"] = layer["input"]
    # parse input dim
    in_dims = 1
    for in_layer in input_layers:
        shape = in_layer["attr"]["_output_shapes"]["list"]["shape"][0]["dim"]
        for dim in shape:
            if int(dim["size"]) != -1:
                in_dims = in_dims * int(dim["size"])

    # parse output dim
    shape = layer["attr"]["_output_shapes"]["list"]["shape"][0]["dim"]
    out_dims = 1
    for dim in shape:
        if int(dim["size"]) != -1:
            out_dims = out_dims * int(dim["size"])

    layer_meta["filter"] = [1, 1, in_dims,
                            out_dims]  # as mmdnn lack input shape,\
    # need put input layer into here
    layer_meta["padding"] = "VALID"
    layer_meta["strides"] = [1, 1, 1, 1]
    layer_meta["activation_fn"] = ""
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_pool(layer):
    """[Convert pooling layer]
    
    Arguments:
        layer {[type]} -- [layer spec]
    
    Returns:
        [type] -- [Converted layer spec]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = "Pooling"
    layer_meta["parents"] = layer["input"]
    filter = []
    for f in layer["attr"]["kernel_shape"]["list"]["i"]:
        filter.append(int(f))
    layer_meta["ksize"] = filter
    strides = []
    for s in layer["attr"]["strides"]["list"]["i"]:
        strides.append(int(s))
    layer_meta["strides"] = strides
    layer_meta["padding"] = "VALID"  # use VALID as default, need update later
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_conv(layer):
    """[Convert conv2d layer]
    
    Arguments:
        layer {[type]} -- [layer spec]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = "Convolution"
    layer_meta["parents"] = layer["input"]
    filter = []
    for f in layer["attr"]["kernel_shape"]["list"]["i"]:
        filter.append(int(f))
    layer_meta["filter"] = filter
    layer_meta[
        "padding"] = "SAME"  #? need understand mmdnn padding, use SAME \
    # as default now
    strides = []
    for s in layer["attr"]["strides"]["list"]["i"]:
        strides.append(int(s))
    layer_meta["strides"] = strides
    layer_meta["activation_fn"] = ""  # need combine the conv and activation \
    # op at DAG
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_dropout(layer):
    """[Convert dropout layer]
    
    Arguments:
        layer {[type]} -- [Layer spec]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["parents"] = layer["input"]
    layer_meta["dropout_keep_prob"] = float(layer["attr"]["keep_prob"]["f"])
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_softmax(layer):
    """[Convert softmax layer]
    
    Arguments:
        layer {[type]} -- [Layer spec]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = "Softmax"
    layer_meta["parents"] = layer["input"]
    shape = layer["attr"]["_output_shapes"]["list"]["shape"][0]["dim"]
    # parse dim
    dims = 1

    for dim in shape:
        if int(dim["size"]) != -1:
            dims = dims * int(dim["size"])
    layer_meta["num_classes"] = dims
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_op_elimentwise_map_mem(layer, input_layers):
    """[Convert elementwise layer spec]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["parents"] = layer["input"]
    layer_meta["attr"] = layer["attr"]
    # output_size = sum_all_output_size(layer)
    # layer_meta["output_size"] = output_size
    return layer_meta


def convert_op_shape_transpose(layer, input_layers):
    """[Convert shape transpose layer]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Layer spec]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["parents"] = layer["input"]
    layer_meta["attr"] = layer["attr"]
    if "Reshape" in layer_meta["type"]:
        dims = layer["attr"]["_output_shapes"]["list"]["shape"][0]["dim"]
        darray = []
        #darray.append(batchsize)
        for dim in dims:
            if dim["size"] == -1 or "-1" in dim["size"]:
                darray.append(batchsize)
                continue
            darray.append(int(dim["size"]))
        layer_meta["output_shape"] = darray
    # output_size = sum_all_output_size(layer)
    # layer_meta["output_size"] = output_size
    return layer_meta


def convert_op_join(layer, input_layers):
    """[Convert join layer]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["parents"] = layer["input"]
    layer_meta["attr"] = layer["attr"]
    # output_size = sum_all_output_size(layer)
    # layer_meta["output_size"] = output_size
    return layer_meta


def convert_op_gemm_weight(layer, input_layers):
    """[Convert gemm layer]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["parents"] = layer["input"]
    layer_meta["attr"] = layer["attr"]
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_op_constant(layer, input_layers):
    """[Convert constant layer]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["parents"] = []
    if "input" in layer:
        layer_meta["parents"] = layer["input"]
    layer_meta["attr"] = layer["attr"]
    output_size = sum_all_output_size(layer)
    layer_meta["output_size"] = output_size
    return layer_meta


def convert_op_controlflow(layer, input_layers):
    """[Convert controlflow layer]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["parents"] = layer["input"]
    layer_meta["attr"] = layer["attr"]
    return layer_meta


def convert_op_misc(layer, input_layers):
    """[Convert misc layer]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [type] -- [Converted layer]
    """
    layer_meta = {}
    layer_meta["name"] = layer["name"]
    layer_meta["type"] = layer["op"]
    layer_meta["attr"] = layer["attr"]
    layer_meta["parents"] = []
    if "input" in layer:
        layer_meta["parents"] = layer["input"]
    return layer_meta


def parse_layer(layer, input_layers):
    """[parse layer type then dispatch convert]
    
    Arguments:
        layer {[type]} -- [description]
        input_layers {[type]} -- [description]
    
    Returns:
        [str] -- [Layer name]
        [DictType] -- [Converted layer spec]
    """
    layer_name = layer["name"]
    layer_meta = {}

    if layer["op"] == "DataInput":
        layer_meta = convert_data(layer, input_layers)
        #return "data", layer_meta
    elif layer["op"] == "FullyConnected":
        layer_meta = convert_fc(layer, input_layers)
    # elif layer["op"] == "Flatten":
    #     layer_meta = convert_flatten(layer, input_layers)
    elif layer["op"] == "Dropout":
        layer_meta = convert_dropout(layer)
    elif layer["op"] == "Conv":
        layer_meta = convert_conv(layer)
    elif layer["op"] == "Pool":
        layer_meta = convert_pool(layer)
    elif layer["op"] == "Softmax":
        layer_meta = convert_softmax(layer)
    elif layer["op"] in ir_op_set.in_place_op:
        layer_meta = convert_op_elimentwise_map_mem(layer, input_layers)
    elif layer["op"] in ir_op_set.op_shape_transpose_fix or \
        layer["op"] in ir_op_set.op_shape_transpose_pool:
        layer_meta = convert_op_shape_transpose(layer, input_layers)
    elif layer["op"] in ir_op_set.op_elimentwise_join:
        layer_meta = convert_op_join(layer, input_layers)
    elif layer["op"] in ir_op_set.op_gemm_weight:
        layer_meta = convert_op_gemm_weight(layer, input_layers)
    elif layer["op"] in ir_op_set.op_constant:
        layer_meta = convert_op_constant(layer, input_layers)
    elif layer["op"] in ir_op_set.op_controlflow:
        layer_meta = convert_op_controlflow(layer, input_layers)
    elif layer["op"] in ir_op_set.op_misc:
        layer_meta = convert_op_misc(layer, input_layers)
    return layer_name, layer_meta


@click.group()
@click.option('--verbose', is_flag=True, help="help")
def cli(verbose):
    """[set log level]
    
    Arguments:
        verbose {[type]} -- [description]
    """
    # if verbose:
    #     logger.setLevel(logging.DEBUG)
    print("skip")


@cli.command()
@click.option('--input_path', '-i', help='input path')
@click.option('--output_path', '-o', help='output path')
def parse_mmdnn_to_json(input_path, output_path):
    """[convert MMdnn IR to DnnSAT json]
    
    Arguments:
        input_path {[type]} -- [Input MMdnn IR file path]
        output_path {[type]} -- [Generated file path]
    """
    layer_list = {}
    with open(input_path) as json_file:
        data = json.load(json_file)
        node = data["node"]
        layer_list["name"] = input_path
        layer_list["layers"] = {}
        # construct dic for layer input layer usage
        layer_dic = {}

        for layer in node:
            layer_name = layer["name"]
            layer_dic[str(layer_name)] = layer

        for layer in node:
            input_layers = []

            if "input" in layer:
                parents = layer["input"]
                for parent in parents:
                    # NOTE: model file contains layer parents not exists
                    if str(parent) in layer_dic:
                        input_layers.append(layer_dic[str(parent)])

            layer_name, parsed_layer = parse_layer(layer, input_layers)
            layer_list["layers"][str(layer_name)] = parsed_layer

        with open(output_path, 'w') as outfile:
            print(layer_list)
            json.dump(layer_list, outfile, indent=4, sort_keys=True)
        GB = 1024 * 1024 * 1024


# python3 dnnsat/utils/ir_transformer.py parse-mmdnn-to-json \
# -i keras_imagenet_vgg16.json -o nets/mmdnn_vgg16.json

if __name__ == "__main__":
    """[Main entry of MMdnn IR file to DnnSAT net json file]
    """
    cli()
