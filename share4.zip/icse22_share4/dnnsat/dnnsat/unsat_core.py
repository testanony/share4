from z3 import *
from dnnsat.param import *
from logger import logger


def get_solver_opt(ctx=None):
    if use_opt:
        if ctx == None:
            return Optimize()
        else:
            return Optimize(ctx=ctx)
    else:
        if ctx == None:
            s = DnnSATSolver()
            if use_unsatcore:
                s.set(unsat_core=True)
            return s
        else:
            s = DnnSATSolver(ctx=ctx)
            if use_unsatcore:
                s.set(unsat_core=True)
            return s


class DnnSATSolver(Solver):
    """
    Add sub class and switch to call unsat core and avoid code change for 
    dnnsat

    Args:
        Solver 
    """
    def __init__(self, solver=None, ctx=None, logFile=None):
        super().__init__(solver, ctx, logFile)

    def add(self, *args):
        """
        Add constraints.
        >>> x = Int('x')
        >>> g = Goal()
        >>> g.add(x > 0, x < 2)
        >>> g
        [x > 0, x < 2]
        """
        if use_unsatcore:
            logger.debug(str(args[0]))
            super().assert_and_track(*args, '{}'.format(str(args[0])))
        else:
            super().add(*args)
