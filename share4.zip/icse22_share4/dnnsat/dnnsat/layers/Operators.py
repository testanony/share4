from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from dnnsat.param import *
from dnnsat.csp_solving import *
from dnnsat.gen_solver_variable import *
from dnnsat.gen_solver_constraint import *
from dnnsat.utils import ir_op_set


class OperatorFactory(object):
    """ simple factory for operators 
    """
    @staticmethod
    def construct_operator(op_type, op_spec, opt, ctx, layer_id, search_space):
        operators_dic = {
            "input": InputOp,
            "conv2d": Conv2DOp,
            "pool2d": Pool2DOp,
            "activation2d": ActivationOp,
            "softmax": SoftmaxOp, 
            "innerproduct": SoftmaxOp,
            "generic_Accuracy": SoftmaxOp,
            "batchnorm2d": BatchNormOp,
            "generic_BatchNorm": BatchNormOp,
            "dropout": DropoutOp,
            "dropout2d": DropoutOp,
            "concat": ConcatOp,
            "reshape": ReshapeOp,
            "squeeze": SqueezeOp,
            "transpose": TransposeOp, 
            "unsqueeze": UnSqueezeOp,
            "elementwise": ElementwiseOp,
            "rnn": RNNOp
        }

        op_type = "activation2d" if op_type.lower() in ir_op_set.activation \
                    else op_type 

        op_type = "elementwise" if op_type.lower() in ir_op_set.elementwise \
                    else op_type 
        
        op_type = "rnn" if op_type.lower() in ir_op_set.rnn \
                    else op_type 

        if op_type in operators_dic:
            return operators_dic[op_type](layer_spec = op_spec, solver = opt, \
                                          ctx = ctx, layer_id = layer_id, \
                                          search_space = search_space) 
        else:
            assert False, 'the operator is not exists {}'.format(op_type)   


class BaseOperator(object):
    """Base class for operator. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        self.layer_spec = layer_spec
        self.op_name = self.layer_spec.layer_op.name
        self.op_type = self.layer_spec.layer_op.layertype
        self.solver = solver
        self.ctx = ctx
        self.layer_id = layer_id
        self.search_space = search_space
        self.symbol_dic = []

    def init_symbols(self):
        """init z3 symbols"""
        return self._name

    def gen_datatype_dataformat_constraint(self, \
                                           symbols_dic, \
                                           layer_spec, \
                                           search_space, \
                                           solver, \
                                           ctx):
        #logger.debug("gen_datatype_dataformat_constraint")
        gen_tensor_datatype_search_space_constraints(symbols_dic, \
                                                     layer_spec, \
                                                     search_space, \
                                                     solver, \
                                                     ctx)
        gen_tensor_dataformat_search_space_constraints(symbols_dic, \
                                                      layer_spec, \
                                                      search_space, \
                                                      solver, \
                                                      ctx)
        return 

    def push_constraints(self, solver):
        """generate constraint"""
        self.solver.push()
        return
    
    def pop_constraints(self):
        """release constraint"""
        self.solver.pop()
        return

    def solve(self, output_folder, net_arch, allsat_callback, log_mode = "w", \
              msg_show_in_log = ""):
        """solve at this operator"""
        return allsat_callback(self.solver, \
                                self.ctx, \
                                output_folder, \
                                degree = 1, \
                                net_arch = net_arch, \
                                search_space_var_dic = None, \
                                speed_output=None, \
                                log_mode = log_mode, \
                                msg_show_in_log = msg_show_in_log)



class Conv2DOp(BaseOperator):
    """Conv2D. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(Conv2DOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space
        if "dataformat" in layer_spec.params:
            if layer_spec.params["dataformat"][1] == "C":
                self.data_format = "NCHW"
            else: 
                self.data_format = "NHWC"
        else:
            self.data_format = "NHWC"

    def init_symbols(self):
        """init z3 symbols"""
        if self.data_format == "NCHW":
            channel_first = True
        else:
            channel_first = False
        self.symbols_dic = gen_conv2d_symbols(self.op_name, self.op_type, \
                                self.solver, self.ctx, self.layer_id, channel_first = channel_first)
            
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(Conv2DOp, self).push_constraints(solver)
        if "fc" not in self.op_name and "Linear" not in self.op_name:
            conv2d_shape_rules(opt=self.solver,
                                inputs=self.symbols_dic["inputs"],
                                filters=self.symbols_dic["filters"],
                                strides=self.symbols_dic["strides"],
                                paddings=self.symbols_dic["padding"])
        elif "Linear" in self.op_name:
            #print("in if gen_conv2d_symbols op name: ", op_name)
            fc_shape_rules(opt=self.solver,
                            inputs=self.symbols_dic["inputs"],
                            filters=self.symbols_dic["filters"],
                            strides=self.symbols_dic["strides"])
        gen_conv2d_op_constraint(self.symbols_dic, self.layer_spec, \
                                 self.search_space, self.solver, self.ctx)
        
        if refty_use_dataformat_datatype_rule:
            logger.debug("gen_datatype_dataformat_constraint")
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class InputOp(BaseOperator):
    """InputOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(InputOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self, rank = 4):
        """init z3 symbols"""
        self.symbols_dic = gen_input_symbols_(self.op_name, self.op_type, \
                                             self.ctx, self.layer_id, rank = 4)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(InputOp, self).push_constraints(solver)
        gen_input_op_constraint(self.symbols_dic, self.layer_spec.layer_op, \
                                self.search_space, self.solver, self.ctx)
        if refty_use_dataformat_datatype_rule:
            logger.debug("gen_datatype_dataformat_constraint")
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class Pool2DOp(BaseOperator):
    """Pool2DOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(Pool2DOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space
        if "dataformat" in layer_spec.params:
            if layer_spec.params["dataformat"][1] == "C":
                self.data_format = "NCHW"
            else: 
                self.data_format = "NHWC"
        else:
            self.data_format = "NHWC"

    def init_symbols(self):
        """init z3 symbols"""
        if self.data_format == "NCHW":
            channel_first = True
        else:
            channel_first = False
        self.symbols_dic = gen_pool2d_symbols(self.op_name, self.op_type, \
                                              self.solver, self.ctx, self.layer_id, \
                                              channel_first = channel_first)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(Pool2DOp, self).push_constraints(solver)
        pool2d_shape_rules(opt=self.solver,
                           inputs=self.symbols_dic["inputs"],
                           ksizes=self.symbols_dic["kernel"],
                           strides=self.symbols_dic["strides"])
        gen_pool2d_op_constraint(self.symbols_dic, self.layer_spec, \
                                 self.search_space, self.solver, self.ctx)
        if refty_use_dataformat_datatype_rule:
            logger.debug("gen_datatype_dataformat_constraint")
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class ActivationOp(BaseOperator):
    """Activation. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(ActivationOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_activation2d_symbols(self.op_name, self.op_type, \
                                                    self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(ActivationOp, self).push_constraints(solver)
        # forall input == output, 
        # the rule is implies implemented at shape inference
        if refty_use_dataformat_datatype_rule:
            logger.debug("gen_datatype_dataformat_constraint")
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class SoftmaxOp(BaseOperator):
    """Softmax. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(SoftmaxOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_softmax_symbols(self.op_name, self.op_type, \
                                               self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(SoftmaxOp, self).push_constraints(solver)
        # forall input == output, 
        # the rule is implies implemented at shape inference
        if refty_use_dataformat_datatype_rule:
            logger.debug("gen_datatype_dataformat_constraint")
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return
        

class BatchNormOp(BaseOperator):
    """BatchNorm. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(BatchNormOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_batchnorm2d_symbols(self.op_name, self.op_type, \
                                                   self.ctx, self.layer_id)

        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(BatchNormOp, self).push_constraints(solver)
        # forall input == output, 
        # the rule is implies implemented at shape inference
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class DropoutOp(BaseOperator):
    """DropoutOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(DropoutOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_dropout2d_symbols(self.op_name, self.op_type, \
                                                 self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(DropoutOp, self).push_constraints(solver)
        # forall input == output, 
        # the rule is implies implemented at shape inference
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class ConcatOp(BaseOperator):
    """ConcatOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(ConcatOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_concat_symbols(self.op_name, self.op_type, \
                                              self.layer_spec.inputs, \
                                              self.layer_spec.dim,  \
                                              self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(ConcatOp, self).push_constraints(solver)
        concat_shape_rules(opt=self.solver,
                           input_list=self.symbols_dic["inputs"],
                           dim=self.symbols_dic["dim"])
        # forall input == output, 
        # the rule is implies implemented at shape inference
        # each dim > 0
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class ReshapeOp(BaseOperator):
    """ReshapeOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(ReshapeOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_reshape_symbols(self.op_name, self.op_type, \
                                               self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(ReshapeOp, self).push_constraints(solver)
        reshape_shape_rules(opt=self.solver,
                            inputs=self.symbols_dic["inputs"],
                            outputs=self.symbols_dic["outputs"])
        # forall input == output, 
        # the rule is implies implemented at shape inference 
        # each dim > 0 
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class SqueezeOp(BaseOperator):
    """SqueezeOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(ReshapeOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_squeeze_symbols(self.op_name, self.op_type, \
                                               self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(ReshapeOp, self).push_constraints(solver)
        # TODO squeeze
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class TransposeOp(BaseOperator):
    """TransposeOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(TransposeOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_transpose_symbols(self.op_name, self.op_type, \
                                                 self.layer_spec.onnx.input, \
                                                 self.layer_spec.onnx.dim1, \
                                                 self.layer_spec.onnx.dim2, \
                                                 self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(Transpose, self).push_constraints(solver)
        # TODO squeeze
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class UnSqueezeOp(BaseOperator):
    """UnSqueezeOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(UnSqueezeOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_unsqueeze_symbols(self.op_name, self.op_type, \
                                                 self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(UnSqueeze, self).push_constraints(solver)
        # TODO UnSqueeze
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class ElementwiseOp(BaseOperator):
    """Elementwise. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(ElementwiseOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_elementwise_symbols(self.op_name, self.op_type, \
                                                   self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(Elementwise, self).push_constraints(solver)
        # TODO gen_elementwise_op_constraint forall all input == output
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class BinaryOp(BaseOperator):
    """BinaryOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(BinaryOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)
        self.layer_spec = layer_spec
        self.solver = solver
        self.ctx = ctx
        self.search_space = search_space
        
    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_add_symbols(self.op_name, self.op_type, \
                                           self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(BinaryOp, self).push_constraints(solver)
        # TODO forall all input == output
        if refty_use_dataformat_datatype_rule:
            self.gen_datatype_dataformat_constraint(self.symbols_dic, \
                                                    self.layer_spec, \
                                                    self.search_space, \
                                                    self.solver, \
                                                    self.ctx)
        return


class RNNOp(BaseOperator):
    """RNNOp. """
    def __init__(self, layer_spec, solver, ctx, layer_id, search_space):
        super(RNNOp, self).__init__(layer_spec, solver, ctx, layer_id, search_space)

    def init_symbols(self):
        """init z3 symbols"""
        self.symbols_dic = gen_rnn_symbols(self.op_name, self.op_type, \
                                           self.ctx, self.layer_id)
        return self.symbols_dic

    def push_constraints(self, solver):
        """generate constraint"""
        super(RNNOp, self).push_constraints(solver)
        gen_rnn_op_constraint(self.symbols_dic, self.layer_spec.seq_len, \
                              self.layer_spec.batch_size, \
                              self.layer_spec, \
                              self.search_space, \
                              self.solver, \
                              self.ctx)
        return
