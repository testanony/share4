# variable data precision
# https://rise4fun.com/z3/tutorialcontent/guide#h25
# https://ericpony.github.io/z3py-tutorial/guide-examples.htm
use_bit_vec = False
bit_len = 32
# parallel and interval filtering speedup
# intro of the optimization: https://www.microsoft.com/en-us/research/uploads/prod/2021/02/dnnsat.pdf
use_parallel = False
num_parallel_degree = 1
constraint_split_degree = 1
need_tiny_search_space = False
interval_filtering_flag = False 
use_constraint_merge = False
# DnnSAT or DNNCheck
use_shape_rule = True # Whether to use shape checking constraintls
use_resource_constraint =  False # Whether to use resources cost function constraint
# UNSAT core or not
use_opt = False # use Z3 optimizer (could solve csp problem) or solver object for solving
use_unsatcore = False # intro of UNSATCORE https://www.fmcad.org/FMCAD16/slides/s3t2.pdf
use_refty_op_topo_solving = False # iterate the operators then tigger solving at specific operators
use_refty_diagnosis_mode = False # this mode will trigger solving at each operator point
refty_diagnosis_multi_error = False
refty_use_dataformat_datatype_rule = False
