"""Code generation of DnnSAT solver weight equations
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from z3 import *
import math
import numpy as np


def construct_operator_weights_symbol(op_name, op_type, op_spec, ctx):
    """
    Generate operator z3 equations
    
    Arguments:
        op_name -- Operator name
        op_type -- Operator type
        op_spec -- Operator spec
        ctx -- Z3 context
    """
    if op_type == "conv2d":
        return _conv2d_weight(op_name, ctx)
    elif op_type in ["batchnorm2d", "generic_BatchNorm"]:
        return _batchnorm2d_weight(op_name, ctx)
    elif op_type == "rnn":
        return _rnn_weight(op_name, op_spec.onnx._seq_len, \
            op_spec.onnx._batch, op_spec.onnx._input_size, \
            op_spec.onnx._num_layers, op_spec.onnx._num_directions, \
            op_spec.onnx._hidden_size, ctx)
    else:  # TODO
        return


def conv2d_weight(filters):
    """
    conv2d weghts cost func, linear consider as a special conv to share
    cost func
    
    Assume
        inputs: [N, H, W, C]
        outputs: [N, H, W, C] # [batch_size,,,] ???
        filters: [H, W, C_in, C_out]

    Arguments:
        inputs -- 
        filters -- 
        strides -- 
        padding -- 
    """

    weights = filters
    bias = filters[3]  # bias output channels
    return np.prod(weights) + bias


def batchnorm2d_weight(inputs):
    """
    batchnorm cost func

    Assume
        inputs: [N, H, W, C]
        outputs: [N, H, W, C] # [batch_size,,,] ???
    Arguments:
        inputs -- 
        filters -- 
        strides -- 
        padding -- 
    """
    output_channel = inputs[3]
    return 2 * output_channel


def rnn_weight(mode,
               input_size,
               num_layers,
               num_directions,
               hidden_size,
               unit=1):
    """
    RNN weight cost func
    Ref:    
    # TODO: does it related with _num_directions??
    Arguments:
        seq_len -- description
        batch -- description
        input_size -- description
        num_layers -- description
        num_directions -- description
        hidden_size -- description
    """

    num_mats = 2

    if mode == "GRU":
        num_mats = 6
    elif mode == "LSTM":
        num_mats = 8
    else:
        num_mats = 2

    weights = hidden_size * input_size * num_layers * num_mats
    return weights / unit
