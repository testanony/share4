"""Code generation of DnnSAT solver equations
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from dnnsat.type.hyperparam import HyperparamterTensor
from dnnsat.type.tensor import InputTensor, OutputTensor
from z3 import *
from logger import logger
from dnnsat.shape_inference import conv2d_output_shape
from dnnsat.shape_inference import pool2d_output_shape
from dnnsat.shape_inference import activation_output_shape
from dnnsat.shape_inference import softmax_output_shape
from dnnsat.shape_inference import batchnorm2d_output_shape
from dnnsat.shape_inference import dropout2d_output_shape
from dnnsat.shape_inference import squeeze_output_shape
from dnnsat.shape_inference import transpose_output_shape
from dnnsat.shape_inference import reshape_output_shape
from dnnsat.shape_inference import unsqueeze_output_shape
from dnnsat.shape_inference import elementwise_output_shape
from dnnsat.shape_inference import add_output_shape
from dnnsat.shape_inference import rnn_output_shape
from dnnsat.weight_cost_func import conv2d_weight
from dnnsat.weight_cost_func import batchnorm2d_weight
from dnnsat.flops_cost_func import conv2d_fwd_FLOPs
from dnnsat.flops_cost_func import pool2d_fwd_FLOPs
from dnnsat.flops_cost_func import activation_fwd_FLOPs
from dnnsat.flops_cost_func import softmax_fwd_FLOPs
from dnnsat.flops_cost_func import batchnorm2d_fwd_FLOPs
from dnnsat.flops_cost_func import dropout2d_fwd_FLOPs
from dnnsat.flops_cost_func import elementwise_fwd_FLOPs
from dnnsat.flops_cost_func import add_fwd_FLOPs
from dnnsat.flops_cost_func import rnn_fwd_FLOPs
from dnnsat.shape_rules import conv2d_shape_rules, fc_shape_rules
from dnnsat.shape_rules import pool2d_shape_rules
from dnnsat.shape_rules import concat_shape_rules
from dnnsat.shape_rules import reshape_shape_rules
from dnnsat.param import *
from dnnsat.utils import ir_op_set
from dnnsat.mem_cost_func import rnn_mem
from dnnsat.weight_cost_func import rnn_weight
from dnnsat.init_var_sym import *

def construct_solver_variable_rnn(op_name, op_type, op_spec, opt, ctx, layer_id):
    if op_type == "input":
        return gen_input_symbols_(op_name, op_type, ctx, layer_id, rank=2)
    elif op_type == "rnn":
        return gen_rnn_symbols(op_name, op_type, ctx, layer_id)

def construct_solver_variable(op_name, op_type, op_spec, opt, ctx, layer_id, channel_first = False):
    """
    Generate operator z3 equations
    
    Arguments:
        op_name -- Operator name
        op_type -- Operator type
        op_spec -- Operator spec
        ctx -- Z3 context
    
    Raises:
        Exception: description
    
    Returns:
        Z3 symbols of operator
    """
    if op_type == "input":
        return gen_input_symbols_(op_name, op_type, ctx, layer_id)
    elif op_type == "conv2d":
        return gen_conv2d_symbols(op_name, op_type, opt, ctx, layer_id, channel_first)
    elif "pool" in op_type and op_name != "InceptionV3/Logits/AvgPool_1a_8x8/AvgPool":
        return gen_pool2d_symbols(op_name, op_type, opt, ctx, layer_id, channel_first)
    elif op_name == "InceptionV3/Logits/AvgPool_1a_8x8/AvgPool":
        return gen_gblpool2d_symbol(op_name, op_type, opt, ctx, layer_id)
    elif op_type == "activation2d" or op_type.lower() in ir_op_set.activation:
        return gen_activation2d_symbols(op_name, op_type, ctx, layer_id)
    elif op_type in ["softmax", "innerproduct", "generic_Accuracy"]:
        return gen_softmax_symbols(op_name, op_type, ctx, layer_id)
    elif op_type in ["batchnorm2d", "generic_BatchNorm"]:
        return gen_batchnorm2d_symbols(op_name, op_type, ctx, layer_id)
    elif op_type in ["dropout", "dropout2d"]:
        return gen_dropout2d_symbols(op_name, op_type, ctx, layer_id)
    elif op_type == "concat":
        #print("concat op_spec.inputs {}".format(op_spec.inputs))
        return gen_concat_symbols(op_name, op_type, op_spec.inputs, \
            op_spec.dim, opt, ctx, layer_id)
    elif op_type == "reshape":
        #print("reshape layer id: ", layer_id)
        return gen_reshape_symbols(op_name, op_type, opt, ctx, layer_id)
    elif op_type == "squeeze":
        return gen_squeeze_symbols(op_name, op_type, ctx, layer_id)
    elif op_type == "transpose":
        return gen_transpose_symbols(op_name, op_type, op_spec.onnx.input, \
            op_spec.onnx.dim1, op_spec.onnx.dim2, ctx, layer_id)
    elif op_type == "unsqueeze":
        return gen_unsqueeze_symbols(op_name, op_type, ctx, layer_id)
    elif op_type == "elementwise" or op_type.lower() in ir_op_set.elementwise:
        return gen_elementwise_symbols(op_name, op_type, ctx, layer_id)
    elif op_type == "add":
        return gen_add_symbols(op_name, op_type, ctx)
    elif op_type == "rnn" or op_type.lower() in ir_op_set.rnn:
        return gen_rnn_symbols(op_name, op_type, op_spec._seq_len, \
            op_spec._batch_size, op_spec._input_size, \
            op_spec._num_layers, op_spec._num_directions, \
            op_spec._hidden_size, op_spec._output_dim, ctx, layer_id)
    else:
        return dict()
    # else:
    #     raise Exception("error construct_solver_variable {}".format(op_type))


def gen_input_symbols_(op_name, op_type, ctx, layer_id, rank=4):
    """[summary]
        generate the input tensor symbols
    Args:
        op_name ([type]): [description]
        op_type ([type]): [description]
        ctx ([type]): [description]
        rank (int, optional): [description]. Defaults to 4.

    Returns:
        [type]: [description]
    """
    tensor = InputTensor(rank = rank, ctx = ctx, layer_id=layer_id)
    inputs = InputTensor(rank = rank, ctx = ctx, layer_id=layer_id)
    op_symbol_dic = dict()
    op_symbol_dic["name"] = op_name
    op_symbol_dic["type"] = op_type
    op_symbol_dic["input_tensor_obj"] = inputs 
    op_symbol_dic["inputs"] = inputs.get_all_dims()
    op_symbol_dic["outputs"] = op_symbol_dic["inputs"]
    return op_symbol_dic


def gen_conv2d_symbols(op_name, op_type, opt, ctx, layer_id, channel_first = False):
    """
    Generate Conv2d z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context
    
    Returns:
        Operator symbols
    """
    inputs = InputTensor(rank = 4, ctx = ctx, layer_id=layer_id)
    filters = HyperparamterTensor(op_name=op_name, tensor_name = 'filter', rank = 4, ctx = ctx, layer_id=layer_id, op_type = op_type).get_all_dims()
    strides = HyperparamterTensor(op_name=op_name, tensor_name = 'stride', rank = 4, ctx = ctx, layer_id=layer_id, op_type = op_type).get_all_dims()
    paddings = HyperparamterTensor(op_name=op_name, tensor_name = 'padding', rank = 4, ctx = ctx, layer_id=layer_id, op_type = op_type).get_all_dims()

    op_symbol_dic = {}
    op_symbol_dic["input_tensor_obj"] = inputs
    op_symbol_dic["name"]    = op_name
    op_symbol_dic["type"]    = op_type
    op_symbol_dic["inputs"]  = inputs.get_all_dims() 
    op_symbol_dic["filters"] = filters 
    op_symbol_dic["strides"] = strides 
    op_symbol_dic["padding"] = paddings
    op_symbol_dic["outputs"] = conv2d_output_shape(op_symbol_dic["inputs"],
                                                   op_symbol_dic["filters"],
                                                   op_symbol_dic["strides"],
                                                   op_symbol_dic["padding"],
                                                   channel_first)
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["weights"] = conv2d_weight(op_symbol_dic["filters"])
    op_symbol_dic["weights_gradients"] = op_symbol_dic["weights"]
    op_symbol_dic["fwd_FLOPs"] = conv2d_fwd_FLOPs(
        inputs=op_symbol_dic["inputs"],
        filters=op_symbol_dic["filters"],
        outputs=op_symbol_dic["outputs"])

    if not use_refty_op_topo_solving: 
        if "fc" not in op_name and "Linear" not in op_name:
            conv2d_shape_rules(opt=opt,
                            inputs=op_symbol_dic["inputs"],
                            filters=op_symbol_dic["filters"],
                            strides=op_symbol_dic["strides"],
                            paddings=op_symbol_dic["padding"])
        elif "Linear" in op_name:
            #print("in if gen_conv2d_symbols op name: ", op_name)
            fc_shape_rules(opt=opt,
                            inputs=op_symbol_dic["inputs"],
                            filters=op_symbol_dic["filters"],
                            strides=op_symbol_dic["strides"])
    print("gen_conv2d_symbols op name: ", op_name)
        
    return op_symbol_dic

def gen_gblpool2d_symbol(op_name, op_type, opt, ctx, layer_id):
    inputs = InputTensor(rank = 4, ctx = ctx, layer_id=layer_id)
    op_symbol_dic = {}
    op_symbol_dic["inputs"]   = inputs.get_all_dims()
    op_symbol_dic["outputs"]  = [op_symbol_dic["inputs"][0], 1, 1, op_symbol_dic["inputs"][-1]]
    op_symbol_dic["type"]     = op_type
    return op_symbol_dic
    
def gen_pool2d_symbols(op_name, op_type, opt, ctx, layer_id, channel_first = False):
    """
    Generate pool2d z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context
    
    Returns:
        Operator symbols
    """
    inputs = InputTensor(rank = 4, ctx = ctx, layer_id=layer_id)
    kernels = HyperparamterTensor(op_name=op_name, tensor_name = 'kernel', rank = 4, ctx = ctx, layer_id=layer_id, op_type = op_type).get_all_dims()
    strides = HyperparamterTensor(op_name=op_name, tensor_name = 'stride', rank = 4, ctx = ctx, layer_id=layer_id, op_type = op_type).get_all_dims()
    paddings = HyperparamterTensor(op_name=op_name, tensor_name = 'padding', rank = 4, ctx = ctx, layer_id=layer_id, op_type = op_type).get_all_dims()

    op_symbol_dic = {}
    op_symbol_dic["input_tensor_obj"] = inputs
    op_symbol_dic["name"]    = op_name
    op_symbol_dic["type"]    = op_type
    op_symbol_dic["inputs"]  = inputs.get_all_dims() 
    op_symbol_dic["kernel"]  = kernels 
    op_symbol_dic["strides"] = strides 
    op_symbol_dic["padding"] = paddings
    op_symbol_dic["outputs"] = pool2d_output_shape(op_symbol_dic["inputs"],
                                                   op_symbol_dic["kernel"],
                                                   op_symbol_dic["strides"],
                                                   op_symbol_dic["padding"],
                                                   channel_first)
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["fwd_FLOPs"] = pool2d_fwd_FLOPs(
        inputs=op_symbol_dic["inputs"],
        kernel=op_symbol_dic["kernel"],
        outputs=op_symbol_dic["outputs"])
    if not use_refty_op_topo_solving:
        pool2d_shape_rules(opt=opt,
                        inputs=op_symbol_dic["inputs"],
                        ksizes=op_symbol_dic["kernel"],
                        strides=op_symbol_dic["strides"])
    return op_symbol_dic


def gen_activation2d_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate activation z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context
    
    Returns:
        Operator symbols
    """
    # Have input dim assumptions.
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)

    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = activation_output_shape(op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["fwd_FLOPs"] = activation_fwd_FLOPs(
        inputs=op_symbol_dic["inputs"])
    return op_symbol_dic


def gen_softmax_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate softmax z3 symbols
    
    support ops:
    softmax
    innerproduct

    Arguments:
        op_name -- Operator names
        ctx -- Z3 context

    Returns:
        Operator symbols
    """
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = softmax_output_shape(op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["fwd_FLOPs"] = softmax_fwd_FLOPs(
        inputs=op_symbol_dic["inputs"])
    return op_symbol_dic


def gen_batchnorm2d_symbols(op_name, op_type, ctx, layer_id):
    """[Generate batchnorm2d z3 symbols]
    
    Arguments:
        op_name {[type]} -- [Operator names]
        ctx {[type]} -- [Z3 context]
    
    Returns:
        [type] -- [Operator symbols]
    """
    # Have input dim assumptions.
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = batchnorm2d_output_shape(
        op_symbol_dic["inputs"])
    op_symbol_dic["weights"] = batchnorm2d_weight(op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["fwd_FLOPs"] = batchnorm2d_fwd_FLOPs(
        inputs=op_symbol_dic["inputs"])
    return op_symbol_dic


def gen_dropout2d_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate dropout2d z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context
    
    Returns:
        Operator symbols
    """
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = dropout2d_output_shape(op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["fwd_FLOPs"] = dropout2d_fwd_FLOPs(
        inputs=op_symbol_dic["inputs"])
    return op_symbol_dic


def gen_concat_symbols(op_name, op_type, inputs, dim, opt, ctx, layer_id):
    """
    Generate concat z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context
        input_list -- input tensor list
        dim -- dim

    Returns:
        Operator symbols
    """
    print("concat layer id: ", layer_id)
    op_symbol_dic = {}
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["name"] = op_name
    op_symbol_dic["type"] = op_type
    op_symbol_dic["dim"] = dim
    op_symbol_dic["outputs"] = op_symbol_dic["inputs"]
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]

    if not use_refty_op_topo_solving:
        concat_shape_rules(opt=opt,
                        input_list=op_symbol_dic["inputs"],
                        dim=op_symbol_dic["dim"])
    return op_symbol_dic


def concat_output_shape(input_list, dim, layer_id):
    first = []
    index = 0

    for i in input_list[0]:
        first.append(i)

    for i in input_list[1:]:
        first[dim] += i[dim]

    return first

def gen_reshape_output_symbols(ctx, layer_id):
    outputs = OutputTensor(rank=4, ctx = ctx, layer_id=layer_id).get_all_dims()
    return outputs

def gen_reshape_symbols(op_name, op_type, opt, ctx, layer_id):
    """
    Generate reshape z3 symbols
    
    Arguments:
        op_name -- Operator names
        input -- input tensor
        dim -- dim
        ctx -- Z3 context

    Returns:
        Operator symbols
    """
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["name"] = op_name
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = gen_reshape_output_symbols(ctx, layer_id)
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]

    if not use_refty_op_topo_solving:
        reshape_shape_rules(opt=opt,
                            inputs=op_symbol_dic["inputs"],
                            outputs=op_symbol_dic["outputs"])
    return op_symbol_dic


def gen_transpose_symbols(op_name, op_type, dim1, dim2, ctx, layer_id):
    """
    Generate reshape z3 symbols
    
    Arguments:
        op_name -- [Operator names
        input -- [input tensor
        dim1 -- [dim
        dim2 -- [dim
        ctx -- [Z3 context

    Returns:
        Operator symbols
    """
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = transpose_output_shape(op_symbol_dic["inputs"], \
        dim1, dim2)
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    return op_symbol_dic


def gen_squeeze_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate reshape z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context

    Returns:
        Operator symbols
    """
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = squeeze_output_shape(op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    return op_symbol_dic


def gen_unsqueeze_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate reshape z3 symbols
    
    Arguments:
        op_name -- [Operator names
        ctx -- [Z3 context

    Returns:
        Operator symbols
    """
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = unsqueeze_output_shape(op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    return op_symbol_dic


def gen_elementwise_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate elementwise z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context

    Returns:
        Operator symbols
    """
    print("in elementwise: ", op_type)
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = elementwise_output_shape(
        op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["fwd_FLOPs"] = elementwise_fwd_FLOPs(
        inputs=op_symbol_dic["inputs"])
    return op_symbol_dic


def gen_add_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate reshape z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context

    Returns:
        Operator symbols
    """
    op_symbol_dic = gen_4_dim_shape_operator_vars(op_name, ctx, layer_id=layer_id, op_type = op_type)
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = add_output_shape(op_symbol_dic["inputs"])
    op_symbol_dic["outputs_gradients"] = op_symbol_dic["outputs"]
    op_symbol_dic["fwd_FLOPs"] = add_fwd_FLOPs(inputs=op_symbol_dic["inputs"])
    return op_symbol_dic


def gen_layer_attr_symbol(layer_name, attr_lst, op_symbol_dict, ctx):
    name_generator = lambda attr: "{}:{}".format(layer_name, attr)
    symbol_lst = []
    for attr in attr_lst:
        name = name_generator(attr)
        op_symbol_dict[attr] = init_solver_variable(name, ctx)
        symbol_lst.append(op_symbol_dict[attr])
    return symbol_lst
    
def get_layer_symbol(layer_name, attr, op_symbol_dict):
    name = "{}:{}".format(layer_name, attr)
    return op_symbol_dict[name]

def gen_rnn_symbols(op_name, op_type, ctx, layer_id):
    """
    Generate rnn z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context

    Returns:
        Operator symbols
    """
    op_symbol_dic = {}
    seq_len, batch, num_embeddings, embedding_dim, n_layers, num_directions, hidden_dim = gen_layer_attr_symbol(op_name, ["seq_len", "batch", "num_embeddings", "embedding_dim", "n_layers", "num_directions", "hidden_dim"], op_symbol_dic, ctx)
    op_symbol_dic["name"] = op_name
    op_symbol_dic["type"] = op_type
    op_symbol_dic["outputs"] = rnn_output_shape(seq_len, batch, num_embeddings,
                                                n_layers, num_directions,
                                                hidden_dim)
    op_symbol_dic["fwd_FLOPs"] = rnn_fwd_FLOPs(mode=op_type,
                                               seq_len=seq_len,
                                               batch=batch,
                                               input_size=num_embeddings,
                                               num_layers=n_layers,
                                               num_directions=num_directions,
                                               hidden_size=hidden_dim)

    op_symbol_dic["mem"] = rnn_mem(mode=op_type,
                                   seq_len=seq_len,
                                   batch=batch,
                                   input_size=num_embeddings,
                                   num_layers=n_layers,
                                   num_directions=num_directions,
                                   hidden_size=hidden_dim,
                                   output_dim=embedding_dim)

    op_symbol_dic["weight"] = rnn_weight(mode=op_type,
                                         input_size=num_embeddings,
                                         num_layers=n_layers,
                                         num_directions=num_directions,
                                         hidden_size=hidden_dim,
                                         unit=1)

    op_symbol_dic["fwd_time"] = rnn_fwd_FLOPs(
        mode=op_type,
        seq_len=seq_len,
        batch=batch,
        input_size=embedding_dim,
        num_layers=n_layers,
        num_directions=num_directions,
        hidden_size=hidden_dim) / 9519  # P100
    
    return op_symbol_dic


def gen_4_dim_shape_operator_vars(op_name, ctx, layer_id, op_type):
    """
    Generate reshape z3 symbols
    
    Arguments:
        op_name -- Operator names
        ctx -- Z3 context

    Returns:
        Operator symbols
    """
    inputs = InputTensor(rank = 4, ctx = ctx, layer_id=layer_id).get_all_dims()
    op_symbol_dic = {}
    op_symbol_dic["input_tensor_obj"] = inputs
    op_symbol_dic["name"] = op_name
    op_symbol_dic["inputs"] = inputs
    return op_symbol_dic

