#! /bin/sh
NET_FOLDER=nets
NET_FILE=nets/vgg16.json
OUT_FOLDER=results/vgg16
OUT_FILE=results/vgg16/log
mkdir results
mkdir $OUT_FOLDER

python3 main.py $NET_FILE \
    --device_name=TITAN_X \
    --output_folder=$OUT_FOLDER \
    --search_space_path=$NET_FOLDER/vgg16_search_space_1_constraint.json >> $OUT_FILE