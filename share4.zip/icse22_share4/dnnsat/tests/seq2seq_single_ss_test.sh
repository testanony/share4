#! /bin/sh
NET_FOLDER=nets/
NET_FILE=nets/seq2seq.json
OUT_FOLDER=results/seq2seq
OUT_FILE=results/seq2seq/log
mkdir results
mkdir $OUT_FOLDER

python3 main.py $NET_FILE \
    --device_name=TITAN_X \
    --output_folder=$OUT_FOLDER \
    --search_space_path=$NET_FOLDER/seq2seq_search_space.json  >> $OUT_FILE