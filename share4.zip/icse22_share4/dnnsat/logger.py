"""Logger for debugging
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import logging
import sys

logger = logging.getLogger('root')
FORMAT = "[%(filename)s:%(lineno)s - %(funcName)20s() ] %(message)s"
logging.basicConfig(stream=sys.stdout, format=FORMAT)
logger.setLevel(logging.DEBUG)
#logger.setLevel(logging.INFO)
