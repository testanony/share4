
RPATH=.
EXPPATH=refty_test/vgg_parallel_speed
THREAD=10
TASK=10
for THREAD in 1 4 8 12
do
    for TASK in 77 38 8
    do
        time python $RPATH/dnnsat/parallel_dist_launcher.py -thn $THREAD -nf $EXPPATH/vgg_16.json -ss $EXPPATH/vgg_16_search_space.json -o thread_$THREAD_task_$TASK -tn $TASK 
    done
done
