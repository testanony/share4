cd ..
REPO_PATH=/home/testcluster/yanjga/pythia_exp/dnncost
MODEL_NAME=mnist_pythia
# /home/testcluster/yanjga/pythia_exp/dnncost/dnnsat/scripts/
python3 $REPO_PATH/dnnsat/scripts/run_all_single_model.py --input_folder=$REPO_PATH/dnnperf_data/pythia_bench/mnist_pythia_refty_test/ --output_folder=$REPO_PATH/dnnsat/results/$MODEL_NAME/ --net_name=$MODEL_NAME
