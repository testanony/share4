import os
import click
import sys
#sys.path.append("..") 
#from logger import logger
import logging
import subprocess
import json
def list_folders(dir):
    subdirs = [x[0] for x in os.walk(dir)]
    return subdirs


HELP_VERBOSE = 'Whether to display debug level log messages.'
HELP_DEVICE_NAME = 'Device to estimate.'
logger = logging.getLogger('root')
FORMAT = "[%(filename)s:%(lineno)s - %(funcName)20s() ] %(message)s"
logging.basicConfig(stream=sys.stdout, format=FORMAT)
logger.setLevel(logging.DEBUG)

@click.group()
@click.option('--verbose', is_flag=True, help=HELP_VERBOSE)
def cli(verbose):
    if verbose:
        logger.setLevel(logging.DEBUG)
        
@cli.command()
@click.option('--input_folder',  default='/home/testcluster/zhengxian/dnncost/dnnsat/sample/pytorch/vgg_16_all/')
@click.option('--output_folder', default='/home/testcluster/zhengxian/dnncost/dnnsat/results/pt_vgg_16_total/')
@click.option('--net_name', default= "vgg_16")
def entry(input_folder, output_folder, net_name):
    if not os.path.exists(output_folder):
        os.mkdir(output_folder)
    print("input_folders: ", input_folder)
    sub_folders = list_folders(input_folder)
    #print("sub folders: ", sub_folders)
    total_cnt = len(sub_folders)
    processes = []
    output_folders = []
    print("in pythia code")
    if False:
        for folder in sub_folders:
            base_name = os.path.basename(folder)
            if base_name != "":
                sub_out_folder = output_folder + base_name
                mkdir_cmd = "mkdir {}".format(sub_out_folder)
                run_cmd = "python3 main.py {}/{}.json --device_name=TITAN_X \
                                        --output_folder={} \
                                        >> {}/log".format(
                                        folder, net_name, sub_out_folder, sub_out_folder)
                cmd = mkdir_cmd + ";" + run_cmd
                print(cmd)
                p = subprocess.Popen(cmd,
                                    shell=True,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT)
                p.stdout.close()
                processes.append(p)
        for p in processes:
            p.wait()
    stat_dict = dict()
    cnt = 0
    extra_catched_error = 0
    un_catched_error    = 0
    actual_negative     = 0
    actual_positive     = 0
    false_positive      = 0
    true_positive       = 0
    true_negative       = 0
    false_negative      = 0
    error_count = 0
    all_count = 0
    for folder in sub_folders:
        all_count += 1
        base_name = os.path.basename(folder)
        sub_out_folder = output_folder + base_name
        if base_name != "":
            net_file = folder + "/{}.json".format(net_name)
            with open(net_file, 'r') as f:
                data = json.load(f)
                if "exception" in data:
                    actual_negative += 1
                    if data["pythia_detect_error"] == False:
                        error_count += 1
                        false_positive += 1
                        un_catched_error += 1
                    else:
                        true_negative += 1
                else:
                    actual_positive += 1
                    if data["pythia_detect_error"] == False:
                        true_positive += 1
                    else:
                        false_negative += 1
                        extra_catched_error += 1
                        error_count    += 1
            
    stat_dict['extra_catched_error'] = extra_catched_error
    stat_dict['un_catched_error']    = un_catched_error
    stat_dict['error_rate'] = round(float((cnt+1)/total_cnt), 2)
    if actual_positive != 0:
        true_positive_rate  = float(float(true_positive)/float(actual_positive))
        false_negative_rate = float(float(false_negative)/float(actual_positive))
    else:
        true_positive_rate  = -100
        false_negative_rate = -100
    if actual_negative != 0:
        false_positive_rate = float(float(false_positive)/float(actual_negative))
        true_negative_rate  = float(float(true_negative)/float(actual_negative))
    else:
        false_positive_rate = -100
        true_negative_rate  = -100
    stat_dict = dict()
    stat_dict['total_cases'] = all_count
    stat_dict['true_positive']       = true_positive
    stat_dict['actual_positive']     = actual_positive
    stat_dict['false_positive']      = false_positive
    stat_dict['false_negative']      = false_negative
    stat_dict['true_negative']       = true_negative
    stat_dict['actual_negative']     = actual_negative
    stat_dict['true_positive_rate']  = true_positive_rate
    stat_dict['false_positive_rate'] = false_positive_rate
    stat_dict['true_negative_rate']  = true_negative_rate
    stat_dict['false_negative_rate'] = false_negative_rate
    stat_file = output_folder + '/stat_pythia.json'
    with open(stat_file, 'w') as f:
        json.dump(stat_dict, f, indent=4)
    #stat(sub_folders, output_folder)

if __name__ == '__main__':
    #sub_folders = list_folders("/home/testcluster/zhengxian/dnncost/dnnsat/sample/pytorch/vgg_13_total/")
    print("in entry")
    entry()
