"""Graph Representation of Deep Neural Network Architecture."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import json
from logger import logger
from paleo import layers
from dnnsat.utils import ir_op_set
use_mmdnn_shape_infer = False


class LayerSpec(object):
    """The specification of layers/operations in the DNN."""
    def __init__(self, layer_name, layer_params):
        super(LayerSpec, self).__init__()
        self.name = layer_name
        self.params = dict(layer_params)
        self.layer_op = None
        self.parents = [
        ]  # TODO: deprecate this property. Used at forward pass
        self.children = []  # TODO: Used at backward pass.
        self.inbounds = []
        self.outbounds = []
        self.predecessors = set()

    def attach_op(self, layer_op):
        self.layer_op = layer_op

    def __repr__(self):
        return self.name

    def __hash__(self):
        return hash(self.name)

    def __getitem__(self, key):
        return self.params[key]

    @property
    def device_id(self):
        if '@' in self.name:
            return self.name.split('@')[1]
        else:
            # By default, the layer is run on device 0.
            return 0

    def get(self, key, default):
        return self.params.get(key, default)


class OperationGraph(object):
    """The dependency graph of operations in the DNN."""
    def __init__(self, filename=None, net=None, attach_ops=True):
        super(OperationGraph, self).__init__()
        self.nested_list = None
        self._topological_order = None
        self.attach_ops = attach_ops
        self.subgraph_id_pairs = []
        if filename:
            self.load(filename)
        if net and not filename:
            self._create_graph(net)

    def load(self, filename):
        """Load the neural net architecture from JSON format.

            Convert the neural net into a list.
            Arrange the layers into multiple groups,
            such that the next group depend on the previous group.
              [(a), (b, c), (d)]
              [(a), ([b, c], [d, e]), (f)]

            Each node is LayerSpec object.
        """
        with open(filename, 'r') as f:
            net = json.load(f)
        self._create_graph(net)

    def load_from_string(self, string):
        net = json.loads(string)
        self._create_graph(net)

    @property
    def topology_order(self):
        return self._topological_order

    def _create_topology_order(self):
        """
        Expand the network to a plain list.
        The list is in topology order.
        """
        logger.debug('Creating topological order of layers '
                     'based on the nested list representation.')

        def flatten(layer):
            if isinstance(layer, (tuple, list)):
                _layer_list = []
                for l in layer:
                    _layer_list.extend(flatten(l))
                return _layer_list
            else:
                return [layer]

        logger.debug("self.nested_list {} ".format(self.nested_list))
        if self._topological_order is None:
            self._topological_order = []
            for layer in self.nested_list:
                self._topological_order.extend(flatten(layer))
    
    def _attach_layer_op_for_bert(self):
        """Flatten the list in topology order."""
        names_to_specs = dict()
        for layer_spec in self.topology_order:
            if layer_spec['type'] == 'Input' or layer_spec[
                            'type'] == 'Constant':
                inputs = [layer_spec['tensor']]
            else:
                inputs = []

            if len(layer_spec['parents']) == 1:
                parent_name = layer_spec['parents'][0]
                if parent_name == 'fake_input':
                    input_ranks = len(layer_spec['tensor'])
                else:
                    input_ranks = [names_to_specs[parent_name].layer_op.outrank]
            else:
                input_ranks = []
                try:
                    for parent_name in layer_spec['parents']:
                        input_ranks.append(
                            names_to_specs[parent_name].layer_op.outrank)
                except KeyError:
                    raise KeyError('Cannot find parent "%s" of "%s"' %
                                   (parent_name, layer_spec.name))

            try:
                layer = None
                logger.debug("layer_spec.params {}".format(layer_spec.params))
                use_mmdnn_shape_infer = False
                # if "attr" in layer_spec.params:
                #     use_mmdnn_shape_infer = True
                #     raise Exception("error _attach_layer_op_for_bert {}".format(layer_spec))

                if use_mmdnn_shape_infer:
                    layer = layers.Generic(layer_spec.name,
                                           layer_spec['tensor'],
                                           layer_spec['type'])
                    layer._layertype = "mmdnn_{}".format(layer.layertype)
                else:
                    if self.is_bert:
                        layer = layers.Generic(layer_spec.name, inputs,
                                               layer_spec['type'])
                        # layer = layers.BertGeneric(layer_spec.name, inputs,
                        #                        layer_spec['type'], input_ranks, layer_spec)
            except Exception as e:
                logger.error('Error when attaching ops for layer %s' %
                             layer_spec.name)
                logger.error('Error when attaching ops for layer inputs %s' %
                             str(inputs))
                logger.exception(e)
                exit()

            if layer:
                logger.debug('Attach layer op: %s inputs: %s  ouputs: %s \
                    layer type: %s layer spec: %s layer parents: %s'                                                   % \
                    (layer.name, layer.inputs, layer.outputs, \
                    layer.layertype, layer_spec, layer_spec.params))
                layer_spec.parents.extend(
                    [names_to_specs[p] for p in layer_spec['parents']])
                layer.parents = layer_spec['parents']
                layer_spec.attach_op(layer)
                names_to_specs[layer_spec.name] = layer_spec

                # add the backprop children properties
                # update childern list
                for p in layer_spec['parents']:
                    names_to_specs[p].children.append(layer_spec)

    def _attach_layer_op(self):
        """Flatten the list in topology order."""
        names_to_specs = dict()
        for layer_spec in self.topology_order:
            if len(layer_spec['parents']) == 1:
                parent_name = layer_spec['parents'][0]
                inputs = names_to_specs[parent_name].layer_op.outputs
            else:
                inputs = []
                inputs_symbol = []
                try:
                    for parent_name in layer_spec['parents']:
                        inputs.append(
                            names_to_specs[parent_name].layer_op.outputs)
                except KeyError:
                    raise KeyError('Cannot find parent "%s" of "%s"' %
                                   (parent_name, layer_spec.name))

            # Unsqueeze and elementwise broadcast need to be supported in generic or make a new type
            # But now, no need to infer shape in this pass 
            try:
                layer = None
                logger.debug("layer_spec.params {}".format(layer_spec.params))
                use_mmdnn_shape_infer = False
                if "attr" in layer_spec.params:
                    use_mmdnn_shape_infer = True

                if use_mmdnn_shape_infer:
                    layer = layers.Generic(layer_spec.name,
                                           layer_spec['tensor'],
                                           layer_spec['type'])
                    layer._layertype = "mmdnn_{}".format(layer.layertype)
                else:
                    if layer_spec['type'] == 'Input' or layer_spec[
                            'type'] == 'Constant':
                        logger.debug("layer_spec {}".format(layer_spec))
                        layer = layers.Input(layer_spec.name,
                                             layer_spec['tensor'])
                    # elif self.is_bert:
                    #     layer = layers.Generic(layer_spec.name, inputs,
                    #                            layer_spec['type'])
                    elif layer_spec['type'] == 'Convolution':
                        filters = layer_spec['filter']
                        if filters[2] == -1:
                            filters[2] = names_to_specs[parent_name].layer_op.\
                                outputs[-1]
                        logger.debug("filters {}, inputs {}".format(
                            filters, inputs))
                        #for linear conv there isn't padding for conv
                        try:
                            padding = layer_spec['padding']
                        except:
                            padding = [0,0,0,0,0,0,0,0]
                        layer = layers.Conv2d(
                            layer_spec.name,
                            inputs,
                            #layer_spec['filter'],
                            filters,
                            layer_spec['strides'],
                            padding,
                            backprop=('data' not in layer_spec['parents']),
                            activation_fn=layer_spec.get(
                                'activation_fn', 'relu'),
                            normalizer_fn=layer_spec.get(
                                'normalizer_fn', 'no'),
                            splits=layer_spec.get('splits', None))
                    elif layer_spec['type'] == 'Deconvolution':
                        layer = layers.Deconv2D(
                            layer_spec.name,
                            inputs,
                            layer_spec['filter'],
                            layer_spec['strides'],
                            layer_spec['padding'],
                            layer_spec['output_shape'],
                            backprop=('data' not in layer_spec['parents']),
                            activation_fn=layer_spec.get(
                                'activation_fn', 'relu'))
                    elif layer_spec['type'] == 'Pooling':
                        try:
                            ksize = layer_spec['ksize']
                        except Exception as e:
                            logger.debug("pooling doesn't have ksize, so we set a default value for it")
                            ksize = [0,0,0,0]
                        layer = layers.Pool2d(
                            layer_spec.name,
                            inputs,
                            ksize,
                            layer_spec['strides'],
                            layer_spec['padding'],
                            pool_type='max',
                            normalizer_fn=layer_spec.get(
                                'normalizer_fn', None),
                        )
                    elif layer_spec['type'] == 'UpSampling2D':
                        layer = layers.UpSampling2D(layer_spec.name, inputs,
                                                    layer_spec['ksize'])
                    elif layer_spec['type'] == 'AvgPool':
                        layer = layers.Pool2d(layer_spec.name,
                                              inputs,
                                              layer_spec['ksize'],
                                              layer_spec['strides'],
                                              layer_spec['padding'],
                                              pool_type='avg')
                    elif layer_spec['type'] == 'Dropout':
                        layer = layers.Dropout(layer_spec.name, inputs,
                                               layer_spec['dropout_keep_prob'])
                    elif layer_spec['type'] == 'Concatenate':
                        layer = layers.Concatenate(layer_spec.name, inputs,
                                            layer_spec['dim'], layer_spec.\
                                                get('concat_type', 'Concatenate'), \
                                            layer_spec.get('loop_count', 1))
                        logger.debug("concatenate inputs {}".format(
                            str(inputs)))
                    elif layer_spec['type'] == 'Reshape':
                        layer = layers.Reshape(layer_spec.name, inputs,
                                               layer_spec['output_shape'])
                    elif layer_spec['type'] == 'Softmax':
                        layer = layers.Softmax(layer_spec.name, inputs, \
                                                num_classes = layer_spec.\
                                                get('num_classes', None))
                    elif layer_spec['type'] == 'Elementwise' or \
                        layer_spec['type'].lower() in ir_op_set.elementwise:
                        logger.info('ls debug info: elementwise name is {} type is {} inputs is {} '\
                            .format(layer_spec['type'], layer_spec.name, inputs))
                        layer = layers.Elementwise(layer_spec.name, inputs)
                    elif layer_spec['type'] == 'Sigmoid' or \
                        layer_spec['type'].lower() in ir_op_set.activation:
                        layer = layers.Sigmoid(layer_spec.name, inputs)
                    elif layer_spec['type'] == 'InnerProduct':
                        layer = layers.InnerProduct(layer_spec.name, inputs,
                                                    layer_spec['num_outputs'])
                    elif layer_spec['type'] == 'Flatten':
                        layer = layers.Flatten(layer_spec.name, inputs,
                                               layer_spec['type'])
                    elif layer_spec['type'].lower() in ir_op_set.rnn:
                        layer = layers.RNN(
                            layer_spec.name,
                            [layer_spec['batch'], layer_spec['input_size'], 1],
                            layer_spec['type'], layer_spec['seq_len'],
                            layer_spec['num_layers'],
                            layer_spec['num_directions'],
                            layer_spec['hidden_size'],
                            layer_spec['output_dim'])
                    # No need to support shape inference here for those ops in BERT
                    # elif layer_spec['type'] == 'Unsqueeze':
                    #     layer = layers.Unsqueeze(layer_spec.name, inputs, 
                    #                            layer_spec['type'], layer_spec['axes'][0])
                    else:
                        layer = layers.Generic(layer_spec.name, inputs,
                                               layer_spec['type'])

                # for MMdnn parsed model
                # if (layer._outputs is None or layer._outputs == []) and
                # if "tensor" in layer_spec:
                #     layer._outputs = layer_spec["tensor"]
                # if "attr" in layer_spec and "_output_shapes" in layer_spec["attr"]:
                #     dim = layer_spec["attr"]["_output_shapes"]["list"]["shape"][0]["dim"]
                #     for i in dim:
                #         layer._outputs.append(i)
                #  else:
                #      raise ValueError('Cannot create layer object for %s,'
                #                       '%s is an unknown layer type.' %
                #                       (layer_spec.name, layer_spec['type']))
            except Exception as e:
                logger.error('Error when attaching ops for layer %s' %
                             layer_spec.name)
                logger.error('Error when attaching ops for layer inputs %s' %
                             str(inputs))
                logger.exception(e)
                exit()

            if layer:
                logger.debug('Attach layer op: %s inputs: %s  ouputs: %s \
                    layer type: %s layer spec: %s layer parents: %s'                                                   % \
                    (layer.name, layer.inputs, layer.outputs, \
                    layer.layertype, layer_spec, layer_spec.params))
                layer_spec.parents.extend(
                    [names_to_specs[p] for p in layer_spec['parents']])
                layer.parents = layer_spec['parents']
                layer_spec.attach_op(layer)
                names_to_specs[layer_spec.name] = layer_spec

                # add the backprop children properties
                # update childern list
                for p in layer_spec['parents']:
                    names_to_specs[p].children.append(layer_spec)

    def _create_graph(self, net):
        names_to_specs = dict()  # layer_name -> LayerSpec object
        # Shortcuts, allow use block_name as parent.
        block_endpoints = dict()

        # This dictionary records how many splits each end_point name has.
        layernames_to_splits = dict()

        def _parents(parents, current_split=None):
            # Replace with endpoint if parent is a block.
            transformed_parents = []
            for parent_name in parents:
                # We don't support pointing to specific split.
                if '@all' in parent_name:
                    parent_name = parent_name.replace('@all', '')
                    splits = layernames_to_splits[parent_name]
                    for s in range(splits):
                        transformed_parents.append(
                            block_endpoints.get(parent_name, parent_name) +
                            ('@%d' % s))
                elif '@self' in parent_name:
                    parent_name = parent_name.replace('@self', '')
                    assert parent_name in layernames_to_splits, (
                        'Parent %s is not split.')
                    transformed_parents.append(
                        block_endpoints.get(parent_name, parent_name) +
                        '@%d' % current_split)
                else:
                    transformed_parents.append(
                        block_endpoints.get(parent_name, parent_name))
            return transformed_parents

        self.is_bert = False
        if 'node' in net:
            self.is_bert = True
            logger.debug('ls Found node in the first level. Then the input is another format.')
            important_attr = ['axes', 'axis', 'shape', 'perm']
            has_tensor = ['Input', 'Reshape', 'Constant']
            for each in net['node']:
                # logger.debug('ls layer name {} layer type {}'.format(each['name'], each['op']))
                layer_name = each['name']
                layer_params = dict()
                layer_params['type'] = 'Input' if each['op'] == 'DataInput' else each['op']
                layer_params['parents'] = []

                if 'input' in each:
                    input_list = each['input']
                    layer_params['parents'] = _parents(input_list)
                assert 'attr' in each
                attrs = each['attr']
                
                for attr_name, attr_params in attrs.items():
                    if attr_name in important_attr:
                        if 'list' in attr_params:
                            layer_params[attr_name] = list(map(int, attr_params['list']['i']))
                        else:
                            layer_params[attr_name] = list(map(int, attr_params['i']))
                    if attr_name == '_output_shapes' and layer_params['type'] in has_tensor:
                        tensor_shape = list()
                        shape_dim = attr_params['list']['shape'][0]['dim']
                        for each_dim in shape_dim:
                            tensor_shape.append(each_dim['size'])
                        tensor_shape = list(map(int, tensor_shape))
                        if layer_params['type'] == 'Reshape':
                            layer_params['shape'] = tensor_shape
                        else:
                            layer_params['tensor'] = tensor_shape
                
                layer = LayerSpec(layer_name, layer_params)
                assert layer_name not in names_to_specs, ('Duplicate %s' %
                                                          layer_name)
                names_to_specs[layer_name] = layer
        else:
            # First count split.
            # input fisrt level only has "name" & ""layers
            for layer_name, layer_params in net['layers'].items():
                # by now, don't consider
                if layer_params.get('type', None) == 'ModelParallel':
                    block_name = layer_name
                    num_splits = layer_params.get('splits', 1)
                    for sublayer_name in layer_params['layers']:
                        layernames_to_splits['%s/%s' %
                                            (block_name,
                                            sublayer_name)] = num_splits

            # Transform all specs into LayerSpec objects.
            for layer_name, layer_params in net['layers'].items():
                #if layer_params.get('type', None) in ['Block', 'ModelParallel']:
                if layer_params.get('type', None) in ['Block', 'If', 'Loop', \
                    'ModelParallel']:
                    is_model_parallel = (layer_params['type'] == 'ModelParallel')
                    block_name = layer_name
                    block_parents = _parents(layer_params['parents'])

                    # For model parallel, the specified layers are repeated.
                    num_splits = layer_params.get('splits', 1)

                    for s in range(num_splits):
                        for sublayer_name, sublayer_params in layer_params[
                                'layers'].items():
                            sublayer_name = '%s/%s' % (block_name, sublayer_name)
                            if is_model_parallel:
                                sublayer_name = sublayer_name + ("@%d" % s)
                                sublayer_params['splits'] = num_splits

                            sublayer = LayerSpec(sublayer_name, sublayer_params)

                            # Update parents
                            if len(sublayer_params['parents']) == 0:
                                # Use the parent of the block.
                                sublayer_parents = block_parents
                            else:
                                # Add blockname to the parent names.
                                sublayer_parents = map(
                                    lambda n: '%s/%s' % (block_name, n),
                                    sublayer_params['parents'])
                                sublayer_parents = _parents(sublayer_parents, s)

                            sublayer.params['parents'] = sublayer_parents

                            assert sublayer_name not in names_to_specs, (
                                'Duplicate %s' % sublayer_name)
                            names_to_specs[sublayer_name] = sublayer

                    # If block provides an endpoint, subsequent layers can
                    # refer to the block name as parent.
                    if 'endpoint' in layer_params:
                        block_endpoints[block_name] = '%s/%s' % (
                            block_name, layer_params['endpoint'])
                else:
                    logger.debug("layer_name {} \
                        layer_params {}".format(layer_name, layer_params))
                    layer_params['parents'] = _parents(layer_params['parents'])
                    logger.debug('ls want to find what is in parents' + str(layer_params['parents']))
                    layer = LayerSpec(layer_name, layer_params)
                    assert layer_name not in names_to_specs, ('Duplicate %s' %
                                                            layer_name)
                    names_to_specs[layer_name] = layer

        logger.debug("names_to_specs {}".format(names_to_specs))

        # And judge the input type, make it more general
        input_layer_names = []  #["data"]
        for layer_name, layer_spec in names_to_specs.items():
            # if "Input" in layer_spec["type"]:
            if "Input" in layer_spec["type"] or layer_spec[
                    "parents"] == []:  # extend to constant
                logger.debug(
                    "layer spec test {}".format(layer_name +
                                                layer_spec["type"] + "\n"))
                #input_layer_name = layer_name
                input_layer_names.append(layer_name)
            # NOTE: Some IR layer spec parents not exist, remove and igore it.
            for parent_name in _parents(layer_spec['parents']):
                # assert parent_name in names_to_specs, (
                #     'Parent layer %s of %s '
                #     'does not have a LayerSpec object.' % (parent_name,
                #                                            layer_name))
                if parent_name not in names_to_specs:
                    logger.debug(
                        'Parent layer %s of %s does not have a LayerSpec \
                        object.' % (parent_name, layer_name))
                    continue
                names_to_specs[parent_name].outbounds.append(layer_spec)
                layer_spec.inbounds.append(names_to_specs[parent_name])

        # Construct share fake inputs: reduce to 1 input graph
        import copy
        logger.debug("input_layer_names {}".format(input_layer_names))
        # Reduce multi input graphs to 1 input graphs (e.g. BERT)
        if len(input_layer_names) > 1:
            layer_name = "fake_input"
            fake_input_spec = LayerSpec(
                layer_name, {
                    'name': layer_name,
                    'parents': [],
                    'type': "Input",
                    'tensor': [],
                    'attr': {}
                })
            #copy.deepcopy(names_to_specs[input_layer_names[0]])
            fake_input_spec.name = layer_name
            names_to_specs[layer_name] = fake_input_spec

            # for every input, get in_spec, set parent of in_spec to fake_input
            for i in input_layer_names:
                in_spec = names_to_specs[i]
                fake_input_spec.outbounds.append(in_spec)
                in_spec.inbounds.append(fake_input_spec)
                in_spec.parents = [fake_input_spec]
                logger.debug("in_spec {}, fake_input_spec {}".format(
                    in_spec, fake_input_spec))
            # now only fake_input is input_layer
            input_layer_names = [layer_name]

        if self.nested_list == None:
            self.nested_list = []

        # init : joints store all the indegree is more than 1
        graphwalker = GraphWalker(names_to_specs)

        for input_layer_name in input_layer_names:
            traversal_list = graphwalker.start(
                names_to_specs[input_layer_name])
            logger.debug("self.nested_list {} input layer name {} traversal list {}"\
                .format(self.nested_list, input_layer_name, traversal_list))
            self.nested_list = self.nested_list + traversal_list

        logger.debug("self.nested_list {}".format(self.nested_list))
        self._create_topology_order()

        self._get_subgraph_id_pairs(names_to_specs)

        logger.debug("self.nested_list {}".format(self.nested_list))
        logger.debug("self._topological_order {}".format(
            self._topological_order))

        debug_dump_dict = dict()
        if names_to_specs:
            debug_dump_dict['name'] = 'debug test bert model'
            debug_dump_dict['layers'] = dict()
            for layer_name, layer_params in names_to_specs.items():
                debug_dump_dict['layers'][layer_name] = layer_params.params
        # with open('tests/dump-debug.json', 'w') as f:
        #     json.dump(debug_dump_dict, f, indent=2)

        if self.attach_ops and self.is_bert:
            self._attach_layer_op_for_bert()
        elif self.attach_ops:
            self._attach_layer_op()

    def _get_subgraph_id_pairs(self, names_to_nodes):
        S = []
        L = []
        for name, node in names_to_nodes.items():
            node.left_in_edges = len(node.inbounds)
            if len(node.inbounds) == 0:
                node.predecessors.add(name)
                S.append(node)

        # only caculate the big circle
        while (len(S)):
            n = S.pop(0)
            L.append(n.name)
            n_out_size = len(n.outbounds)
            for m in n.outbounds:
                m.left_in_edges -= 1
                if n_out_size > 1:
                    if len(m.predecessors):
                        m.predecessors = m.predecessors & (
                            (n.predecessors) | set([n.name]))
                    else:
                        m.predecessors = (n.predecessors) | set([n.name])
                else:
                    if len(m.predecessors):
                        m.predecessors = m.predecessors & n.predecessors
                    else:
                        m.predecessors = n.predecessors
                if m.left_in_edges == 0:
                    S.append(m)

        for idx in range(len(L) - 1):  #skip the last node.
            n = names_to_nodes[L[idx]]
            if len(n.inbounds) > 1:
                logger.debug("names_to_nodes {}".format(names_to_nodes))
                logger.debug("self._topological_order {}".format( \
                    self._topological_order))
                low_id = max([
                    self._topological_order.index(names_to_nodes[np])
                    for np in n.predecessors
                ])
                self.subgraph_id_pairs.append(
                    (low_id,
                     self._topological_order.index(names_to_nodes[L[idx]])))


class GraphWalker(object):
    def __init__(self, names_to_nodes):
        self.names_to_nodes = names_to_nodes
        self.indegrees = dict()
        self.joints = set()
        for node in names_to_nodes.values():
            self.indegrees[node] = len(node.inbounds)
            if self.indegrees[node] > 1:
                self.joints.add(node)

    def start(self, starting_node):
        nested_list, frontiers = self.nested_list_till_joints([],
                                                              [starting_node])
        # keep investigate joint points for complex graph traversal
        while len(frontiers) != 0:
            logger.debug("frontiers {} nested_list {} frontiers[0].outbounds {}"\
                .format(frontiers, nested_list, frontiers[0].outbounds))
            for f in frontiers:
                self.joints.remove(f)
            nested_list, frontiers = self.nested_list_till_joints(
                nested_list, frontiers)

        return nested_list

    def nested_list_till_joints(self, history, frontiers):
        """Returns current history and encountered joint"""
        if len(frontiers) == 0:
            return history, []

        all_joints = True
        for node in frontiers:
            all_joints = all_joints and (node in self.joints)
        if all_joints:
            return history, frontiers

        if len(frontiers) == 1:
            # Simply chain the layer and continue
            node = frontiers[0]
            history.append(node)
            for x in node.outbounds:
                assert self.indegrees[x] > 0
                self.indegrees[x] -= 1
            frontiers = node.outbounds
            return self.nested_list_till_joints(history, frontiers)
        else:
            # When the frontier has more than one nodes, we explore from each
            # frontier individually until they reach a common joint.
            supernode = []
            merged_joints = set()
            for node in frontiers:
                # The search will stop at joints.
                sub_list, joints = self.nested_list_till_joints([], [node])
                if len(sub_list) > 0:
                    supernode.append(sub_list)
                for joint in joints:
                    if self.indegrees[joint] == 0:
                        merged_joints.add(joint)
            if len(supernode) > 0:
                history.append(tuple(supernode))

            # Reached joints becomes the new frontiers.
            for joint in merged_joints:
                self.joints.remove(joint)
            frontiers = list(merged_joints)
            return self.nested_list_till_joints(history, frontiers)
