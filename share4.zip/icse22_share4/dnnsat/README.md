# Refty 

## Prerequisites

- Python 3.7.x
- z3-solver (tested with 4.8.7.0)
- pyspark (tested with 2.4.5)

## Installation

Refty can be directly executed through source code

1. Download and install Python 3.7.x [here](https://www.python.org/downloads/).

2. Install z3-solver and pyspark

    a. Run installation cmds:

        $ pip3 install --user z3-solver==4.8.7.0

        $ pip3 install --user pyspark==2.4.5  
         
        $ pip3 install --user click

    b. "--user" will install the package into Python "USER_BASE" directory. You could use "python3 -m site" to find where the directory is.
 
    c. Binaries "z3", "pyspark" are placed in the "bin" subfolder of the Python user base directory. Please make sure that it can be searched in $PATH or %Path% .
    
3. Clone Refty

    ``` $ git clone https://github.com/testanony/share4.git```

## Usage

To run, users need to prepare the DL model/IR file, resource constraint, device SKU.

#### Bulk Mode

1. Prepare DL model IR JSON file (e.g. [vgg16.json](nets/vgg16.json)) which contains the computation graph and init hyperparameters. 

```$ model.json```


***NOTE***: We provide a parser for parsing DL model file to the IR JSON file which was built upon MMdnn. 

2. Prepare the search space JSON file (e.g. [vgg16_search_space.json](nets/vgg16_search_space.json)) which contains the hyperparameters options and resource constraints.

```$ search_space.json```

3. Run and prune

For example VGG-16 search space pruning: 
```$ 
mkdir results
mkdir results/vgg16

python3 main.py nets/vgg16.json \ # DL model IR file
    --device_name=TITAN_X \ 
    --output_folder=results/vgg16 \
    --search_space_path=nets//vgg16_search_space.json >> results/vgg16/log
```

Refty will generate results at the folder:

```
dnnsat_global_statistic.txt # Contains search space pruning statistics.
sub_search_space_xx_xx_statistics.txt # Contains satisfied hyperparameters.
log # Contains debugging log.
```

sub_search_space_xx_xx_statistics.txt contains SAT hyperparameter combinations.
```
...
[test z3 solving] *** return the 75 model *** ...
fc6_stride_2 = 1
pool2_kernel_2 = 2
conv3-2_input_1 = 55
pool2_same_padding = 1
fc6_filter_2 = 512
conv5-2_filter_3 = 512
...
```

#### Individule Mode

Prepare DL model IR JSON and constraint. 



```python
net = json.loads("""{ \
          ... 
          }""")
search_space = json.loads("""{ \
          ...
          }""")
device_name = "P40"

dnnsat = DnnSAT(net=net)
result = dnnsat.check(device_name=device_name, search_space=search_space)
print("check result {}".format(result))
```

Then check by DnnSAT interactive mode.

```bash
$ python tests/interactive_test.py
```

```bash
check result sat
```

Analysis more DL model IR from the DL model file by front-end parser. For example [dnnsat/utils/parse_dl_model_test.py](dnnsat/utils/parse_dl_model_test.py)

Currently, Refty supported IR operators are listed at [ir_op_set.py](dnnsat/dnnsat/utils/ir_op_set.py)


#### Test suite

##### Interactive mode

- Scripts

```
python tests/interactive_api_vgg16.py
```

- Inputs 

ir cfg: at code

search space: at code

- Ouputs


##### Pruning mode

- Scripts

```
./tests/vgg16_1_c_test.sh
```

This shell contains:

```
NET_FOLDER=nets
NET_FILE=nets/vgg16.json
OUT_FOLDER=results/vgg16
OUT_FILE=results/vgg16/log
mkdir results
mkdir $OUT_FOLDER

python3 main.py $NET_FILE \
    --device_name=TITAN_X \
    --output_folder=$OUT_FOLDER \
    --search_space_path=$NET_FOLDER/vgg16_search_space_1_constraint.json >> $OUT_FILE
```

- Inputs 

ir graph: NET_FILE=nets/vgg16.json
search space: $NET_FOLDER/vgg16_search_space_1_constraint.json

- Ouputs

--output_folder=$OUT_FOLDER constains serveral files:

```
# search pruning statistics:
dnnsat_global_statistic.txt
# logs for debug:
log.txt 
# parallel solving: each sub search space solutions
sub_search_space_0_statistics.txt
# parallel solving: each sub search space solving speed statistics
solving_speed_of_sub_searh_space_0.txt
```

