"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn
import numpy as np
import onnx
from typing import Sequence

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """

    def test_concat_output_shape(self):
        test_cases = {
            '1d': ([1, 2],
                [3, 4]),
            '2d': ([[1, 2], [3, 4]],
                [[5, 6], [7, 8]]),
            '3d': ([[[1, 2], [3, 4]], [[5, 6], [7, 8]]],
                [[[9, 10], [11, 12]], [[13, 14], [15, 16]]])
        }  # type: Dict[Text, Sequence[Any]]

        for test_case, values_ in test_cases.items():
            values = [np.asarray(v, dtype=np.float32) for v in values_]
            # print(values)
            for i in range(len(values[0].shape)):
                in_args = ['value' + str(k) for k in range(len(values))]
                node = onnx.helper.make_node(
                    'Concat',
                    inputs=[s for s in in_args],
                    outputs=['output'],
                    axis=i
                )
                result = onnx_node_shape_infer(node, inputs=[v for v in values], name='test_concat_' + test_case + '_axis_' + str(i))
                output_shape = _concate_output_shape([list(v.shape) for v in values], i)                
                self.assertListEqual(output_shape, result[0])

            for i in range(-len(values[0].shape), 0):
                in_args = ['value' + str(k) for k in range(len(values))]
                node = onnx.helper.make_node(
                    'Concat',
                    inputs=[s for s in in_args],
                    outputs=['output'],
                    axis=i
                )
                result = onnx_node_shape_infer(node, inputs=[v for v in values], name='test_concat_' + test_case + '_axis_negative_' + str(abs(i)))
                j = i % len(values[0].shape)
                output_shape = _concate_output_shape([list(v.shape) for v in values], j)
                self.assertListEqual(output_shape, result[0])

    # def test_concat_sequence_output_shape(self):
    #     test_cases = {
    #         '1d': ([1, 2],
    #             [3, 4]),
    #         '2d': ([[1, 2], [3, 4]],
    #             [[5, 6], [7, 8]]),
    #         '3d': ([[[1, 2], [3, 4]], [[5, 6], [7, 8]]],
    #             [[[9, 10], [11, 12]], [[13, 14], [15, 16]]])
    #     }  # type: Dict[Text, Sequence[Any]]

    #     for test_case, values_ in test_cases.items():
    #         values = [np.asarray(v, dtype=np.float32) for v in values_]
    #         # print(values)
    #         for i in range(len(values[0].shape)):
    #             in_args = ['value' + str(k) for k in range(len(values))]
    #             node = onnx.helper.make_node(
    #                 'ConcatFromSequence',
    #                 inputs=[s for s in in_args],
    #                 outputs=['output'],
    #                 axis=i
    #             )
    #             result = onnx_node_shape_infer(node, inputs=Sequence[[v for v in values]], name='test_concat_sequence_' + test_case + '_axis_' + str(i))
    #             output_shape = _concate_output_shape([list(v.shape) for v in values], i)
    #             # self.assertListEqual(output_shape, result[0])

    #         for i in range(-len(values[0].shape), 0):
    #             in_args = ['value' + str(k) for k in range(len(values))]
    #             node = onnx.helper.make_node(
    #                 'ConcatFromSequence',
    #                 inputs=[s for s in in_args],
    #                 outputs=['output'],
    #                 axis=i
    #             )
    #             result = onnx_node_shape_infer(node, inputs=Sequence[[v for v in values]], name='test_concat_sequence_' + test_case + '_axis_negative_' + str(abs(i)))
    #             j = i % len(values[0].shape)
    #             output_shape = _concate_output_shape([list(v.shape) for v in values], j)
    #             # self.assertListEqual(output_shape, result[0])

if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from onnx_shape_infer import onnx_node_shape_infer
    from dnnsat.dnnsat.shape_inference import _concate_output_shape
    unittest.main(verbosity=2)