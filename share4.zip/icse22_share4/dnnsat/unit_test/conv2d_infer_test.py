"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions Pytorch version]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """
        self.inputs = [128, 224, 224, 3]
        self._inputs = torch.randn(128, 3, 224, 224)
        self.filters = [3, 3, 3, 64]
        self.strides = [1, 1, 1, 1]
        self.padding = [0, 1] 
        # self.padding = "SAME"
        self.kernel = [3, 3, 1, 1]

        self.concat_dim = 0

        self.transpose_dim1 = 0
        self.transpose_dim2 = 1

        self.reshape_new_shape = [128, 3, 224, 224]

    def test_conv2d_output_shape(self):
        """[Test conv2d shape infer]
        """
        outputs = _conv2d_output_shape(self.inputs, 
                                        _filters = self.filters,
                                        _strides = self.strides,
                                        _padding = self.padding 
                                        )

        padding_size = self.padding[1] * 1
        test_layer = nn.Conv2d(in_channels=3, out_channels=self.filters[-1],\
             kernel_size=(self.filters[1], self.filters[2]), stride=(self.strides[1],\
             self.strides[2]), padding=(padding_size, padding_size)) 
        _output = test_layer(self._inputs)
        # print(self.filters[-1])
        # print(outputs)
        # print(_output.shape)
        self.assertListEqual(outputs, [128, 224, 224, 64])



if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from paleo.solver.shape_inference import _conv2d_output_shape
    unittest.main(verbosity=2)