"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn
import numpy as np
import onnx

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """

    def test_conv_output_shape(self):
        input_shape = [1, 3, 28, 28]
        w_shape = [64, 3, 3, 3]
        node = onnx.helper.make_node(
            'Conv',
            inputs=['x', 'w'],
            outputs=['y'],
            pads=[2, 2, 2, 2],
            count_include_pad=1,
            strides=[1,1],
            dilations=[3,3]
        )
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        w_data = np.random.uniform(-10, 10, w_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data, w_data], name='test_Conv_keepdims_example')
        output_shape = ConvPool(input_shape, w_shape, [1, 1], [2, 2], [3, 3]).infer()
        # output_shape = _convpool_output_shape(input_shape, w_shape, [1, 1], [2, 2], [3, 3])
        self.assertListEqual(output_shape, result[0])

    def test_conv_integer_output_shape(self):
        x = np.array([2, 3, 4, 5, 6, 7, 8, 9, 10]).astype(np.uint8).reshape((1, 1, 3, 3))
        x_zero_point = np.uint8(1)
        w = np.array([1, 1, 1, 1]).astype(np.uint8).reshape((1, 1, 2, 2))

        convinteger_node = onnx.helper.make_node('ConvInteger',
            inputs=['x', 'w', 'x_zero_point'],
            outputs=['y'])

        result = onnx_node_shape_infer(convinteger_node, inputs=[x, w, x_zero_point], name='test_basic_convinteger')
        print(result)

        convinteger_node_with_padding = onnx.helper.make_node('ConvInteger',
            inputs=['x', 'w', 'x_zero_point'],
            outputs=['y'],
            pads=[1, 1, 1, 1],)

        result = onnx_node_shape_infer(convinteger_node_with_padding, inputs=[x, w, x_zero_point], name='test_convinteger_with_padding')
        print(result)

    def test_averagepool_output_shape(self):
        input_shape = [1, 3, 28, 28]
        node = onnx.helper.make_node(
            'AveragePool',
            inputs=['x'],
            outputs=['y'],
            kernel_shape=[3, 3],
            pads=[2, 2, 2, 2],
            count_include_pad=1,
            strides=[2,2]
        )
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_averagepool_keepdims_example')
        output_shape = ConvPool(input_shape, [3, 3, 3, 3], [2, 2], [2, 2], [1, 1]).infer()
        # output_shape = _convpool_output_shape(input_shape, [3, 3, 3, 3], [2, 2], [2, 2], [1, 1])
        self.assertListEqual(output_shape, result[0])
        # print(result)

    def test_globalaveragepool_output_shape(self):
        input_shape = [1, 3, 5, 5]
        node = onnx.helper.make_node(
            'GlobalAveragePool',
            inputs=['x'],
            outputs=['y'],
        )
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_globalaveragepool_example')
        output_shape = GlobalAveragePool(input_shape).infer()
        self.assertListEqual(output_shape, result[0])

    def test_globallppool_output_shape(self):
        input_shape = [1, 3, 5, 5]
        node = onnx.helper.make_node(
            'GlobalLpPool',
            inputs=['x'],
            outputs=['y'],
        )
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_GlobalLpPool_example')
        output_shape = GlobalAveragePool(input_shape).infer()
        self.assertListEqual(output_shape, result[0])

    def test_globalmaxpool_output_shape(self):
        input_shape = [1, 3, 5, 5]
        node = onnx.helper.make_node(
            'GlobalMaxPool',
            inputs=['x'],
            outputs=['y'],
        )
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_GlobalMaxPool_example')
        output_shape = GlobalAveragePool(input_shape).infer()
        self.assertListEqual(output_shape, result[0])

    def test_lppool_output_shape(self):
        input_shape = [1, 3, 5, 5]
        strides = [2, 2]
        pads = [2, 2, 0, 0]
        kernel_shape = [5, 5]
        node = onnx.helper.make_node(
            'LpPool',
            auto_pad="NOTSET",
            kernel_shape=kernel_shape,
            p=3,
            pads=pads,
            strides=strides,
            inputs=['x'],
            outputs=['y'],
        )
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_LpPool_example')
        kernel_shape = [input_shape[1]]*2 + kernel_shape
        output_shape = ConvPool(input_shape, kernel_shape, strides, pads, [1, 1]).infer()
        self.assertListEqual(output_shape, result[0])


if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from onnx_shape_infer import onnx_node_shape_infer
    # from dnnsat.dnnsat.shape_inference import _convpool_output_shape
    from dnnsat.dnnsat.shape_inference import ConvPool
    from dnnsat.dnnsat.shape_inference import GlobalAveragePool
    unittest.main(verbosity=2)