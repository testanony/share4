"""Using Onnx to infer output shape."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import onnx
from onnx import helper, shape_inference
from onnx import TensorProto
import onnx.utils


def get_shape_list(value_info):
    all_shape_list = []
    for each in value_info:
        shape_list = []
        for dim_shape in each.type.tensor_type.shape.dim:
            shape_list.append(dim_shape.dim_value)
        all_shape_list.append(shape_list)
    return all_shape_list

def onnx_shape_infer(op_name, 
                    input_tensor_name, 
                    input_tensor_shape
                    ):
    assert len(input_tensor_name) == len(input_tensor_shape)
    node = onnx.helper.make_node(
        op_name,
        inputs=input_tensor_name,
        outputs=[op_name+'output']
    )
    # print(node)
    input_tensor_list = []
    for name, shape in zip(input_tensor_name, input_tensor_shape):
         input_tensor_list.append(helper.make_tensor_value_info(name, TensorProto.FLOAT, shape))
    
    graph = helper.make_graph(
        [node],
        'test-'+ op_name,
        input_tensor_list,
        []
    )
    original_model = helper.make_model(graph, producer_name='test-'+ op_name)
    inferred_model = shape_inference.infer_shapes(original_model)
    result = get_shape_list(inferred_model.graph.value_info)
    return result

def _extract_value_info(input, name, ele_type=None):  
    return onnx.helper.make_tensor_value_info(
        name=name,
        elem_type=ele_type if ele_type else onnx.mapping.NP_TYPE_TO_TENSOR_TYPE[input.dtype],
        shape=input.shape)

def onnx_node_shape_infer(node,  # type: onnx.NodeProto
           inputs,  # type: Sequence[np.ndarray]
           name,  # type: Text
           **kwargs  # type: Any
           ):
    present_inputs = [x for x in node.input if (x != '')]
    input_types = [None] * len(inputs)
    if 'input_types' in kwargs:
        input_types = kwargs[str('input_types')]
        del kwargs[str('input_types')]
    inputs_vi = [_extract_value_info(arr, arr_name, input_type)
                 for arr, arr_name, input_type in zip(inputs, present_inputs, input_types)]
    
    # print("inputs_vi is " + str(inputs_vi))
    graph = onnx.helper.make_graph(
        nodes=[node],
        name=name,
        inputs=inputs_vi,
        outputs=[])
    kwargs[str('producer_name')] = 'backend-test'
    original_model = onnx.helper.make_model(graph, **kwargs)
    inferred_model = shape_inference.infer_shapes(original_model)
    # print(inferred_model)
    result = get_shape_list(inferred_model.graph.value_info)
    return result
