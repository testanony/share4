"""parse auto_pad mode"""
