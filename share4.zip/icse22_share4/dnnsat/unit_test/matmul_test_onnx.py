"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn
import numpy as np
import onnx

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """
        

    def test_reduceL1_output_shape(self):
        # data = np.array()
        input_shape = [3, 2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        print("data shape is "+ str(data.shape))
        axis = [2]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceL1',
            inputs=['data'],
            outputs=['result'],
            axis=axis,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceL1_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axis, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceL1_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axis, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from onnx_shape_infer import onnx_node_shape_infer
    from dnnsat.dnnsat.shape_inference import _reducemean_output_shape
    unittest.main(verbosity=2)