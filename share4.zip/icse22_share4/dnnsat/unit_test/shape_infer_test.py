"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os


class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """
        self.inputs = [128, 224, 224, 3]
        self.filters = [3, 3, 3, 64]
        self.strides = [1, 1, 1, 1]
        self.padding = [0, 1]

        self.kernel = [3, 3, 1, 1]

        self.concat_dim = 0

        self.transpose_dim1 = 0
        self.transpose_dim2 = 1

        self.reshape_new_shape = [128, 3, 224, 224]

    def test_conv2d_output_shape(self):
        """[Test conv2d shape infer] TODO
        """
        outputs = _conv2d_output_shape(self.inputs, 
                                        _filters = self.filters,
                                        _strides = self.strides,
                                        _padding = self.padding 
                                        )
        self.assertListEqual(self.layer.outputs, [128, 54, 54, 96])

    def test_pool2d_output_shape(self):
        """[Test pool2d shape infer] TODO
        """
        outputs = _pool2d_output_shape(self.inputs, 
                                        _kernel = self.kernel,
                                        _strides = self.strides,
                                        _padding = self.padding 
                                        )
        self.assertListEqual(outputs, )

    def test_activation_output_shape(self):
        """[Test activation shape infer]
        """
        outputs = _activation_output_shape(self.inputs)
        self.assertListEqual(self.inputs, outputs)

    def test_softmax_output_shape(self):
        """[Test softmax shape infer]
        """
        outputs = _softmax_output_shape(self.inputs)
        self.assertListEqual(outputs, self.inputs)
    
    def test_batchnorm2d_output_shape(self):
        """[Test batchnorm2d shape infer]
        """
        outputs = _batchnorm2d_output_shape(self.inputs)
        self.assertListEqual(outputs, self.inputs)
    
    def test_dropout2d_output_shape(self):
        """[Test dropout2d shape infer]
        """
        outputs = _dropout2d_output_shape(self.inputs)
        self.assertListEqual(outputs, self.inputs)
        
    def test_concate_output_shape(self):
        """[Test concate shape infer]
        """
        outputs = _concate_output_shape([self.inputs, 
                                        self.inputs], 
                                        self.concat_dim)
        self.assertListEqual(outputs, [256, 224, 224, 3])

    def test_squeeze_output_shape(self):
        """[Test squeeze shape infer]
        """
        outputs = _squeeze_output_shape([1,2,3,4,5,1])
        self.assertListEqual(outputs, [2,3,4,5])
        
    def test_transpose_output_shape(self):
        """[Test transpose shape infer]
        """
        outputs = _transpose_output_shape(self.inputs, 1, 3)
        self.assertListEqual(outputs, [128, 3, 224, 224])

    def test_reshape_output_shape(self):
        """[Test reshape shape infer]
        """
        outputs = _reshape_output_shape(self.inputs, [64, 224, 224, 6])
        self.assertListEqual(outputs, [64, 224, 224, 6])

    def test_unsqueeze_output_shape(self):
        """[Test unsqueeze shape infer]
        """
        outputs = _unsqueeze_output_shape(self.inputs, [0])
        self.assertListEqual(outputs, [self.inputs])

    def test_elementwise_output_shape(self):
        """[Test elementwise shape infer]
        """
        outputs = _elementwise_output_shape(self.inputs)
        self.assertListEqual(outputs, self.inputs)

    def test_add_output_shape(self):
        """[Test add shape infer]
        """
        outputs = _add_output_shape([self.inputs, self.inputs])
        self.assertListEqual(outputs, self.inputs)

    def test_rnn_output_shape(self):
        """[Test rnn shape infer] TODO
        """
        outputs = _rnn_output_shape(_seq_len = 128, 
                                    _batch = 64, 
                                    _input_size = 100, 
                                    _num_layers = 2, 
                                    _num_directions = 2, 
                                    _hidden_size = 100)
        self.assertListEqual(outputs, )


if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from paleo.solver.shape_inference import _conv2d_output_shape
    from paleo.solver.shape_inference import _pool2d_output_shape
    from paleo.solver.shape_inference import _activation_output_shape
    from paleo.solver.shape_inference import _softmax_output_shape
    from paleo.solver.shape_inference import _batchnorm2d_output_shape
    from paleo.solver.shape_inference import _dropout2d_output_shape
    from paleo.solver.shape_inference import _concate_output_shape
    from paleo.solver.shape_inference import _squeeze_output_shape
    from paleo.solver.shape_inference import _transpose_output_shape
    from paleo.solver.shape_inference import _reshape_output_shape
    from paleo.solver.shape_inference import _unsqueeze_output_shape
    from paleo.solver.shape_inference import _elementwise_output_shape
    from paleo.solver.shape_inference import _add_output_shape
    from paleo.solver.shape_inference import _rnn_output_shape
    unittest.main(verbosity=2)