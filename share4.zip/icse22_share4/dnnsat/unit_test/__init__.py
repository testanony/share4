"""
Test Suite 
"""
__version__ = '0.1'

import os
from shape_infer_test import Conv2DTest