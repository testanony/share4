import re
import json

def get_shape_info(value_info):
    """[Parser for onnx]

    Args:
        value_info ([str]): [shape infer result of single onnx node]

    Returns:
        [list]: [inferred output shape of onnx]
    """
    pattern = re.compile(r"dim_value: (\d+)")
    result_list = re.findall(pattern, value_info)
    shape_list = []
    for each in result_list:
        shape_list += [int(each)]
    return shape_list

def get_json_from_onnx(value_info):
    pattern1 = re.compile(r"\[name: \"([a-zA-Z]\w*)\"\ntype([^\]]*)\]")
    result, n = re.subn(pattern1, r"{ \1:\2}", value_info)

    pattern2 = re.compile(r"([a-zA-Z]\w*)([^:\w])")
    result, n = re.subn(pattern2, r"\1:\2", result)

    pattern3 = re.compile(r'([a-zA-Z]\w*)')
    result, n = re.subn(pattern3, r'"\1"', result)

    pattern4 = re.compile(r'(\d+|})(\s+")')
    result, n = re.subn(pattern4, r'\1,\2', result)
    
    result = json.loads(result)
    print(result)
    return result
