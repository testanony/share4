# Unit Test for Shape Inference

> should be updated to accord to onnx 1.7.0, right some of the following ops may not match

## High importance

<a href="#bert_op">bert</a>

## Reference

[numpy broadcast](https://github.com/onnx/onnx/blob/master/docs/Broadcasting.md)

## Ideas

1. How to simply describe concatenate input shape dimension and output shape dimension?

## Operators & Functions in ONNX

|**Operator**|**Classification**|memo|
|-|-|-|
|<a href="#Abs">Abs</a>|<a href="#no-change">no-change</a>||
|<a href="#Acos">Acos</a>|<a href="#no-change">no-change</a>||
|<a href="#Acosh">Acosh</a>|<a href="#no-change">no-change</a>||
|<a href="#Add">Add</a>|<a href="#broadcast">broadcast</a>|**multidirectional broadcast**|
|<a href="#And">And</a>|<a href="#broadcast">broadcast</a>|**multidirectional broadcast**|
|<a href="#ArgMax">ArgMax</a>|<a href="#Reduce">Reduce</a>|attr: axis, keepdims|
|<a href="#ArgMin">ArgMin</a>|<a href="#Reduce">Reduce</a>|attr: axis, keepdims|
|<a href="#Asin">Asin</a>|<a href="#no-change">no-change</a>||
|<a href="#Asinh">Asinh</a>|<a href="#no-change">no-change</a>||
|<a href="#Atan">Atan</a>|<a href="#no-change">no-change</a>||
|<a href="#Atanh">Atanh</a>|<a href="#no-change">no-change</a>||
|<a href="#AveragePool">AveragePool</a>|<a href="#pool">pool</a>|<a href="#pool">pool</a> is contrast to <a href="#unpool">unpool</a> , and 1-3 D are all supported|
|<a href="#BatchNormalization">BatchNormalization</a>|<a href="#no-change">no-change</a>|But extra outputs may be needed according to `mode`|
|<a href="#BitShift">BitShift</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#Cast">Cast</a>|<a href="#no-change">no-change</a>|dtype changed|
|<a href="#Ceil">Ceil</a>|<a href="#no-change">no-change</a>||
|<a href="#Celu">Celu</a>|<a href="#no-change">no-change</a>||
|<a href="#Clip">Clip</a>|<a href="#no-change">no-change</a>||
|<a href="#Compress">Compress</a>|<a href="#Compress">Compress</a>|rank: sometimes same as input                                     dimension: changed by condition elements|
|<a href="#Concat">Concat</a>|<a href="#Concate">Concat</a>|a list of input|
|<a href="#ConcatFromSequence">ConcatFromSequence</a>|<a href="#Concate">Concat</a>|a sequence of input and concatenate or stack according to `new_axis`|
|<a href="#Constant">Constant</a>|<a href="#Produce">Produce</a>|No shape infer rules, rules for `sparse_value` and other attributes|
|<a href="#ConstantOfShape">ConstantOfShape</a>|<a href="#Produce">Produce</a>|shape tensor -> output, `value` is not described well|
|<a href="#Conv">Conv</a>|<a href="#Convs">Conv</a>||
|<a href="#ConvInteger">ConvInteger</a>|<a href="#Convs">Conv</a>||
|<a href="#ConvTranspose">ConvTranspose</a>|<a href="#ConvTranspose">ConvTranspose</a>||
|<a href="#Cos">Cos</a>|<a href="#no-change">no-change</a>||
|<a href="#Cosh">Cosh</a>|<a href="#no-change">no-change</a>||
|<a href="#CumSum">CumSum</a>|<a href="#no-change">no-change</a>||
|<a href="#DynamicQuantizeLinear">DynamicQuantizeLinear</a>|<a href="#no-change">no-change</a>||
|<a href="#DepthToSpace">DepthToSpace</a>|<a href="#DepthToSpace">DepthToSpace</a>|[N, C/(blocksize * blocksize), H * blocksize, W * blocksize]|
|<a href="#DequantizeLinear">DequantizeLinear</a>|<a href="#no-change">no-change</a>|`x_scale` and `x_zero_point`, have rank constraints|
|<a href="#Det">Det</a>|<a href="#Det">Det</a>||
|<a href="#Div">Div</a>|<a href="#broadcast">broadcast</a>||
|<a href="#Dropout">Dropout</a>|<a href="#no-change">no-change</a>|return mask|
|<a href="#Einsum">Einsum</a>|<a href="#Einsum">Einsum</a>|this is very hard to implement, Attr includes a string describing an expression|
|<a href="#Elu">Elu</a>|<a href="#no-change">no-change</a>||
|<a href="#Equal">Equal</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#Erf">Erf</a>|<a href="#no-change">no-change</a>||
|<a href="#Exp">Exp</a>|<a href="#no-change">no-change</a>||
|<a href="#Expand">Expand</a>|<a href="#broadcast">broadcast</a>|According to description, <a href="#Expand">Expand</a> is an **multidirectional-broadcast** op, shape & input shape. but shape is an input, which is <a href="#Dynamical">Dynamical</a>|
|<a href="#EyeLike">EyeLike</a>|<a href="#no-change">no-change</a>||
|<a href="#Flatten">Flatten</a>|<a href="#Split C">Split</a>|tensor -> 2D matrix, split by  the attr`axis`, is a specific situation of <a href="#Split">Split</a>|
|<a href="#Floor">Floor</a>|<a href="#no-change">no-change</a>||
|<a href="#GRU">GRU</a>|<a href="#RNN Layer">RNN Layer</a>||
|<a href="#Gather">Gather</a>|<a href="#Gather C">Gather</a>|q + r - 1|
|<a href="#GatherElements">GatherElements</a>|<a href="#Gather C">Gather</a>|r = q|
|<a href="#GatherND">GatherND</a>|<a href="#Gather C">Gather</a>|Start gather from `batch_dims` dimension.|
|<a href="#Gemm">Gemm</a>|<a href="#Gemm">Gemm</a>|**unidirectional broadcasting**, C -> A * B.a little different from <a href="#MatMul">matmul</a> because of supporting transpose|
|<a href="#GlobalAveragePool">GlobalAveragePool</a>|<a href="#pool">pool</a>||
|<a href="#GlobalLpPool">GlobalLpPool</a>|<a href="#pool">pool</a>||
|<a href="#GlobalMaxPool">GlobalMaxPool</a>|<a href="#pool">pool</a>||
|<a href="#Greater">Greater</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#GreaterOrEqual">GreaterOrEqual</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#HardSigmoid">HardSigmoid</a>|<a href="#no-change">no-change</a>||
|<a href="#Hardmax">Hardmax</a>|<a href="#no-change">no-change</a>||
|<a href="#Identity">Identity</a>|<a href="#no-change">no-change</a>||
|<a href="#If">If</a>|<a href="#Dynamical">Dynamical</a>||
|<a href="#InstanceNormalization">InstanceNormalization</a>|<a href="#no-change">no-change</a>|`scale` , `bias` have constraints|
|<a href="#IsInf">IsInf</a>|<a href="#no-change">no-change</a>||
|<a href="#IsNaN">IsNaN</a>|<a href="#no-change">no-change</a>||
|<a href="#LRN">LRN</a>|<a href="#no-change">no-change</a>||
|<a href="#LSTM">LSTM</a>|<a href="#RNN Layer">RNN Layer</a>||
|<a href="#LeakyRelu">LeakyRelu</a>|<a href="#no-change">no-change</a>||
|<a href="#Less">Less</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#LessOrEqual">LessOrEqual</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#Log">Log</a>|<a href="#no-change">no-change</a>||
|<a href="#LogSoftmax">LogSoftmax</a>|<a href="#no-change">no-change</a>||
|<a href="#Loop">Loop</a>|<a href="#Dynamical">Dynamical</a>||
|<a href="#LpNormalization">LpNormalization</a>|<a href="#no-change">no-change</a>|`axis` has  constraints, usual|
|<a href="#LpPool">LpPool</a>|<a href="#pool">pool</a>|`auto_pad` , pad_pattern -> real number,  **global define ** is better;     `pads` determins|
|<a href="#MatMul">MatMul</a>|<a href="#MatMul C">MatMul</a>||
|<a href="#MatMulInteger">MatMulInteger</a>|<a href="#MatMul C">MatMul</a>|`a_zero_point` and `b_zero_point`, have rank constraints|
|<a href="#Max">Max</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#MaxPool">MaxPool</a>|<a href="#pool">pool</a>||
|<a href="#MaxRoiPool">MaxRoiPool</a>|<a href="#MaxRoiPool">MaxRoiPool</a>|`pooled_shape` and `rois` determine output shape, `rois` is given as [[batch_id, x1, y1, x2, y2], ... ]|
|<a href="#MaxUnpool">MaxUnpool</a>|<a href="#Unpool">Unpool</a>|`output_shape` determines `pads`|
|<a href="#Mean">Mean</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#MeanVarianceNormalization">MeanVarianceNormalization</a>|<a href="#no-change">no-change</a>|`axes` has constraints|
|<a href="#Min">Min</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#Mod">Mod</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#Mul">Mul</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#Multinomial">Multinomial</a>|<a href="#Multinomial">Multinomial</a>|[batch_size, sample_size]|
|<a href="#Neg">Neg</a>|<a href="#no-change">no-change</a>||
|<a href="#NegativeLogLikelihoodLoss">NegativeLogLikelihoodLoss</a>|<a href="#Loss">Loss</a>|Input tensor of shape (N, C) or (N, C, d1, d2, ..., dk). output just cuts C column|
|<a href="#NonMaxSuppression">NonMaxSuppression</a>|<a href="#NonMaxSuppression">NonMaxSuppression</a>|`boxes` [num_batches, spatial_dimension, 4], `scores` [num_batches, num_classes, spatial_dimension] -> [num_selected_indices, 3]|
|<a href="#NonZero">NonZero</a>|<a href="#Dynamical">Dynamical</a>|Can not know which are zero|
|<a href="#Not">Not</a>|<a href="#no-change">no-change</a>||
|<a href="#OneHot">OneHot</a>|<a href="#Dynamical">Dynamical</a>|data distribution|
|<a href="#Or">Or</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#PRelu">PRelu</a>|<a href="#broadcast">broadcast</a>|**unidirectional**|
|<a href="#Pad">Pad</a>|<a href="#Pad">Pad</a>|`modes` changes the output shape|
|<a href="#Pow">Pow</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#QLinearConv">QLinearConv</a>|<a href="#Convs">Conv</a>|`auto_pad` `x_scale` ... extra constraints than conv|
|<a href="#QLinearMatMul">QLinearMatMul</a>|<a href="#MatMul">MatMul</a>|`x_scale` ... extra constraints than matmul|
|<a href="#QuantizeLinear">QuantizeLinear</a>|<a href="#no-change">no-change</a>|`y_scale` ... extra constraints|
|<a href="#RNN">RNN</a>|<a href="#RNN Layer">RNN Layer</a>||
|<a href="#RandomNormal">RandomNormal</a>|<a href="#Produce">Produce</a>||
|<a href="#RandomNormalLike">RandomNormalLike</a>|<a href="#Produce">Produce</a>||
|<a href="#RandomUniform">RandomUniform</a>|<a href="#Produce">Produce</a>||
|<a href="#RandomUniformLike">RandomUniformLike</a>|<a href="#Produce">Produce</a>||
|<a href="Range">Range</a>|<a href="#Range">Range</a>, <a href="#Dynamical">Dynamical</a>|output is only 1D, otherwise I can also consider it as <a href="#Produce">Produce</a>. But it is <a href="#Dynamical">Dynamical</a>|
|<a href="#Reciprocal">Reciprocal</a>|<a href="#no-change">no-change</a>||
|<a href="#ReduceL1">ReduceL1</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceL2">ReduceL2</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceLogSum">ReduceLogSum</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceLogSumExp">ReduceLogSumExp</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceMax">ReduceMax</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceMean">ReduceMean</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceMin">ReduceMin</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceProd">ReduceProd</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceSum">ReduceSum</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#ReduceSumSquare">ReduceSumSquare</a>|<a href="#Reduce">Reduce</a>|`keepdims` matters|
|<a href="#Relu">Relu</a>|<a href="#no-change">no-change</a>||
|<a href="#Reshape">Reshape</a>|<a href="#ReShape">ReShape</a>, <a href="#Dynamical">Dynamical</a>|output shape accords to input shape, if it is static sometimes(However)|
|<a href="#Resize">Resize</a>|<a href="#no-change">no-change</a>||
|<a href="#ReverseSequence">ReverseSequence</a>|<a href="#no-change">no-change</a>||
|<a href="#RoiAlign">RoiAlign</a>|<a href="#RoiAlign">RoiAlign</a>||
|<a href="#Round">Round</a>|<a href="#no-change">no-change</a>||
|<a href="#Scan">Scan</a>|<a href="#Scan">Scan</a>||
|<a href="#Scatter">Scatter</a> (deprecated)|same as <a href="#ScatterElements">ScatterElements</a>|**deprecated**|
|<a href="#ScatterElements">ScatterElements</a>|<a href="#no-change">no-change</a>|`indices` `updates` `data` have constraints|
|<a href="#ScatterND">ScatterND</a>|<a href="#no-change">no-change</a>|`indices` `updates` `data` have constraints|
|<a href="#Selu">Selu</a>|<a href="#no-change">no-change</a>||
|<a href="#SequenceAt">SequenceAt</a>|<a href="#Dynamical">Dynamical</a>||
|<a href="#SequenceConstruct">SequenceConstruct</a>|<a href="#Dynamical">Dynamical</a>||
|<a href="#SequenceEmpty">SequenceEmpty</a>|<a href="#ConstantShape">ConstantShape</a>|[ 0 ]|
|<a href="#SequenceErase">SequenceErase</a>|<a href="#Dynamical">Dynamical</a>||
|<a href="#SequenceInsert">SequenceInsert</a>|<a href="#Dynamical">Dynamical</a>||
|<a href="#SequenceLength">SequenceLength</a>|<a href="#ConstantShape">ConstantShape</a>|[ scalar ]|
|<a href="#Shape">Shape</a>|<a href="#ConstantShape">ConstantShape</a>|[ rank ]|
|<a href="#Shrink">Shrink</a>|<a href="#no-change">no-change</a>||
|<a href="#Sigmoid">Sigmoid</a>|<a href="#no-change">no-change</a>||
|<a href="#Sign">Sign</a>|<a href="#no-change">no-change</a>||
|<a href="#Sin">Sin</a>|<a href="#no-change">no-change</a>||
|<a href="#Sinh">Sinh</a>|<a href="#no-change">no-change</a>||
|<a href="#Size">Size</a>|<a href="#ConstantShape">ConstantShape</a>|[ size ]|
|<a href="#Slice">Slice</a>|<a href="#Slice">Slice</a>, <a href="#Dynamical">Dynamical</a>|`data` `starts` `ends` `axes` `step` -> output, which are <a href="#Dynamical">Dynamical</a>|
|<a href="#SoftMax">SoftMax</a>|<a href="#no-change">no-change</a>||
|<a href="#SoftmaxCrossEntropyLoss">SoftmaxCrossEntropyLoss</a>|<a href="#Loss">Loss</a>|scalar, [batch_size], or [batch_size, D1, D2, ..., Dk]|
|<a href="#Softplus">Softplus</a>|<a href="#no-change">no-change</a>||
|<a href="#Softsign">Softsign</a>|<a href="#no-change">no-change</a>||
|<a href="#SpaceToDepth">SpaceToDepth</a>|<a href="#SpaceToDepth">SpaceToDepth</a>|[N, C * blocksize * blocksize, H/blocksize, W/blocksize]|
|<a href="#Split">Split</a>|<a href="#Split C">Split</a>|`axis`|
|<a href="#SplitToSequence">SplitToSequence</a>|<a href="#Split C">Split</a>|list -> Sequence|
|<a href="#Sqrt">Sqrt</a>|<a href="#no-change">no-change</a>||
|<a href="#Squeeze">Squeeze</a>|<a href="#squeeze">Squeeze</a>|delete 1|
|<a href="#StringNormalizer">StringNormalizer</a>|<a href="#StringNormalizer">StringNormalizer</a>, <a href="#Dynamical">Dynamical</a>|it is string operations|
|<a href="#Sub">Sub</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|
|<a href="#Sum">Sum</a>|<a href="#broadcast">broadcast</a>|**multidirectional**  （可变输入参数）|
|<a href="#Tan">Tan</a>|<a href="#no-change">no-change</a>||
|<a href="#Tanh">Tanh</a>|<a href="#no-change">no-change</a>||
|<a href="#TfIdfVectorizer">TfIdfVectorizer</a>|<a href="#TfIdfVectorizer">TfIdfVectorizer</a>,  <a href="#Dynamical">Dynamical</a>|[max(ngram_indexes) + 1] or [N, max(ngram_indexes) + 1]|
|<a href="#ThresholdedRelu">ThresholdedRelu</a>|<a href="#no-change">no-change</a>||
|<a href="#Tile">Tile</a>|<a href="#Tile">Tile</a>|`repeats`|
|<a href="#TopK">TopK</a>|<a href="#TopK">TopK</a>|shape = k, outputs are `values` and `Indices`|
|<a href="#Transpose">Transpose</a>|<a href="#Transpose">Transpose</a>|`perm` determines|
|<a href="#Unique">Unique</a>|<a href="#Dynamical">Dynamical</a>|`axis` determines,  multiple outputs required|
|<a href="#Unsqueeze">Unsqueeze</a>|<a href="#unsqueeze">Unsqueeze</a>|add 1|
|<a href="#Upsample">Upsample</a>|<a href="#no-change">no-change</a>|**deprecated**|
|<a href="#Where">Where</a>|<a href="#broadcast">broadcast</a>|directional not specified|
|<a href="#Xor">Xor</a>|<a href="#broadcast">broadcast</a>|**multidirectional**|

### ai.onnx.preview.training
|**Operator**|**Since version**|
|-|-|
|<a href="#ai.onnx.preview.training.Adagrad">ai.onnx.preview.training.Adagrad</a>|<a href="Changelog.md#ai.onnx.preview.training.Adagrad-1">1</a>|
|<a href="#ai.onnx.preview.training.Adam">ai.onnx.preview.training.Adam</a>|<a href="Changelog.md#ai.onnx.preview.training.Adam-1">1</a>|
|<a href="#ai.onnx.preview.training.Gradient">ai.onnx.preview.training.Gradient</a>|<a href="Changelog.md#ai.onnx.preview.training.Gradient-1">1</a>|
|<a href="#ai.onnx.preview.training.Momentum">ai.onnx.preview.training.Momentum</a>|<a href="Changelog.md#ai.onnx.preview.training.Momentum-1">1</a>|


## Operator Reduction
> Reference Links are based on Pytorch

> The operator names correspond to ONNX.  
1. <a name="no-change">**Element-wise operator without shape change, single tensor input**</a>
   
   | op name | onnx document link | pytorch document link |
   | ------- | ------------------ | --------------------- |
   | <a name="Abs">**Abs**</a> |   https://github.com/onnx/onnx/blob/master/docs/Operators.md#Abs                 |    https://pytorch.org/docs/stable/generated/torch.abs.html#torch.abs                   |
   | <a name="Acos">**Acos**</a> |  https://github.com/onnx/onnx/blob/master/docs/Operators.md#Acos                  |      https://pytorch.org/docs/stable/generated/torch.acos.html#torch.acos                 |
   | <a name="Acosh">**Acosh**</a> |    https://github.com/onnx/onnx/blob/master/docs/Operators.md#Acosh                |      https://pytorch.org/docs/stable/generated/torch.acosh.html#torch.acosh                 |
   | angle   |     None               |     https://pytorch.org/docs/stable/generated/torch.angle.html#torch.angle                  |
   | <a name="Asin">**Asin**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#Asin |      https://pytorch.org/docs/stable/generated/torch.asin.html#torch.asin                 |
   | <a name="Asinh">**Asinh**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#Asinh |       https://pytorch.org/docs/stable/generated/torch.asinh.html#torch.asinh                |
   | <a name="Atan">**Atan**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#Atan |      https://pytorch.org/docs/stable/generated/torch.atan.html#torch.atan                 |
   | <a name="Atanh">**Atanh**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#Atanh |       https://pytorch.org/docs/stable/generated/torch.atanh.html#torch.atanh                |
   | <a name="BatchNormalization">**BatchNormalization**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#BatchNormalization | https://pytorch.org/docs/stable/generated/torch.nn.BatchNorm2d.html#torch.nn.BatchNorm2d |
   | <a name="Cast">**Cast**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#Cast | None |
   | <a name="Ceil">**Ceil**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#ceil | https://pytorch.org/docs/stable/generated/torch.ceil.html#torch.ceil |
   | <a name="Clip">**Clip**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#clip | https://pytorch.org/docs/stable/generated/torch.clamp.html#torch.clamp |
   |  |  |  |
   | <a name="Erf">**Erf**</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#Erf | https://pytorch.org/docs/stable/generated/torch.erf.html#torch.erf |
   | bitwise_not  |                    |         https://pytorch.org/docs/stable/generated/torch.bitwise_not.html#torch.bitwise_not            |
   | ceil    |                    |    https://pytorch.org/docs/stable/generated/torch.ceil.html#torch.ceil                   |
   | clamp   |                    |    https://pytorch.org/docs/stable/generated/torch.clamp.html#torch.clamp                   |
   | conj    |                    |      https://pytorch.org/docs/stable/generated/torch.conj.html#torch.conj                 |
   | cos    |                    |    https://pytorch.org/docs/stable/generated/torch.cos.html#torch.cos                   |
   | cosh   |                    |      https://pytorch.org/docs/stable/generated/torch.cosh.html#torch.cosh                 |
   | div    |                    |   https://pytorch.org/docs/stable/generated/torch.div.html#torch.div                    |
  | digamma  |                    |       https://pytorch.org/docs/stable/generated/torch.digamma.html#torch.digamma                |
  | dropout  |                    |                       |
  | softmax |                    |                       |
  |   |                    |                       |
  | sigmoid	|						|		https://pytorch.org/docs/stable/nn.functional.html#non-linear-activation-functions				|
  | <a name="PRelu">PRelu</a>	| https://github.com/onnx/onnx/blob/master/docs/Operators.md#prelu |		|
  
2. <a name="broadcast">**Element-wise operator with broadcast, double or more tensor inputs, may change shape, two kind: bidirectional- & unidirectional-**</a>  (√)

   - Broadcast should support both **multidirectional** ~~and **unidirectional**~~ (unidirectional can be reduced to non-change with extra constraints)
   - Broadcast should support more than two inputs
   - Broadcast should support that inputs have different rank 

   | op name                                     | onnx link                                                    | pytorch link                                                 |
   | ------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
   | <a name="Add">Add</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#add | https://pytorch.org/docs/stable/generated/torch.add.html#torch.add |
   | <a name="And">And</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#and |                                                              |
   | <a name="BitShift">BitShift</a>             | https://github.com/onnx/onnx/blob/master/docs/Operators.md#BitShift | None                                                         |
   | <a name="Div">Div</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#div | https://pytorch.org/docs/stable/generated/torch.div.html#torch.div |
   | <a name="Equal">Equal</a>                   | https://github.com/onnx/onnx/blob/master/docs/Operators.md#equal | https://pytorch.org/docs/stable/generated/torch.equal.html#torch.equal |
   | ~~<a name="Expand">Expand</a>~~             | ~~https://github.com/onnx/onnx/blob/master/docs/Operators.md#expand~~ |                                                              |
   | <a name="Greater">Greater</a>               | https://github.com/onnx/onnx/blob/master/docs/Operators.md#greater | https://pytorch.org/docs/stable/generated/torch.gt.html#torch.gt |
   | <a name="GreaterOrEqual">GreaterOrEqual</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#greaterorequal | https://pytorch.org/docs/stable/generated/torch.ge.html#torch.ge |
   | <a name="Less">Less</a>                     | https://github.com/onnx/onnx/blob/master/docs/Operators.md#less | https://pytorch.org/docs/stable/generated/torch.lt.html#torch.lt |
   | <a name="LessOrEqual">LessOrEqual</a>       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#lessorequal | https://pytorch.org/docs/stable/generated/torch.le.html#torch.le |
   | <a name="Max">Max</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#max | https://pytorch.org/docs/stable/generated/torch.max.html#torch.max |
   | <a name="Mean">Mean</a>                     | https://github.com/onnx/onnx/blob/master/docs/Operators.md#mean | https://pytorch.org/docs/stable/generated/torch.mean.html#torch.mean |
   | <a name="Min">Min</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#min |                                                              |
   | <a name="Mod">Mod</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#mod |                                                              |
   | <a name="Mul">Mul</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#mul |                                                              |
   | <a name="Or">Or</a>                         | https://github.com/onnx/onnx/blob/master/docs/Operators.md#or |                                                              |
   | ~~<a name="PRelu">PRelu</a>~~               | ~~https://github.com/onnx/onnx/blob/master/docs/Operators.md#prelu~~ |                                                              |
   | <a name="Pow">Pow</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#pow |                                                              |
   | <a name="Sub">Sub</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#sub |                                                              |
   | <a name="Sum">Sum</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#sub |                                                              |
   | <a name="Where">Where</a>                   | <a name="Where">Where</a>                                    |                                                              |
   | <a name="Xor">Xor</a>                       | <a name="Where">Where</a>                                    |                                                              |

3. <a name="Reduce">**Reduce**</a>  （√）

   Along a specified axis, do reduction operation. Generally, this  shrink the input tensor just in one dimension if `keepdims` is 0.
   
   `Attributes`: `axis`, `keepdims` 
   
   | Op name                                       | onnx link                                                    | pytorch link                                                 |
   | --------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
   | <a name="ArgMax">ArgMax</a>                   | https://github.com/onnx/onnx/blob/master/docs/Operators.md#argmax | https://pytorch.org/docs/stable/generated/torch.argmax.html#torch.argmax |
   | <a name="ArgMin">ArgMin</a>                   | https://github.com/onnx/onnx/blob/master/docs/Operators.md#argmin | https://pytorch.org/docs/stable/generated/torch.argmin.html#torch.argmin |
   | <a name="ReduceL1">ReduceL1</a>               | https://github.com/onnx/onnx/blob/master/docs/Operators.md#reducel1 |                                                              |
   | <a name="ReduceL2">ReduceL2</a>               |                                                              |                                                              |
   | <a name="ReduceLogSum">ReduceLogSum</a>       |                                                              |                                                              |
   | <a name="ReduceLogSumExp">ReduceLogSumExp</a> |                                                              |                                                              |
   | <a name="ReduceMax">ReduceMax</a>             |                                                              |                                                              |
   | <a name="ReduceMean">ReduceMean</a>           |                                                              |                                                              |
   | <a name="ReduceMin">ReduceMin</a>             |                                                              |                                                              |
   | <a name="ReduceProd">ReduceProd</a>           |                                                              |                                                              |
   | <a name="ReduceSum">ReduceSum</a>             |                                                              |                                                              |
   | <a name="ReduceSumSquare">ReduceSumSquare</a> |                                                              |                                                              |
   
4. <a name="pool">**pool**</a>   （√）

   maxpool, avgpool, etc. all Pool operations are subsampling. thus they have same shape infer rules. Below infer equations refer to [pytorch](https://pytorch.org/docs/stable/nn.html#pooling-layers)
   $$
   1D: L_{out}=\lfloor \frac{L_{in} + 2\times padding - kernel\_size}{stride} + 1\rfloor \\
   2D: 
   H_{out}=\lfloor \frac{H_{in} + 2\times padding[0] - kernel\_size[0]}{stride[0]} + 1 \rfloor \\
   W_{out}=\lfloor \frac{W_{in} + 2\times padding[1] - kernel\_size[1]}{stride[1]} +1 \rfloor \\
   3D:  D_{out}=\lfloor \frac{D_{in} + 2\times padding[0] - kernel\_size[0]}{stride[0]} +1\rfloor \\
   H_{out}=\lfloor \frac{H_{in} + 2\times padding[1] - kernel\_size[1]}{stride[1]} + 1 \rfloor \\
   W_{out}=\lfloor \frac{W_{in} + 2\times padding[2] - kernel\_size[2]}{stride[2]}+1 \rfloor \\
   $$

   | Op name                                           | onnx link                                                    | pytorch link                                                 |
   | ------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
   | <a name="AveragePool">AveragePool</a>             | https://github.com/onnx/onnx/blob/master/docs/Operators.md#averagepool | [1D](https://pytorch.org/docs/stable/generated/torch.nn.AvgPool1d.html#torch.nn.AvgPool1d) [2D](https://pytorch.org/docs/stable/generated/torch.nn.AvgPool2d.html#torch.nn.AvgPool2d) [3D](https://pytorch.org/docs/stable/generated/torch.nn.AvgPool3d.html#torch.nn.AvgPool3d) |
   | <a name="GlobalAveragePool">GlobalAveragePool</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#globalaveragepool |                                                              |
   | <a name="GlobalLpPool">GlobalLpPool</a>           | https://github.com/onnx/onnx/blob/master/docs/Operators.md#globallppool |                                                              |
   | <a name="GlobalMaxPool">GlobalMaxPool</a>         | https://github.com/onnx/onnx/blob/master/docs/Operators.md#globalmaxpool |                                                              |
   | <a name="LpPool">LpPool</a>                       | https://github.com/onnx/onnx/blob/master/docs/Operators.md#lppool | [LpPool2D](https://pytorch.org/docs/stable/generated/torch.nn.LPPool2d.html#torch.nn.LPPool2d) |
   | <a name="MaxPool">MaxPool</a>                     | https://github.com/onnx/onnx/blob/master/docs/Operators.md#maxpool | [MaxPool2D](https://pytorch.org/docs/stable/generated/torch.nn.MaxPool2d.html#torch.nn.MaxPool2d) |

4. <a name="Compress">Compress</a>  (???)

   Along the specified `axis`(optional), take slices according to `condition`. If `axis` is not specified, flatten it at the very beginning.

    [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#compress)  

5. <a name="Concate">Concate tensors together</a> 

   | Op                                                      | onnx link                                                    | pytorch link                                                 |
   | ------------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
   | <a name="Concat">Concat </a> (√)                        | https://github.com/onnx/onnx/blob/master/docs/Operators.md#concat | https://pytorch.org/docs/stable/generated/torch.cat.html#torch.cat |
   | <a name="ConcatFromSequence">ConcatFromSequence</a> (x) | https://github.com/onnx/onnx/blob/master/docs/Operators.md#concatfromsequence | https://github.com/onnx/onnx/blob/master/docs/Operators.md#concatfromsequence |
   |                                                         |                                                              |                                                              |

7. <a name="Produce">generator, input shape is either empty or shape-keeping.</a> (√)

   | Op name                                           | onnx                                                         | pytorch |
   | ------------------------------------------------- | ------------------------------------------------------------ | ------- |
   | <a name="Constant">Constant</a>                   | https://github.com/onnx/onnx/blob/master/docs/Operators.md#constant | None    |
   | <a name="ConstantOfShape">ConstantOfShape</a>     | https://github.com/onnx/onnx/blob/master/docs/Operators.md#constantofshape | None    |
   | <a name="RandomNormal">RandomNormal</a>           | https://github.com/onnx/onnx/blob/master/docs/Operators.md#randomuniform |         |
   | <a name="RandomNormalLike">RandomNormalLike</a>   | https://github.com/onnx/onnx/blob/master/docs/Operators.md#RandomNormalLike |         |
   | <a name="RandomUniform">RandomUniform</a>         | https://github.com/onnx/onnx/blob/master/docs/Operators.md#randomuniform |         |
   | <a name="RandomUniformLike">RandomUniformLike</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#RandomNormalLikes |         |

7. <a name="Convs">Conv</a> 

   Same as <a href="#pool">pool</a>, this combines conv operations in 1D, 2D, 3D
   $$
   1D: L_{out}=⌊\frac{L_{in} + 2 × padding − dilation × (kernel\_size−1) − 1}{stride} + 1⌋ \\
   2D: H_{out}=⌊\frac{H_{in} + 2 × padding[0] − dilation[0] × (kernel\_size[0] − 1) − 1}{stride[0]} + 1⌋ \\
   W_{out}=⌊\frac{W_{in} + 2 × padding[1] − dilation[1] × (kernel\_size[1] − 1) − 1}{stride[1]} + 1⌋ \\
   3D: \ ...
   $$
   

   | Op name                               | onnx                                                         | pytorch                                                      |
   | ------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
   | <a name="Conv">Conv</a>               | https://github.com/onnx/onnx/blob/master/docs/Operators.md#conv | [conv1d](https://pytorch.org/docs/stable/generated/torch.nn.Conv1d.html#torch.nn.Conv1d)  [conv2d](https://pytorch.org/docs/stable/generated/torch.nn.Conv2d.html#torch.nn.Conv2d) [conv3d](https://pytorch.org/docs/stable/generated/torch.nn.Conv3d.html#torch.nn.Conv3d) |
   | <a name="ConvInteger">ConvInteger</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#convinteger |                                                              |
   | <a name="QLinearConv">QLinearConv</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#qlinearconv |                                                              |
   |                                       |                                                              |                                                              |

   [linear](https://pytorch.org/docs/stable/generated/torch.nn.Linear.html#torch.nn.Linear) -- specialized conv operator [1, 1, out_channel, in_channel] where out_channel == in_channel

8. <a name="ConvTranspose">ConvTranspose</a>

   [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#convtranspose) [pytorch ConvTranspose2d ](https://pytorch.org/docs/stable/generated/torch.nn.ConvTranspose2d.html#torch.nn.ConvTranspose2d)

   calculate the output shape as follows
   $$
   output\_shape[i] = stride[i] * (input\_size[i] - 1) + output\_padding[i] + ((kernel\_shape[i] - 1) * dilations[i] + 1) - pads[start\_i] - pads[end\_i]
   $$

9. <a name="DepthToSpace">DepthToSpace</a> [onnx link](https://github.com/onnx/onnx/blob/master/docs/Operators.md#depthtospace) [pytorch link](https://pytorch.org/docs/stable/generated/torch.nn.PixelShuffle.html#torch.nn.PixelShuffle) [tensorflow link](https://tensorflow.google.cn/api_docs/python/tf/nn/depth_to_space)

   `Attributes` : `blocksize` 

   `input` : [N, C, H, W] 

   `output` : [N, C/(blocksize * blocksize), H * blocksize, W * blocksize]

10. <a name="SpaceToDepth">SpaceToDepth</a>

   `Attributes` : `blocksize` 

   `input` : [N, C, H, W] 

   `output` : [N, C * blocksize * blocksize, H/blocksize, W/blocksize]

11. <a name="Det">Det</a> [onnx link](https://github.com/onnx/onnx/blob/master/docs/Operators.md#det) [pytorch](https://pytorch.org/docs/stable/generated/torch.det.html#torch.det)

    `input` : [*, M, M]

    `output` : [*]  

12. <a name="Einsum">Einsum</a>

    `Attributes` : `equation` like `...ii ->...i` , `bij, bjk -> bik`, ...

13. <a name="RNN Layer">RNN Layer</a>

    `hidden_layer` = (1, 3, 4) if `op` is （`RNN`, `GRU`, `LSTM`）

    `Attributes` : 

    ​	`direction` - forward, reverse, bidirectional.

    ​	`hidden_size` : Number of neurons in the hidden layer

    ​	`input_forget` : Couple the input and forget gates

    `Inputs`  :

    ​	`X` : [seq_length, batch_size, input_size]

    ​	`W` : [num_directions, `hidden_layer` *hidden_size, input_size]

    ​	`R` : [num_directions, `hidden_layer` *hidden_size, hidden_size]

    ​	`B` : [num_directions, `hidden_layer` * 2 *hidden_size]

    ​	`sequence_lens` : [batch_size]

    ​	`initial_h` : [num_directions, batch_size, hidden_size]

    ​	`initial_c` : [num_directions, batch_size, hidden_size]

    ​	`P` : [num_directions, 3*hidde_size]

    `Outputs` : 

    ​	`Y` : [seq_length, num_directions, batch_size, hidden_size]

    ​	`Y_h` : [num_directions, batch_size, hidden_size]

    ​	`Y_c` : [num_directions, batch_size, hidden_size]

    | Op name                 | onnx                                                         | pytorch                                                      |
    | ----------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
    | <a name="GRU">GRU</a>   | https://github.com/onnx/onnx/blob/master/docs/Operators.md#gru | https://pytorch.org/docs/stable/generated/torch.nn.GRU.html#torch.nn.GRU |
    | <a name="LSTM">LSTM</a> |                                                              | https://pytorch.org/docs/stable/generated/torch.nn.LSTM.html#torch.nn.LSTM |
    | <a name="RNN">RNN</a>   |                                                              | https://pytorch.org/docs/stable/generated/torch.nn.RNN.html#torch.nn.RNN |
    |                         |                                                              |                                                              |

14. <a name="Gather C">Gather</a>

    `Attribute` : `axis` - Which axis to gather on

    `Input` : 

    ​	`data` : rank r

    ​	`indices` : rank q

    `Output` :

    ​	`output` : rank (r - 1)+ q

    outer-most is 0 - `axis - 1` dimension of `data`, and then q dimensions of `indices` and then  `axis + 1` - r dimension of  `data`

    | Op name                                     | onnx                                                         | pytorch |
    | ------------------------------------------- | ------------------------------------------------------------ | ------- |
    | <a name="Gather">Gather</a>                 | https://github.com/onnx/onnx/blob/master/docs/Operators.md#gather |         |
    | <a name="GatherElements">GatherElements</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#gatherelements |         |
    | <a name="GatherND">GatherND</a>             | https://github.com/onnx/onnx/blob/master/docs/Operators.md#gathernd |         |

11. <a name="Gemm">Gemm</a>

    `Attributes` : `transA` `transB`

    `Input` :

    ​	`A` : (M, K) or (K, M)

    ​	`B` : (K, N)  or (N, K)

    ​	`C` : Broadcast to (M, N)

    `Output`:

    ​	`Y` : (M, N)

16. <a name="Dynamical">Dynamical</a>

    Dynamic is a category of operators that runtime information is needed to infer the output  shape. To be more specific, some operators may have several outputs to infer, some of whose shapes are dynamically determinable. We put such outputs in this category for further study later.    

    <a name="Expand">Expand</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#expand), expand to a 1D tensor, thus needing to input 1D tensor element value

    <a name="If">If</a>  

    <a name="Loop">Loop</a>  [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#loop)

    <a name="NonZero">NonZero</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#nonzero)

    <a name="OneHot">OneHot </a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#OneHot)

    <a name="Reshape">Reshape</a>  [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#Reshape) 

    <a name="SequenceAt">SequenceAt</a> 

    <a name="SequenceConstruct">SequenceConstruct</a>  

    <a name="SequenceErase">SequenceErase</a> 

    <a name="SequenceInsert">SequenceInsert</a>

    <a name="Slice">Slice</a>

    <a name="StringNormalizer">StringNormalizer</a>

    <a name="TfIdfVectorizer">TfIdfVectorizer</a>  [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#tfidfvectorizer)

    <a name="Unique">Unique</a>  [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#unique)

13. <a name="MatMul C">MatMul</a>

    support rank difference ; broadcast-like

    A * B -> Y

    <a name="MatMul">MatMul</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#matmul) [pytorch](https://pytorch.org/docs/stable/generated/torch.matmul.html#torch.matmul)

    <a name="MatMulInteger">MatMulInteger </a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#matmulinteger)

    <a name="QLinearMatMul">QLinearMatMul</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#qlinearmatmul)

    

14. <a name="MaxRoiPool">MaxRoiPool</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#maxroipool)

15. <a name="Unpool">Unpool</a>
    $$
    H_{out}	= (H_{in} − 1 ) × stride[0] − 2 × padding[0] + kernel\_size[0] \\
    W_{out} = (W_{in} - 1) \times \text{stride[1]} - 2 \times \text{padding[1]} + \text{kernel_size[1]} \\
    $$
    <a name="MaxUnpool">MaxUnpool</a>   [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#maxunpool)  [pytorch maxunpool2d](https://pytorch.org/docs/stable/generated/torch.nn.MaxUnpool2d.html#torch.nn.MaxUnpool2d)

16. <a name="Multinomial">Multinomial</a> [pytorch](https://pytorch.org/docs/stable/generated/torch.multinomial.html#torch.multinomial)  `sample_size` and `input::batch_size` -> output `[batch_size, sample_size]`

17. <a name="Loss">Loss</a>

    All Loss ops are generating a loss evaluation, thus only having different constraints, but having same output shape. 

    | Op name                                                      | onnx                                                         | pytorch                                                      |
    | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
    | <a name="NegativeLogLikelihoodLoss">NegativeLogLikelihoodLoss</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#negativeloglikelihoodloss | https://pytorch.org/docs/stable/generated/torch.nn.NLLLoss.html#torch.nn.NLLLoss |
    | <a name="SoftmaxCrossEntropyLoss">SoftmaxCrossEntropyLoss</a> | https://github.com/onnx/onnx/blob/master/docs/Operators.md#softmaxcrossentropyloss |                                                              |

18. <a name="ConstantShape">ConstantShape</a>

    Output is either a [scalar], the scalar is a constant number or a list which equals input shape

    <a name="SequenceEmpty">SequenceEmpty</a>

    <a name="Shape">Shape</a>

    <a name="Size">Size</a>

19. <a name="NonMaxSuppression">NonMaxSuppression</a>

    `boxes` [num_batches, spatial_dimension, 4], `scores` [num_batches, num_classes, spatial_dimension] -> [num_selected_indices, 3]

20. <a name="Pad">Pad</a> 

    just padding the input tensor, can be a sub-function of conv, pool, etc. 

21. <a name="Split C">Split</a>

    Split a tensor to two or more output tensors

    <a name="Flatten">Flatten</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#flatten) [pytorch](https://pytorch.org/docs/stable/generated/torch.flatten.html#torch.flatten)

    ​	Flatten a tensor into a 2D matrix 

    ​	`Attributes` : `aixs` , split the input tensor according to `axis` 

    <a name="Split">Split</a>

    ​	`split`(optional) to assign length of each output

    ​	[onnx](a name="Split">Split</a>)

    <a name="SplitToSequence">SplitToSequence</a>

22. <a name="RoiAlign">RoiAlign</a>

23. <a name="Scan">Scan</a>

24. <a name="squeeze">squeeze</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#squeeze) [pytorch](https://pytorch.org/docs/stable/generated/torch.squeeze.html#torch.squeeze)

25. <a name="Tile">Tile</a>

    `data` * `repeats`

26. <a name="TopK">TopK</a>

    `K` matters

27. <a name="Transpose">transpose</a>  [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#transpose) [pytorch](https://pytorch.org/docs/stable/generated/torch.transpose.html#torch.transpose)

28. <a name="unsqueeze">unsqueeze</a> [onnx](https://github.com/onnx/onnx/blob/master/docs/Operators.md#unsqueeze)

## Implentation Records
>  only test legal hyperparameters for now.
1. sometimes, when I accidentally set `self.inputs` as a operator/layer's parameters, some strange mistakes may occur.
2. Element-wise operator and "Broadcast" operator seperation?
3. Broadcast support
   - scalar + tensor
   - equivalent length of tensor shape
   - non equivalant length of tensor shape
   > But this check can also be done when construct operator/graph
## TODO List

### Need help to convert from onnx to pytorch

[BitShift](https://github.com/onnx/onnx/blob/master/docs/Operators.md#BitShift)

[Shape](https://github.com/onnx/onnx/blob/master/docs/Operators.md#shape)

[Expand](https://github.com/onnx/onnx/blob/master/docs/Operators.md#expand)

### <a name="bert_op">BERT</a>

| op name                        | number | support                          |
| ------------------------------ | ------ | -------------------------------- |
| DataInput                      | 3      | y                                |
| Constant                       | 201    | y                                |
| Shape                          | 98     | y because shape is already known |
| Gather                         | 102    | y                                |
| Unsqueeze                      | 101    | y                                |
| FullyConnected                 | 1      | y if this is fc                  |
| Cast                           | 2      | y                                |
| Tanh                           | 1      | y                                |
| Range                          | 1      | y                                |
| Concat                         | 49     | y                                |
| Sub                            | 26     | y                                |
| Mul                            | 50     | y                                |
| Expand                         | 1      | No                               |
| Add                            | 172    | y                                |
| ReduceMean                     | 50     | y                                |
| Pow                            | 25     | y                                |
| Sqrt                           | 25     | y                                |
| Div                            | 49     | y                                |
| MatMul                         | 96     | y                                |
| Reshape                        | 48     | y                                |
| Transpose                      | 48     | y                                |
| <a href="#Softmax">Softmax</a> | 12     | y                                |
| <a href="#Erf">Erf</a>         | 12     | y                                |

**attributes in bert need to be processed:**

| attr   | node                            |
| ------ | ------------------------------- |
| value  | ['Constant']                    |
| axes   | ['Unsqueeze', 'ReduceMean']     |
| axis   | ['Gather', 'Concat', 'Softmax'] |
| alpha  | ['FullyConnected']              |
| beta   | ['FullyConnected']              |
| transB | ['FullyConnected']              |
| to     | ['Cast']                        |
| shape  | ['Reshape']                     |
| perm   | ['Transpose']                   |

存在问题：

1. 属性的值被只dump出了shape信息，缺失
2. gen_solver_variable 的 input以及其它信息默认设置4个维度变量（batch size， in channel, height, width），对于bert？
3. generic 如何设置维度信息？

## Need help

1. how to locate an operator in onnx to pytorch?
2. How to implenment shape_infer functions' reuse? 

## solution
1. if - else statement
2. get op's parent, gen_constraintws
3. If not match, then make a list to mmdnn group
4. complete all operators, test vgg, then use log, and shape rules （z3 constraints）
5. vgg_prune dnnat/tests/vgg_prune   layers are null, test single model use_shape_rule
6. infinite solutions, no constraints
7. always no solution, constraints too strong


# Whole Resolve Process
```
Construct Dependency Graph in topology_order of input DNN
split search space
for each splited space:
   for each op in Dependency Graph:
      construct_solver_variable according to reduced operators categroy
      the constructed z3_variables are used to calculate the output shape
      then, if there are some implict constraints, make it in shape_rules
      generate symbolic constraints according to hyperparameters
      add constraints between childern and parents
   solve
```

## Supported models



## Implementation record

1. [MXNet's idea to support dynamic shape in its framework](https://cwiki.apache.org/confluence/display/MXNET/Dynamic+shape)

2. ONNX may have infer problems in [reduce](https://github.com/onnx/onnx/blob/master/onnx/defs/reduction/defs.cc) category? this is very unusual.
3. shape inference functions of reduction is [here](https://github.com/onnx/onnx/blob/master/onnx/defs/reduction/defs.cc#L96), others are same

