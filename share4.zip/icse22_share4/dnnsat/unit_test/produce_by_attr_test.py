"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn
import numpy as np
import onnx

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """

    def test_constant_output_shape(self):
        input_shape = [5, 5, 6, 8]
        values = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        node = onnx.helper.make_node(
            'Constant',
            inputs=[],
            outputs=['values'],
            value=onnx.helper.make_tensor(
                name='const_tensor',
                data_type=onnx.TensorProto.FLOAT,
                dims=values.shape,
                vals=values. flatten().astype(float),
            )
        )
        result = onnx_node_shape_infer(node, inputs=[], name='test_constant')
        output_shape = no_change_output_shape(input_shape)
        self.assertListEqual(output_shape, result[0])

    # TODO: Onnx inferred output shape of ConstantOfShape is alwyas zero. 
    def test_constantofshape_output_shape(self):
        x = np.array([4, 3, 2]).astype(np.int64)
        tensor_value = onnx.helper.make_tensor("value", onnx.TensorProto.FLOAT,
                                            [1], [1])
        node = onnx.helper.make_node(
            'ConstantOfShape',
            inputs=['x'],
            outputs=['y'],
            value=tensor_value,
        )
        y = np.ones(x, dtype=np.float32)
        result = onnx_node_shape_infer(node, inputs=[x], name='test_constantofshpe')
        # print(result[0])

    def test_randomnormal_output_shape(self):
        input_shape = [3, 2, 3, 4]
        node = onnx.helper.make_node(
            'RandomNormal',
            inputs=[],
            outputs=['y'],
            shape=input_shape,
            dtype=onnx.TensorProto.DOUBLE
        )
        result = onnx_node_shape_infer(node, inputs=[], name='test_randomnormal')
        output_shape = no_change_output_shape(input_shape)
        # print(result)
        self.assertListEqual(output_shape, result[0])

    def test_randomnorlmallike_output_shape(self):
        node = onnx.helper.make_node(
            'RandomNormalLike',
            inputs=['x'],
            outputs=['y']
        )
        input_shape = [5, 5, 6, 8]
        values = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, [values], 'test_randomnormal_like')
        # print(result)
        output_shape = no_change_output_shape(input_shape)
        # print(result)
        self.assertListEqual(output_shape, result[0])

    def test_randomuniform_output_shape(self):
        input_shape = [3, 2, 3, 4]
        node = onnx.helper.make_node(
            'RandomUniform',
            inputs=[],
            outputs=['y'],
            shape=input_shape,
            dtype=onnx.TensorProto.FLOAT
        )
        result = onnx_node_shape_infer(node, inputs=[], name='test_randomuniform')
        output_shape = no_change_output_shape(input_shape)
        # print(result)
        self.assertListEqual(output_shape, result[0])

    def test_randomuniform_like_output_shape(self):
        node = onnx.helper.make_node(
            'RandomUniformLike',
            inputs=['x'],
            outputs=['y']
        )
        input_shape = [5, 5, 6, 8]
        values = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, [values], 'test_randomuniform_like')
        # print(result)
        output_shape = no_change_output_shape(input_shape)
        # print(result)
        self.assertListEqual(output_shape, result[0])

if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from onnx_shape_infer import onnx_node_shape_infer
    from dnnsat.dnnsat.shape_inference import no_change_output_shape
    unittest.main(verbosity=2)