"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn
import numpy as np
import onnx

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """

    def test_compress_output_shape(self):
        input_shape = [3, 2]
        node = onnx.helper.make_node(
            'Compress',
            inputs=['input', 'condition'],
            outputs=['output']
        )
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        condition = np.array([0, 1])
        result = onnx_node_shape_infer(node, inputs=[data, condition.astype(np.bool)], name='test_compress_1')
        print(result[0])
        output = np.compress(condition, data, axis=1)
        print(output)

if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from onnx_shape_infer import onnx_node_shape_infer
    unittest.main(verbosity=2)