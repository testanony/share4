"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn
import numpy as np
import onnx

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """
        self.channel_first = True
        self.batch_size = 128
        self.in_channels = 3
        self.out_channels = 64
        self.in_height = 224
        self.in_width = 224
        if self.channel_first:
            self.inputs = [self.batch_size, self.in_channels, self.in_height, self.in_width]
        else:
            self.inputs = [self.batch_size, self.in_height, self.in_width, self.in_channels]


    def test_argmax_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axis = 1
        keepdims = 1
        node = onnx.helper.make_node(
            'ArgMax',
            inputs=['data'],
            outputs=['result'],
            axis=axis,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_argmax_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axis, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_argmax_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axis, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])
    
    def test_argmin_output_shape(self):
        # data = np.array()
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axis = 1
        keepdims = 1
        node = onnx.helper.make_node(
            'ArgMin',
            inputs=['data'],
            outputs=['result'],
            axis=axis,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_argmin_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axis, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_argmin_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axis, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reduceL1_output_shape(self):
        # data = np.array()
        input_shape = [3, 2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [2]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceL1',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceL1_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceL1_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reduceL2_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceL2',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceL2_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceL2_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reducelogsum_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceLogSum',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceLogsum_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceLogsum_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reducelogsumexp_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceLogSumExp',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceLogsumexp_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceLogsumexp_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reducemax_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceMax',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceMax_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceMax_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reducemean_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceMean',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceMean_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceMean_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reducemin_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceMin',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceMin_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceMin_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reduceprod_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceProd',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceProd_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceProd_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reduceSum_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceSum',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceSum_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceSum_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

    def test_reducesumsquare_output_shape(self):
        input_shape = [2, 2]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        axes = [1]
        keepdims = 1
        node = onnx.helper.make_node(
            'ReduceSumSquare',
            inputs=['data'],
            outputs=['result'],
            axes=axes,
            keepdims=keepdims)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceSumsquare_keepdims_example')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

        input_shape = [2, 3, 4]
        data = np.random.uniform(-10, 10, input_shape).astype(np.float32)
        result = onnx_node_shape_infer(node, inputs=[data], name='test_reduceSumsquare_no_keepdims_random_select_last_index')
        _output = _reducemean_output_shape(input_shape, _dims=axes, _keepdims=bool(keepdims))
        self.assertListEqual(_output, result[0])

if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from onnx_shape_infer import onnx_node_shape_infer
    from dnnsat.dnnsat.shape_inference import _reducemean_output_shape
    unittest.main(verbosity=2)