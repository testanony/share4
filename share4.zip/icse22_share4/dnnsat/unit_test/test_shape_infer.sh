#!/bin/bash
# test_shape_infer
export PYTHONPATH=/home/testcluster/shuo/dnncost:$PYTHONPATH

dir=$PWD/result/$(TZ=UTC-8 date "+%F-%T" | tr ':' '-')
mkdir -p $dir
python $1 2>&1 | tee $dir/log &