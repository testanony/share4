"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn
import numpy as np
import onnx

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """
        

    def test_pool_output_shape(self):
        

if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from onnx_shape_infer import onnx_node_shape_infer
    from dnnsat.dnnsat.shape_inference import _reducemean_output_shape
    unittest.main(verbosity=2)