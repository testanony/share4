"""Tests for Shape Inference."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import unittest
import sys
import os

import torch
import torch.nn as nn

from onnx_shape_infer import onnx_shape_infer

class ShapeInferenceTest(unittest.TestCase):
    """[Test shape inference functions]

    Arguments:
        unittest {[type]} -- [description]
    """
    def setUp(self):
        """[Setup default configuration]
        """
        self.channel_first = True
        self.batch_size = 128
        self.in_channels = 3
        self.in_height = 224
        self.in_width = 224
        if self.channel_first:
            self.inputs = [self.batch_size, self.in_channels, self.in_height, self.in_width]
        else:
            self.inputs = [self.batch_size, self.in_height, self.in_width, self.in_channels]

    def test_add_output_shape(self):
        """[Test add shape infer]
        # Test cases refered to pytorch documents as follows
        # Ref: https://pytorch.org/docs/stable/notes/broadcasting.html#broadcasting-semantics
        """
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Add', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Add', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Add', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_and_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('And', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('And', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('And', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_bitshift_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('BitShift', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('BitShift', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('BitShift', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_div_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Div', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Div', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Div', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_equal_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Equal', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Equal', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Equal', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_greater_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Greater', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Greater', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Greater', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_greaterorequal_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('GreaterOrEqual', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('GreaterOrEqual', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('GreaterOrEqual', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_less_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Less', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Less', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Less', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])
    
    def test_max_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Max', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        _input3 = [1, 1, 1, 4]
        input_shape = [_input1, _input2, _input3]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Max', ['a', 'b', 'c'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        _input3 = [1, 2, 4]
        input_shape = [_input1, _input2, _input3]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Max', ['a', 'b', 'c'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_mean_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mean', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        _input3 = [1, 1, 1, 4]
        input_shape = [_input1, _input2, _input3]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mean', ['a', 'b', 'c'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        _input3 = [1, 1, 2, 4]
        _input4 = [5, 1, 1, 4]
        input_shape = [_input1, _input2, _input3, _input4]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mean', ['a', 'b', 'c', 'd'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_min_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Min', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        _input3 = [1, 1, 1, 4]
        input_shape = [_input1, _input2, _input3]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Min', ['a', 'b', 'c'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        _input3 = [1, 1, 2, 4]
        _input4 = [5, 1, 1, 4]
        input_shape = [_input1, _input2, _input3, _input4]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Min', ['a', 'b', 'c', 'd'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_mod_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mod', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mod', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mod', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_mul_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mul', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mul', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Mul', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_or_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Or', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Or', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Or', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_prelu_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _undirectional_broadcast_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('PRelu', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 3, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _undirectional_broadcast_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('PRelu', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        # _input1 = [5, 1, 4, 3]
        # _input2 = [1, 2, 3]
        # input_shape = [_input1, _input2]
        # outputs = _undirectional_broadcast_output_shape(input_shape)
        # onnx_infer_result = onnx_shape_infer('PRelu', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        # # print(onnx_infer_result[0])
        # self.assertListEqual(outputs, onnx_infer_result[0])

        # _input1 = [5, 1, 4, 1]
        # _input2 = [3, 4, 1]
        # input_shape = [_input1, _input2]
        # outputs = _undirectional_broadcast_output_shape(input_shape)
        # onnx_infer_result = onnx_shape_infer('PRelu', ['a', 'b'], input_shape)
        # # print(onnx_infer_result[0])
        # self.assertListEqual(outputs, onnx_infer_result[0])

    def test_pow_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Pow', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Pow', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Pow', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_sub_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Sub', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Sub', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Sub', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])
    
    def test_sum_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Sum', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        _input3 = [1, 1, 1, 4]
        input_shape = [_input1, _input2, _input3]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Sum', ['a', 'b', 'c'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        _input3 = [1, 1, 2, 4]
        _input4 = [5, 1, 1, 4]
        input_shape = [_input1, _input2, _input3, _input4]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Sum', ['a', 'b', 'c', 'd'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

    def test_Xor_output_shape(self):
        input_shape = [self.inputs, self.inputs]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Xor', ['a', 'b'], input_shape)
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = [5, 1, 4, 1]
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Xor', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

        _input1 = []
        _input2 = [3, 1, 1]
        input_shape = [_input1, _input2]
        outputs = _add_output_shape(input_shape)
        onnx_infer_result = onnx_shape_infer('Xor', ['a', 'b'], input_shape)
        # print(onnx_infer_result[0])
        self.assertListEqual(outputs, onnx_infer_result[0])

if __name__ == '__main__':
    sys.path.append(os.path.dirname(sys.path[0]))
    from dnnsat.dnnsat.shape_inference import _add_output_shape
    from dnnsat.dnnsat.shape_inference import _undirectional_broadcast_output_shape
    unittest.main(verbosity=2)