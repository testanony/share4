# Pythia vs Refty Experiment

## Step0: Prepare pythia docker and fist run compiling pythia [Currently prepared at benchmarkDL6]

Refer [dnnperf_data/Refty_related_baseline_tool.md](dnnperf_data/Refty_related_baseline_tool.md)


## Step1: Generate real test python file and net json

it contains 3 steps
1. gen real python and net json
2. real run gen exception
3. pythia check

NOTE: please change the path as your local folder
```
python3 refty_pythia_compare_bench_gen_test_case.py --container_id b66c3705c3cf --code_folder "/bench6path/yanjga/dnncost/dnnperf_data/pythia_bench/"

# OR use scripts
./gen_real_and_pythia.sh
```

### NOTE:

```
# how to get container id
docker ps

CONTAINER ID        IMAGE                   COMMAND             CREATED             STATUS              PORTS               NAMES
b66c3705c3cf        gfour/doop:4.23.8       "/bin/bash"         2 days ago          Up 2 days                               doop_container_8_11

# doop_container_8_11's id is b66c3705c3cf

```

How to get path:


outputs:
view step1_ouput_example folder

```
mnist_conv1_kernel_h_5_conv1_kernel_w_3_conv1_kernel_c_64_pool_kernel_h_2_pool_kernel_w_2
    - pythia_log.txt: pythia execute logs
    - mnist_search_space.json: search spaces
    - mnist_conv1_kernel_h_5_conv1_kernel_w_3_conv1_kernel_c_64_pool_kernel_h_2_pool_kernel_w_2.py: real run tf code
    - mnist__conv1_kernel_h_5_conv1_kernel_w_3_conv1_kernel_c_64_pool_kernel_h_2_pool_kernel_w_2.json: net json file
        
        #"exception": if contains means real run throw error

        #if detect_error:
        #    temp_net["pythia_detect_error"] = True # detect error
        #else:
        #    temp_net["pythia_detect_error"] = False # not detect error

    - log.txt: real run tf code logs
```

## Step2: Refty check the search space


```
./refty_check.sh
```

# Note

if docker container not launch, please see the doc of [dnnperf_data/Refty_related_baseline_tool.md](dnnperf_data/Refty_related_baseline_tool.md)