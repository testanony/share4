from code_gen_test_launcher import *
import copy
from base_code_gen import *


class MNISTNet(BaseNet):
    """Conv2D. """
    def __init__(self):
        super(MNISTNet, self).__init__()

    def get_net_json(self):
        self.net_json = json.loads("""{
                    "name": "MNIST - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [5, 5, 3, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool1": {
                            "parents": ["conv1-1"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv2-1": {
                            "parents": ["pool1"],
                            "type": "Convolution",
                            "filter": [5, 5, 64, 128],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool2": {
                            "parents": ["conv2-1"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "fc6": {
                            "parents": ["pool5"],
                            "type": "Convolution",
                            "filter": [7, 7, 256, 4096],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "fc8": {
                            "parents": ["fc6"],
                            "type": "Convolution",
                            "filter": [1, 1, 4096, 1000],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": null
                        },
                        "softmax": {
                            "parents": ["fc8"],
                            "type": "Softmax",
                            "num_classes": 1000
                        }
                    }
                }
                """)
        return self.net_json

    def get_search_space(self):
        self.search_space = copy.deepcopy(self.net_json)
        layers = self.search_space["layers"]

        layers["conv1-1"]["filter"] = {
            "_type": "choice",
            "_value": [[5, 5, 3, 64]],
        }

        layers["conv1-1"]["filter"]["_value"] = [[5, 5, 3, 64], \
                                                [11, 11, 3, 64], \
                                                [33, 33, 3, 64], \
                                                [55, 55, 3, 64], \
                                                [5, 3, 3, 64], \
                                                [5, 5, 11, 64], \
                                                [5, 5, 3, 11], \
                                                [5, 5, 3, 64], \
                                                [5, 5, 3, 64], \
                                                [5, 5, 3, 64]]
        layers["pool1"]["ksize"] = {
            "_type": "choice",
            "_value": [[1, 2, 2, 1]],
        }

        layers["pool1"]["ksize"]["_value"] = [[1, 2, 2, 1], \
                                            [1, 12, 12, 1], \
                                            [1, 22, 22, 1]]
        
        layers["conv2-1"]["filter"] = {
            "_type": "choice",
            "_value": [[5, 5, 3, 64]],
        }

        layers["conv2-1"]["filter"]["_value"] = [[5, 5, 3, 64], \
                                                [11, 11, 3, 64], \
                                                [33, 33, 3, 64], \
                                                [55, 55, 3, 64], \
                                                [5, 3, 3, 64], \
                                                [5, 5, 11, 64], \
                                                [5, 5, 3, 11], \
                                                [5, 5, 3, 64], \
                                                [5, 5, 3, 64], \
                                                [5, 5, 3, 64]]
        return self.search_space

    def launch_code(self, \
                    args, \
                    net_object, \
                    model_name, \
                    root_folder, \
                    container_id, \
                    code_folder, \
                    real_run_callback
                    ):

        layers = self.search_space["layers"]
        print(self.search_space)
        c_list = layers["conv1-1"]["filter"]["_value"]
        k_list = layers["pool1"]["ksize"]["_value"]
        c2_list = layers["conv2-1"]["filter"]["_value"]

        for filter in c_list:
            for ksize in k_list:
                for filter2 in c2_list:
                    temp_net = copy.deepcopy(self.net_json)
                    temp_net_layers = temp_net["layers"]
                    # overwrite the hyper dic for code real code rewritten
                    hyper_dic = {}
                    #temp_net_layers = ut1_MNIST_spec_origin["layers"]
                    temp_net_layers["conv1-1"]["filter"] = filter 
                    hyper_dic["conv1_kernel_h"] = filter[1]
                    hyper_dic["conv1_kernel_w"] = filter[2]
                    hyper_dic["conv1_kernel_c"] = filter[3]

                    temp_net_layers["pool1"]["ksize"] = ksize
                    hyper_dic["pool_kernel_h"] = ksize[1]
                    hyper_dic["pool_kernel_w"] = ksize[2]

                    temp_net_layers["conv2-1"]["filter"] = filter 
                    hyper_dic["conv2_kernel_h"] = filter2[1]
                    hyper_dic["conv2_kernel_w"] = filter2[2]
                    hyper_dic["conv2_kernel_c"] = filter2[3]

                    real_run_callback(args, \
                                      net_object, \
                                      model_name, \
                                      root_folder, \
                                      hyper_dic, \
                                      temp_net, \
                                      container_id, \
                                      code_folder
                                      )
        return

    def get_tensorflow_code_gen_str(self, model_name, hyper_dic, root_folder, suffix):
        if not os.path.exists(root_folder):
            os.makedirs(root_folder)
        import_part = """from tensorflow.examples.tutorials.mnist import input_data\n
import tensorflow as tf
mnist = input_data.read_data_sets("/tmp/data", one_hot=True)\n"""
        
        hyper_param_part = """conv1_kernel_h = {}\n
conv1_kernel_w = {}
conv1_kernel_c = {} 
pool_kernel_h = {}
pool_kernel_w = {}
conv2_kernel_c = {} 
conv2_kernel_w = {}
conv2_kernel_h = {} 
conv_padding = '{}'
pool_padding = '{}'
conv_stride = {}
epoch_size = {}\n""".format(
                    hyper_dic.get("conv1_kernel_h", 5),
                    hyper_dic.get("conv1_kernel_w", 5),
                    hyper_dic.get("conv1_kernel_c", 3),
                    hyper_dic.get("pool_kernel_h", 2),
                    hyper_dic.get("pool_kernel_w", 2),
                    hyper_dic.get("conv2_kernel_c", 64),
                    hyper_dic.get("conv2_kernel_w", 5),
                    hyper_dic.get("conv2_kernel_h", 5),
                    hyper_dic.get("conv_padding", "VALID"),
                    hyper_dic.get("pool_padding", "VALID"),
                    hyper_dic.get("conv_stride", 10),
                    hyper_dic.get("epoch_size", 1),
                )

        regular_part = """
tf.set_random_seed(20180130)

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

def conv2d(x, W):
    return tf.nn.conv2d(x, W, strides=[1, conv_stride, conv_stride, 1], padding=conv_padding)

def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, pool_kernel_h, pool_kernel_w, 1],
                        strides=[1, 2, 2, 1], padding=pool_padding)


sess = tf.InteractiveSession()

x = tf.placeholder(tf.float32, shape=[None, 784])
y_ = tf.placeholder(tf.float32, shape=[None, 10])

W_conv1 = weight_variable([conv1_kernel_h, conv1_kernel_w, 1, conv1_kernel_c])
b_conv1 = bias_variable([conv1_kernel_c])

x_image = tf.reshape(x, [-1, 28, 28, 1])

h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)
h_pool1 = max_pool_2x2(h_conv1)

W_conv2 = weight_variable([conv2_kernel_h, conv2_kernel_w, 32, conv2_kernel_c]) 
b_conv2 = bias_variable([64])

h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)
h_pool2 = max_pool_2x2(h_conv2)

W_fc1 = weight_variable([7 * 7 * 64, 1024])
b_fc1 = bias_variable([1024])

h_pool2_flat = tf.reshape(h_pool2, [-1, 7 * 7 * 64])
h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)

keep_prob = tf.placeholder(tf.float32)
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

W_fc2 = weight_variable([1024, 10])
b_fc2 = bias_variable([10])

y_conv = tf.nn.softmax(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)

cross_entropy = -tf.reduce_sum(y_ * tf.log(tf.clip_by_value(y_conv, 1e-10, 1.0)))
train_step = tf.train.AdamOptimizer(1e-4).minimize(cross_entropy)
correct_prediction = tf.equal(tf.argmax(y_conv, 1), tf.argmax(y_, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
sess.run(tf.initialize_all_variables())
for i in range(1):
    batch = mnist.train.next_batch(50)
    print(batch[0].shape)
    print(batch[1].shape)
    if i % 100 == 0:
        loss, train_accuracy = sess.run([cross_entropy, accuracy], feed_dict={
            x: batch[0], y_: batch[1], keep_prob: 1.0})
        print("step %d, training accuracy %g, loss %g" % (i, train_accuracy, loss))
        """
    
        # if not os.path.exists(model_name):
        #     os.makedirs(model_name)
            
        file_name = "{}/{}.py".format(root_folder, suffix)

        with open(file_name, "w") as f:
            f.write(import_part)
            f.write(hyper_param_part)
            f.write(regular_part)

        return file_name

    def get_pytorch_code_gen_str(self, \
                                model_name, \
                                hyper_dic, \
                                root_folder, \
                                suffix):
        return None

    def get_pythia_code_gen_str(self):
        return None
