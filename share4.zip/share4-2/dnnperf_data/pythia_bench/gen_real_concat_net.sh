python3 code_gen_test_launcher.py  --model_name concat --use_pythia 0 --use_tensorflow 1 --use_pytorch 1  --code_folder "/bench6path/yanjga/pythia_exp/dnncost/dnnperf_data/pythia_bench/"
