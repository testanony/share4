import copy
from io import DEFAULT_BUFFER_SIZE
import json 
import os
import subprocess
import argparse
from mnist_code_gen import *
from alexnet_code_gen import *
from base_code_gen import *
from concat_code_gen import *

parser = argparse.ArgumentParser()
parser.add_argument('-m',
                    '--model_name',
                    type=str,
                    default="mnist",
                    help='model_name')
parser.add_argument('-c',
                    '--container_id',
                    default="b66c3705c3cf",
                    type=str,
                    help='docker ps to query your container id')
parser.add_argument('-cp',
                    '--code_folder',
                    type=str,
                    default = "/bench6path/yanjga/dnncost/dnnperf_data/pythia_bench",
                    help='code path view from container, view your docker run cmd -v')
parser.add_argument('-upa',
                    '--use_pythia',
                    dest='use_pythia',
                    type=int,
                    default=0,
                    help='use pythia check')
parser.add_argument('-utf',
                    '--use_tensorflow',
                    dest='use_tensorflow',
                    type=int,
                    default=1,
                    help='use tensorflow real run')
parser.add_argument('-upt',
                    '--use_pytorch',
                    dest='use_pytorch',
                    type=int,
                    default=1,
                    help='use pytorch real run')

class NetsFactory(object):
    """ simple factory for operators 
    """
    @staticmethod
    def construct_net(net_type):
        nets_dic = {
            "mnist": MNISTNet,
            "alexnet": AlexNet,
            "concat": ConcatOp
        }

        if net_type in nets_dic:
            return nets_dic[net_type]() 
        else:
            assert False, 'the net is not exists {}'.format(op_type)   

def experiment(args, container_id, code_folder):
    model_name = args.model_name
    root_folder = "{}".format("{}_refty_test".format(model_name))
    
    if not os.path.exists(root_folder):
        os.makedirs(root_folder)
    
    factory = NetsFactory()
    # construct object
    net_object = factory.construct_net(model_name)
    # gen search space json
    net_json = net_object.get_net_json()
    # gen search space json
    search_space = net_object.get_search_space()

    # dump save search space files:
    with open("{}/{}".format(root_folder, "search_space.json"), 'w') as f:
        json_object = json.dumps(search_space, indent = 4)
        f.write(json_object)

    net_object.launch_code(args = args, \
                           net_object = net_object, \
                           model_name =model_name, \
                           root_folder = root_folder, \
                           container_id = container_id, \
                           code_folder = code_folder, \
                           real_run_callback = real_tf_pytorch_pythia_callback
                           )

    return

def real_tf_pytorch_pythia_callback(args, \
                                    net_object, \
                                    model_name, \
                                    root_folder, \
                                    hyper_dic, \
                                    temp_net, \
                                    container_id, \
                                    code_folder
                                    ):
    suffix = "" 
    # make the folder and path
    for key in hyper_dic:
        suffix += "_{}_{}".format(key, hyper_dic[key])
    
    current_folder = "{}_{}".format(model_name, suffix)
    single_model_path = "{}/{}".format(root_folder, current_folder)

    if not os.path.exists(single_model_path):
        os.makedirs(single_model_path)

    # gen search space file
    with open("{}/{}".format(single_model_path, \
            "{}_search_space.json".format(model_name)), 'w') as f:
            json_object = json.dumps(temp_net, indent = 4)
            f.write(json_object)

    if args.use_tensorflow:
        # gen real run python code for tensorflow
        real_file_path = net_object.get_tensorflow_code_gen_str( \
                                    hyper_dic = hyper_dic, \
                                    root_folder = single_model_path, \
                                    suffix = suffix)
        if real_file_path is not None:    
            # run the code gen file python scripts for tensorflow
            temp_net = code_gen_file_launcher(real_file_path, \
                                  single_model_path, \
                                  temp_net, \
                                  "tensorflow")

    if args.use_pytorch:
        # gen real run python code for tensorflow
        real_file_path = net_object.get_pytorch_code_gen_str(\
                                    hyper_dic = hyper_dic, \
                                    root_folder = single_model_path, \
                                    suffix = suffix)
        if real_file_path is not None:    
            # run the code gen file python scripts for tensorflow
            temp_net = code_gen_file_launcher(real_file_path, \
                                single_model_path, \
                                temp_net, \
                                "pytorch")

    # gen net json file #json_file_name = "mnist_{}.json".format(suffix)
    json_file_name = "{}.json".format(model_name)

    # run the code gen file python scripts for pythia check
    if args.use_pythia:
        print(args.use_pythia)
        pythia_check(container_id, \
                     temp_net, \
                     code_folder, \
                     real_file_path, \
                     single_model_path, \
                     relative_path, \
                     json_file_name)

    # gen net json file 
    with open("{}/{}".format(single_model_path, json_file_name), 'w') as f:
        json_object = json.dumps(temp_net, indent = 4)
        f.write(json_object)


def code_gen_file_launcher(real_file_path, single_model_path, temp_net, framework):
    with open("{}/{}".format(single_model_path, "log.txt"), 'w') as log:
        try:
            # 1. real run
            cmd = "python3 {}".format(real_file_path)
            #print(cmd)
            p = subprocess.Popen(cmd,
                                shell=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
            logs = []
            
            for line in p.stdout.readlines():
                log.write(line.decode("gbk"))
                logs.append(line.decode("gbk"))
            p.wait()
            
            for line in logs:
                if "Traceback" in line:
                    temp_net["exception_{}".format(framework)] = "'{}'".format(str(logs[-1]).replace("'", "\""))
        except Exception as e:
            #print(str(e))
            temp_net["exception_{}".format(framework)] = "'{}'".format(str(e).replace("'", ""))
            #print(temp_net)
    return temp_net

def pythia_check(container_id, \
                 temp_net, \
                 code_folder, \
                 real_file_path, \
                 single_model_path, \
                 relative_path, \
                 json_file_name):
    # 2. pythia check
    with open("{}/{}".format(single_model_path, "pythia_log.txt"), 'w') as log:
        try:
            relative_path = "{}/{}".format(code_folder, real_file_path)
            print("relative_path {}".format(relative_path))
            pythia_cmd = "doop -a 1-call-site-sensitive+heap -i \
                {} -id {} --platform python_2 --single-file-analysis \
                --tensor-shape-analysis --full-tensor-precision" \
                .format(relative_path, json_file_name)
            
            cmd = "docker exec -it {} {} ".format(container_id, pythia_cmd)

            print(cmd)
            p = subprocess.Popen(cmd, 
                                shell=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
            logs = []
            
            for line in p.stdout.readlines():
                log.write(line.decode("gbk"))
                logs.append(line.decode("gbk"))
            p.wait()

            # analysis the log
            for line in logs:
                detect_error = parse_pythia_log(line, temp_net)
                
                if detect_error:
                    temp_net["pythia_detect_error"] = True # detect error
                else:
                    temp_net["pythia_detect_error"] = False # not detect error

        except Exception as e:
            print(str(e))
            temp_net["pythia_exception"] = "'{}'".format(str(e).replace("'", ""))
            print(temp_net)

def parse_pythia_log(line, temp_net):
    # tensor op error (INS)                                                            0
    # tensor op error (SENS)                                                           0
    # tensor op warning (INS)                                                          0
    # tensor op warning (SENS)                                                         0
    
    if "tensor op error (INS)" in line and "0" not in line:
        temp_net["pythia_detect_stat"].append(line)
        return True
    elif "tensor op error (SENS)" in line and "0" not in line:
        temp_net["pythia_detect_stat"].append(line)
        return True
    elif "tensor op warning (INS)" in line and "0" not in line:
        temp_net["pythia_detect_stat"].append(line)
        return True
    elif "tensor op warning (SENS)" in line and "0" not in line:
        temp_net["pythia_detect_stat"].append(line)
        return True
    else:
        return False


if __name__ == "__main__":
    args = parser.parse_args()
    print(args.model_name)
    print(args.use_pythia)
    experiment(args, container_id = args.container_id, code_folder = args.code_folder)