import copy
import json 
import os
import subprocess
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-c',
                    '--container_id',
                    type=str,
                    help='docker ps to query your container id')
parser.add_argument('-cp',
                    '--code_folder',
                    type=str,
                    help='code path view from container, view your docker run cmd -v')

def mnist_experiment(container_id = "b66c3705c3cf", code_folder = "/bench6path/yanjga/dnncost/dnnperf_data/pythia_bench"):
    root_folder = "{}".format("mnist_pythia_refty_test")
    if not os.path.exists(root_folder):
        os.makedirs(root_folder)
    # gen IR json
    ut1_MNIST_spec_origin = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [50, 28, 28, 1]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [5, 5, 1, 32],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool1": {
                            "parents": ["conv1-1"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv2-1": {
                            "parents": ["pool1"],
                            "type": "Convolution",
                            "filter": [5, 5, 32, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool2": {
                            "parents": ["conv2-1"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "fc6": {
                            "parents": ["pool5"],
                            "type": "Convolution",
                            "filter": [1, 1, 64, 1024],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "fc7": {
                            "parents": ["fc6"],
                            "type": "Convolution",
                            "filter": [1, 1, 1024, 10],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": null
                        },
                        "softmax": {
                            "parents": ["fc7"],
                            "type": "Softmax",
                            "num_classes": 10
                        }
                    }
                }
                """)

    # gen search space json
    layers = ut1_MNIST_spec_origin["layers"]

    layers["conv1-1"]["filter"] = {
        "_type": "choice",
        "_value": [[5, 5, 1, 32]],
    }

    layers["conv1-1"]["filter"]["_value"] = [[5, 5, 1, 32], \
                                            [5, 5, 3, 64], \
                                            [11, 11, 3, 64], \
                                            [33, 33, 3, 64], \
                                            [55, 55, 3, 64], \
                                            [5, 3, 3, 64], \
                                            [5, 5, 11, 64], \
                                            [-5, -5, 3, 11], \
                                            [50, 50, 3, 11], \
                                            [500, 500, 3, 11] ]
    layers["pool1"]["ksize"] = {
        "_type": "choice",
        "_value": [[1, 2, 2, 1]],
    }

    layers["pool1"]["ksize"]["_value"] = [[1, 2, 2, 1], \
                                        [1, 12, 12, 1], \
                                        [1, 22, 22, 1]]
    
    layers["conv2-1"]["filter"] = {
        "_type": "choice",
        "_value": [[5, 5, 32, 64]],
    }

    layers["conv2-1"]["filter"]["_value"] = [[5, 5, 32, 64], \
                                            [11, 11, 3, 64], \
                                            [33, 33, 3, 64], \
                                            [55, 55, 3, 64], \
                                            [5, 3, 3, 64], \
                                            [5, 5, 11, 64], \
                                            [5, 5, 3, 11], \
                                            [5, 5, 3, 64], \
                                            [50, 50, 3, 64], \
                                            [25, 25, 3, 64]]
    # dump save search space files:
    with open("{}/{}".format(root_folder, "search_space.json"), 'w') as f:
        json_object = json.dumps(ut1_MNIST_spec_origin, indent = 4)
        f.write(json_object)

    print(layers["pool1"]["ksize"]["_value"])

    c_list = layers["conv1-1"]["filter"]["_value"]
    k_list = layers["pool1"]["ksize"]["_value"]
    c2_list = layers["conv2-1"]["filter"]["_value"]
    count = 0
    for filter in c_list:
        for ksize in k_list:
            for filter2 in c2_list: 
                print("count {}".format(count))
                count += 1
                temp_net = copy.deepcopy(ut1_MNIST_spec_origin)
                temp_net_layers = temp_net["layers"]
                hyper_dic = {}
                temp_net_layers = ut1_MNIST_spec_origin["layers"]
                temp_net_layers["conv1-1"]["filter"] = filter 
                hyper_dic["conv1_kernel_h"] = filter[0]
                hyper_dic["conv1_kernel_w"] = filter[1]
                hyper_dic["conv1_kernel_c"] = filter[3]

                temp_net_layers["pool1"]["ksize"] = ksize
                hyper_dic["pool_kernel_h"] = ksize[1]
                hyper_dic["pool_kernel_w"] = ksize[2]

                temp_net_layers["conv2-1"]["filter"] = filter 
                hyper_dic["conv2_kernel_h"] = filter2[0]
                hyper_dic["conv2_kernel_w"] = filter2[1]
                hyper_dic["conv2_kernel_c"] = filter2[3]
                suffix = "" 

                for key in hyper_dic:
                    suffix += "_{}_{}".format(key, hyper_dic[key])
                

                current_folder = "mnist{}_{}".format(suffix, count)
                single_model_path = "{}/{}".format(root_folder, current_folder)

                # gen real run python code
                real_file_path = code_gen_python_file_of_ut(hyper_dic = hyper_dic, \
                                        root_folder = single_model_path, \
                                        suffix = suffix)

                # gen search space file
                with open("{}/{}".format(single_model_path, "mnist_search_space.json"), 'w') as f:
                        json_object = json.dumps(ut1_MNIST_spec_origin, indent = 4)
                        f.write(json_object)

                with open("{}/{}".format(single_model_path, "log.txt"), 'w') as log:
                    try:
                        # 1. real run
                        cmd = "python3 {}".format(real_file_path)
                        p = subprocess.Popen(cmd,
                                            shell=True,
                                            stdout=subprocess.PIPE,
                                            stderr=subprocess.STDOUT)
                        logs = []
                        
                        for line in p.stdout.readlines():
                            log.write(line.decode("gbk"))
                            logs.append(line.decode("gbk"))
                        p.wait()
                        
                        for line in logs:
                            if "Error:" in line:
                                temp_net["exception"] = "'{}'".format(str(line).replace("'", "\""))
                                break
                    except Exception as e:
                        print(str(e))
                        temp_net["exception"] = "'{}'".format(str(e))#.replace("'", ""))
                        print(temp_net)
                            # gen net json file
                #json_file_name = "mnist_{}.json".format(suffix)
                json_file_name = "mnist_{}.json".format("pythia")

 
                if not os.path.exists(single_model_path):
                    os.makedirs(single_model_path)


                # 2. pythia check
                with open("{}/{}".format(single_model_path, "pythia_log.txt"), 'w') as log:
                    try:
    
                        relative_path = "{}/{}".format(code_folder, real_file_path)
                        print("relative_path {}".format(relative_path))
                        pythia_cmd = "doop -a 1-call-site-sensitive+heap -i \
                            {} -id {} --platform python_2 --single-file-analysis \
                            --tensor-shape-analysis --full-tensor-precision" \
                            .format(relative_path, json_file_name)
                        
                        cmd = "docker exec -it {} {} ".format(container_id, pythia_cmd)

                        print(cmd)
                        p = subprocess.Popen(cmd, 
                                            shell=True,
                                            stdout=subprocess.PIPE,
                                            stderr=subprocess.STDOUT)
                        logs = []
                        
                        for line in p.stdout.readlines():
                            log_line = line.decode("gbk")
                            log.write(log_line)
                            logs.append(log_line)
                        p.wait()
                    
                        # analysis the log
                        # with open("{}/{}".format(single_model_path, "pythia_log.txt"), 'r') as logfile:
                        #     logsl = logfile.readlines()
                            #print(logsl)
                        temp_net["pythia_detect_error"] = False
                        temp_net["pythia_detect_stat"] = []
                        for line in logs:
                            print(line)
                            detect_error = parse_pythia_log(line, temp_net)
                            
                            if detect_error:
                                temp_net["pythia_detect_error"] = True # detect error
                                # else:
                                #     temp_net["pythia_detect_error"] = False # not detect error

                    except Exception as e:
                        print(str(e))
                        temp_net["pythia_exception"] = "'{}'".format(str(e).replace("'", ""))
                        print(temp_net)
                            # gen net json file

                with open("{}/{}".format(single_model_path, json_file_name), 'w') as f:
                    json_object = json.dumps(temp_net, indent = 4)
                    f.write(json_object)

            # # 3. refty check
            # refty_check_cmd = ""
    return


def parse_pythia_log(line, temp_net):
    # tensor op error (INS)                                                            0
    # tensor op error (SENS)                                                           0
    # tensor op warning (INS)                                                          0
    # tensor op warning (SENS)                                                         0
    flag = False
    if "tensor op error (INS)" in line and "0" not in line:
        temp_net["pythia_detect_stat"].append(line)
        flag = True
        print(line)
    if "tensor op error (SENS)" in line and "0" not in line:
        temp_net["pythia_detect_stat"].append(line)
        flag = True
        print(line)
    if "tensor op warning (INS)" in line and ("0" not in line):
        temp_net["pythia_detect_stat"].append(line)
        flag = True
        print(line)
    if "tensor op warning (SENS)" in line and ("0" not in line):
        temp_net["pythia_detect_stat"].append(line)
        flag = True
        print(line)
    return flag


def code_gen_python_file_of_ut(hyper_dic, root_folder, suffix):
    if not os.path.exists(root_folder):
        os.makedirs(root_folder)
    # must no comments, no blank line at var
    import_part = """
from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf
mnist = input_data.read_data_sets("/tmp/data", one_hot=True)\n"""
    
    hyper_param_part = """conv1_kernel_h = {}\n
conv1_kernel_w = {}
conv1_kernel_c = {} 
pool_kernel_h = {}
pool_kernel_w = {}
conv2_kernel_c = {} 
conv2_kernel_w = {}
conv2_kernel_h = {} 
conv_padding = '{}'
pool_padding = '{}'
conv_stride = {}
epoch_size = {}\n""".format(
                hyper_dic.get("conv1_kernel_h", 5),
                hyper_dic.get("conv1_kernel_w", 5),
                hyper_dic.get("conv1_kernel_c", 3),
                hyper_dic.get("pool_kernel_h", 2),
                hyper_dic.get("pool_kernel_w", 2),
                hyper_dic.get("conv2_kernel_c", 64),
                hyper_dic.get("conv2_kernel_w", 5),
                hyper_dic.get("conv2_kernel_h", 5),
                hyper_dic.get("conv_padding", "VALID"),
                hyper_dic.get("pool_padding", "VALID"),
                hyper_dic.get("conv_stride", 1),
                hyper_dic.get("epoch_size", 1),
            )

    regular_part = """
tf.set_random_seed(20180130)

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

def conv2d(x, W):
    return tf.nn.conv2d(x, W, strides=[1, conv_stride, conv_stride, 1], padding=conv_padding)

def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, pool_kernel_h, pool_kernel_w, 1],
                        strides=[1, 2, 2, 1], padding=pool_padding)


sess = tf.InteractiveSession()

x = tf.placeholder(tf.float32, shape=[None, 784])
y_ = tf.placeholder(tf.float32, shape=[None, 10])

W_conv1 = weight_variable([conv1_kernel_h, conv1_kernel_w, 1, conv1_kernel_c])
b_conv1 = bias_variable([conv1_kernel_c])

x_image = tf.reshape(x, [-1, 28, 28, 1])

h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)
h_pool1 = max_pool_2x2(h_conv1)

W_conv2 = weight_variable([conv2_kernel_h, conv2_kernel_w, 32, conv2_kernel_c]) 
b_conv2 = bias_variable([64])

h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)
h_pool2 = max_pool_2x2(h_conv2)

W_fc1 = weight_variable([7 * 7 * 64, 1024])
b_fc1 = bias_variable([1024])

h_pool2_flat = tf.reshape(h_pool2, [-1, 7 * 7 * 64])
h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)

keep_prob = tf.placeholder(tf.float32)
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

W_fc2 = weight_variable([1024, 10])
b_fc2 = bias_variable([10])

y_conv = tf.nn.softmax(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)

cross_entropy = -tf.reduce_sum(y_ * tf.log(tf.clip_by_value(y_conv, 1e-10, 1.0)))
train_step = tf.train.AdamOptimizer(1e-4).minimize(cross_entropy)
correct_prediction = tf.equal(tf.argmax(y_conv, 1), tf.argmax(y_, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
sess.run(tf.initialize_all_variables())
for i in range(1):
    batch = mnist.train.next_batch(50)
    print(batch[0].shape)
    print(batch[1].shape)
    if i % 100 == 0:
        loss, train_accuracy = sess.run([cross_entropy, accuracy], feed_dict={
            x: batch[0], y_: batch[1], keep_prob: 1.0})
        print("step %d, training accuracy %g, loss %g" % (i, train_accuracy, loss))
    """

    file_name = "{}/mnist{}.py".format(root_folder, suffix)

    with open(file_name, "w") as f:
        f.write(import_part)
        f.write(hyper_param_part)
        f.write(regular_part)

    return file_name

if __name__ == "__main__":
    args = parser.parse_args()
    mnist_experiment(container_id = args.container_id, code_folder = args.code_folder)