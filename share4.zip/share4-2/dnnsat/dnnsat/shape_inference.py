"""Code generation of DnnSAT solver shape inference equations
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from z3 import *
from logger import logger
import math
from dnnsat.param import *
import numpy as np


def broadcast_list(inputs):
    """
    broadcast subfunction

    Args:
        inputs (list of tensor shape): 2 or more input shape

    Returns:
        list: shape of output
    """
    # print("input tensor: " + str(inputs))
    input_num = len(inputs)
    assert input_num >= 2
    if input_num == 2:
        return broadcast(inputs)
    else:
        input1 = inputs[0]
        for i in range(1, input_num):
            input2 = inputs[i]
            input1 = broadcast([input1, input2])
        return input1


def broadcast(inputs):
    """
    broadcast subfunction

    Args:
        inputs (list of tensor shape): 2 input shape

    Returns:
        list: shape of output
    """
    assert len(inputs) == 2
    input1 = inputs[0]
    input2 = inputs[1]
    len1 = len(input1)
    len2 = len(input2)

    # situation 1 -- At least one of the inputs is scalar
    if len1 == 0:
        return input2
    if len2 == 0:
        return input1

    # situation 2 -- None of them is scalar, but dimension numbers are not equivalent
    if len1 < len2:
        input1[0:0] = [1] * (len2 - len1)
    if len2 < len1:
        input2[0:0] = [1] * (len1 - len2)
    assert len(input1) == len(input2)

    # situation 3 -- Dimension numbers are also equivalent, find broadcast
    i = 0
    for x, y in zip(input1, input2):
        #assert x == y or x == 1 or y == 1
        if x < y:
            input1[i] = y
        if x > y:
            input2[i] = x
        i += 1
    #assert input2 == input1
    return input1


def no_change_output_shape(inputs):
    """
    some op don't change shape

    Args:
        inputs (list of int(dimension)): input shape
    """
    return inputs


def matmul_output_shape(inputs):
    """
    summary

    Args:
        inputs ([[list]]): input tensor A, input tensor B

    Returns:
        [type]: [description]
    Ref:https://pytorch.org/docs/stable/generated/torch.matmul.html#torch.matmul
    """
    assert len(inputs) == 2
    input0 = inputs[0]
    input1 = inputs[1]
    len0 = len(input0)
    len1 = len(input1)

    if len0 == len1 == 1:
        return []

    if len1 == 1:
        assert input0[-1] == input1[-1]
        return input0[:-1]

    batch_shape = broadcast([input0[:-1], input1[:-2]])
    assert input0[-1] == input1[-2]
    output_shape = batch_shape + input1[-1:]
    return output_shape


def reducemean_output_shape(inputs, dims, keepdims=True):
    """
    ReduceL1
    ReduceL2
    ReduceLogSum
    ReduceLogSumExp
    reducemax
    reducemean
    reducemin
    reduceprod
    reducesum
    reducesumsquare
    Args:
        inputs ([list]): input tensor shape
        dims ([list]): axes, A list of integers, 
            along which to reduce. Accepted range is [-r, r-1]
        keepdims (bool, optional): [Keep the reduced dimension or not].
            Defaults to True.

    Returns:
        list: output shape
    """
    outputs = []
    i = 0

    max_dim = len(inputs)

    if type(dims) is int:
        dims = [dims]

    for dim in dims:
        assert dim <= max_dim - 1
        assert dim >= -max_dim
        if dim < 0:
            dims[i] = max_dim + dim
        i += 1

    i = 0
    for item in inputs:
        if i in dims:
            if keepdims:
                outputs.append(1)
        else:
            outputs.append(item)
        i += 1

    return outputs


# TODO:
def expand_output_shape(inputs, shape):
    """

    Args:
        inputs ([list]): Input tensor shape
        shape ([list]): A 1-D tensor indicates the shape you want to expand to, 
            following the broadcast rule

    Returns:
        list: output shape
    """
    return []


### range
def range_output_shape(start, limit, delta=1):
    """
    Returns the output tensor shape.
    Args:
        start (scalar): First entry for the range of output values.
        limit (scalar): Exclusive upper limit for the range of output values.
        delta (int, optional): Value to step by. Defaults to 1.

    """
    assert (limit - start) * delta >= 0
    size = (float(limit) - float(start)) / float(delta)
    return [int(size) + 1]


### onnx calculates differently from pytorch
def gather_output_shape(inputs, indices, dim=0):  # hard core
    """
    Returns the output tensor shape.
    # According to pytorch, traverse indices matrix to fetch entries from inputs
    # extra constraints: dim is smaller than len(inputs)
    # extra constraints: len(indices) == len(inpuits)
    # extra constraints: for each dimension other than dim, indices <= inputs
    # extra constraints: but @ dim dimension, indices is unlimited
    Arguments:
        inputs {list} -- shape list 
        indices {list} -- index tensor's shape
        dim {int} -- the dimension to be gathered
    Ref: https://pytorch.org/docs/stable/generated/torch.gather.html#torch.gather
    """
    len1 = len(inputs)
    len2 = len(indices)
    assert len1 == len2
    for i in range(0, len2):
        if i == dim:
            continue
        assert indices[i] <= inputs[i]
    return indices


#bit_len = 64
### Convolution
# FIXME: Not consider dilation
class ConvPool:
    """
    Returns the output tensor shape.
    nn.Convolution nn.Pool Layers 
    output format: [batch_size, out_channel, out_height, out_width]
    In onnx, Conv and Pool ops are identified by w. But here we process the difference by setting output-channel by hand.
    interOp rules: filters 
    Ref: https://github.com/onnx/onnx/blob/master/onnx/defs/nn/defs.cc
    """
    def __init__(self, inputs, filters, strides, padding, dilations):
        self.inputs = inputs
        self.filters = filters
        self.strides = strides
        self.padding = padding
        self.dilations = dilations

    def infer(self):
        return self.convpool_output_shape(self.inputs, self.filters, \
            self.strides, self.padding, self.dilations)

    def convpool_output_shape(self, inputs, filters, strides, padding,
                              dilations):
        batch_size, in_channel = inputs[:2]
        dimension = inputs[2:]
        kernel_shape = filters[2:]
        if len(padding) == len(kernel_shape):
            padding_begin = padding
            padding_end = padding
        else:
            assert len(padding) == 2 * len(dimension)
            step = int(len(padding) / 2)
            padding_begin = padding[:step]
            padding_end = padding[step:]
        assert len(kernel_shape) == len(dimension) == len(dilations) == len(
            strides)
        assert in_channel == filters[1]

        effective_kernel_shape = (np.asarray(kernel_shape) -
                                  1) * np.asarray(dilations) + 1
        output_shape = ((np.asarray(dimension) + np.asarray(padding_begin) + \
            np.asarray(padding_end) - effective_kernel_shape) / np.asarray(strides) + 1).astype(int)
        return [batch_size, filters[0]] + list(output_shape)


class GlobalAveragePool(ConvPool):
    def __init__(self, inputs):
        assert len(inputs) >= 2
        len_ = len(inputs) - 2
        super().__init__(inputs, [inputs[1]] * 2 + inputs[2:], [1] * len_,
                         [0] * len_, [1] * len_)

def floor_z3(a, b):
    return (2*a - b) / (2*b)
    #return a/b

# bit_len = 64
### Convolution
# FIXME: Not consider dilation
def conv2d_output_shape(inputs, filters, strides, padding, channel_first=False):
    """
    Returns the output tensor shape.
    nn.Convolution2D Layers 
    output format: [batch_size, out_channel, out_height, out_width]
    Ref: https://pytorch.org/docs/stable/generated/torch.nn.Conv2d.html#torch.nn.Conv2d
    """
    dilation = 1
    if channel_first:
        n, c, h, w = inputs
    else:
        n, h, w, c = inputs
    kernel_h, kernel_w, in_channel, out_channel = filters
    _, stride_h, stride_w, _ = strides

    # H_out = (H_in + 2 * padding[0] - dilation[0] * (kernel_size[0] - 1) - 1) / stride[0] + 1
    h_a = (h + padding[0] + padding[1] - dilation * (kernel_h - 1) - 1)
    h_b = stride_h + 1
    w_a = (w + padding[2] + padding[3] - dilation * (kernel_w - 1) - 1)
    w_b = stride_w + 1
    # to make the results floor
    H_out = floor_z3(a = h_a, b = h_b)
    W_out = floor_z3(a = w_a, b = w_b)
    # assert H_out > 0
    # assert W_out > 0
    return [n, H_out, W_out, out_channel]


### Pool
# FIXME: Not consider dilation
def pool2d_output_shape(inputs, kernel, strides, padding, channel_first=False):
    """
    Returns the output tensor shape. 
    nn.Pooling Layers 
    Ref: https://pytorch.org/docs/stable/nn.html#pooling-layers
    """
    dilation = 1
    if channel_first:
        n, c, h, w = inputs
    else:
        n, h, w, c = inputs
    _, kernel_h, kernel_w, _ = kernel
    _, stride_h, stride_w, _ = strides
    h_a = (h + padding[0] + padding[1] - dilation * (kernel_h - 1) - 1)
    h_b = stride_h + 1
    w_a = (w + padding[2] + padding[3] - dilation * (kernel_w - 1) - 1)
    w_b = stride_w + 1
    # to make the results floor
    H_out = floor_z3(a = h_a, b = h_b)
    W_out = floor_z3(a = w_a, b = w_b)

    return [n, H_out, W_out, c]


### Activation


def activation_output_shape(inputs):
    """
    Returns the output tensor shape.
    nn.Activations supports: 
    27 ops

    ELU
    Hardshrink
    Hardtanh
    LeakyReLU
    LogSigmoid
    MultiheadAttention
    PReLU
    ReLU
    ReLU6
    RReLU
    SELU
    CELU
    GELU
    Sigmoid
    Softplus
    Softshrink
    Softsign
    Tanh
    Tanhshrink
    Threshold

    Softmin
    Softmax
    Softmax2d
    LogSoftmax
    AdaptiveLogSoftmaxWithLoss

    Ref: https://pytorch.org/docs/stable/nn.html#elu 
    """
    return inputs


def softmax_output_shape(inputs):
    """
    Returns the output tensor shape.
    nn.softmax
    Ref: https://pytorch.org/docs/stable/generated/torch.nn.Softmax.html#torch.nn.Softmax
    """
    return inputs


### BatchNorm


def batchnorm2d_output_shape(inputs):
    """
    Returns the output tensor shape.
    nn.BatchNorm2d
    Ref: https://pytorch.org/docs/stable/generated/torch.nn.BatchNorm2d.html#torch.nn.BatchNorm2d
    """
    return inputs


### Dropout


def dropout2d_output_shape(inputs):
    """
    Returns the output tensor shape.
    nn.Dropout2d
    Ref: https://pytorch.org/docs/stable/generated/torch.nn.Dropout2d.html#torch.nn.Dropout2d
    """
    return inputs


### Indexing, Slicing, Joining, Mutating Ops
# Ref: https://pytorch.org/docs/stable/torch.html#indexing-slicing-joining-mutating-ops


def concate_output_shape(inputs_list, dim, channel_first=True):
    """
    Returns the output tensor shape.
    nn.concate
    Ref: https://pytorch.org/docs/stable/generated/torch.cat.html#torch.cat
    """
    # logger.debug(_inputs_list)

    assert len(inputs_list) > 1
    outputs = []

    for i in inputs_list[0]:
        outputs.append(i)

    new_dim = 0

    for tensor in inputs_list:
        new_dim += tensor[dim]

    outputs[dim] = new_dim
    logger.debug("concat outputs: {}".format(outputs[dim]))
    logger.debug("---concat----")
    return outputs


def squeeze_output_shape(inputs, dim=None):
    """
    Returns the output tensor shape.
    squeeze
    Ref: https://pytorch.org/docs/stable/generated/torch.squeeze.html#torch.squeeze
    """
    output = []
    if dim is None:
        for i in inputs:
            if i != 1:
                output.append(i)
        return output
    else:
        for i in range(0, len(inputs)):
            if inputs[i] != 1 or i not in dim:
                output.append(inputs[i])
        return output


def transpose_output_shape(inputs, dim1, dim2):
    """
    Returns the output tensor shape.
    transpose
    Ref: https://pytorch.org/docs/stable/torch.html#torch.transpose
    """
    outputs = []
    i = 0

    for item in inputs:
        if i != dim1 and i != dim2:
            outputs.append(item)
        elif i == dim1:
            outputs.append(inputs[dim2])
        else:  # i == dim2
            outputs.append(inputs[dim1])
        i += 1

    return outputs


def reshape_output_shape(inputs, new_shape):
    """
    Returns the output tensor shape.
    reshape: _new_shape must match totalc size except it is [-1]
    Ref: https://pytorch.org/docs/stable/generated/torch.reshape.html#torch.reshape
    """
    inp = 1
    logger.debug("inputs_d: {}".format(inputs))
    logger.debug("new_shape_d: {}".format(new_shape))
    for i in inputs:
        if i != 0:
            inp *= i

    if new_shape == [-1]:
        return [inp]

    sp = 1
    for j in new_shape:
        if j != 0:
            sp *= j

    #assert inp == sp 
    #maybe we need insert it to z3
    return new_shape


def unsqueeze_output_shape(inputs, dim):  # hard code
    """
    Returns the output tensor shape.
    # extra constraints: _dim is smaller than len(_inputs)
    Arguments:
        _inputs {list} -- shape list 
        _dim {int} -- the dimension to be unsqueezed
    Ref: https://pytorch.org/docs/stable/generated/torch.unsqueeze.html#torch.unsqueeze
    """
    outputs = []
    i = 0

    max_dim = len(inputs)
    assert dim <= max_dim
    assert dim >= -1 - max_dim

    if dim < 0:
        dim = max_dim + dim + 1

    for item in inputs:
        if i == dim:
            outputs.append(1)
        outputs.append(item)
        i += 1

    if dim == max_dim:
        outputs.append(1)

    return outputs


# FIXME: onnx supports indirectional broadcast such as 2 -> 4,
# which is not supported by numpy(At least told by official tutorial)
def undirectional_broadcast_output_shape(inputs):
    """
    shape infer unidirectional broadcast
    e.g. 
        PRelu : X, slope
    Args:
        inputs (list): two input tensor shape

    Returns:
        list: 1D shape list
    """
    input1 = inputs[0]
    input2 = inputs[1]
    assert len(input1) >= len(input2)
    len1 = len(input1)
    for each in reversed(input2):
        len1 -= 1
        assert each == input1[len1] or each == 1
    return input1


### Pointwise Ops
# https://pytorch.org/docs/stable/torch.html#pointwise-ops
def elementwise_output_shape(inputs):
    """
    Returns the output tensor shape.
    pointwise
    53 ops
    abs
    acos
    add
    addcdiv
    addcmul
    angle
    asin
    atan
    atan2
    bitwise_not
    bitwise_xor
    cast ?
    ceil
    clamp
    conj
    cos
    cosh
    div
    digamma
    erf
    erfc
    erfinv
    exp
    expm1
    floor
    fmod
    frac
    imag
    lerp
    lgamma
    log
    log10
    log1p
    log2
    logical_not
    logical_xor
    mul
    mvlgamma
    neg
    polygamma
    pow
    real
    reciprocal
    remainder
    round
    rsqrt
    sigmoid
    sign
    sin
    sinh
    sqrt
    tan
    tanh
    trunc

    Ref: https://pytorch.org/docs/stable/torch.html#pointwise-ops
    """
    return inputs


def add_output_shape(inputs):  # hard core
    """
    Returns the output tensor shape.
    # extra constraints: _dim is smaller than len(_inputs)
    
    Sub
    Mul
    Div

    Arguments:
        inputs {[list, list]} -- shape of input1, shape of input2
    Ref: https://pytorch.org/docs/stable/generated/torch.add.html#torch.add
    Ref: https://pytorch.org/docs/stable/notes/broadcasting.html#broadcasting-semantics
    """
    return broadcast_list(inputs)


### RNN
# ref: https://pytorch.org/docs/stable/nn.html#rnnbase
def rnn_output_shape(seq_len, batch, input_size, num_layers, num_directions,
                     hidden_size):
    """
    Returns the output tensor shape.
    3 ops
    RNN
    LSTM
    GRU
    
    Ref: https://pytorch.org/docs/stable/nn.html#torch.nn.RNN 
    """
    outputs = [seq_len, batch, num_directions * hidden_size]
    hn = [num_layers * num_directions, batch, hidden_size]
    return outputs, hn
