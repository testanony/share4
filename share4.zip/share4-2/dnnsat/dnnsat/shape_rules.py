"""Shape rules to constraint the correctness of DL models hyperparameters
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from z3 import *
from logger import logger
import math
from dnnsat.param import *


def output_shape_positive_shape_rules(opt, parent_outputs):
    """
    make all the input and output >= 0
    to avoid conv2d valid padding to occur less zero shape
    Arguments:
        opt -- 
        parent_outputs -- 
    """
    if use_shape_rule:
        for parent_out in parent_outputs:
            for parent_dim in parent_out:
                for dim in parent_dim:
                    opt.add(dim >= 0)
    return


def conv2d_shape_rules(opt, inputs, filters, strides, paddings):
    """
    construct shape rules of conv2d

    Arguments:
        opt -- 
        inputs -- 
        filters -- 
        strides -- 
    """
    if use_shape_rule:
        batch = inputs[0]
        height = inputs[1]
        width = inputs[2]
        channel = inputs[3]
        f_height = filters[0]
        f_width = filters[1]
        f_in_channel = filters[2]
        s_height = strides[1]
        s_width = strides[2]

        #FC constraints is different should skip (NOTE)
        #opt.add(height >= 1)
        #opt.add(width >= 1)
        #opt.add(f_in_channel == channel)
        #opt.add(s_height <= f_height)
        #opt.add(s_width <= f_width)
        
        # for i in range(len(paddings)):
        #     opt.add(paddings[i] >= 0)

    return


def fc_shape_rules(opt, inputs, filters, strides):
    """
    construct shape rules of fc

    Arguments:
        opt -- 
        inputs -- 
        filters -- 
        strides -- 
    """
    if use_shape_rule:
        in_dims = 1

        for i in inputs[1:]:
            in_dims *= i

        in_filter = filters[2]
        logger.debug("in_dims {} == in_filter {}".format(in_dims, in_filter))
        opt.add(in_dims == in_filter)
    return


def pool2d_shape_rules(opt, inputs, ksizes, strides):
    """
    construct shape rules of pool2d

    Arguments:
        opt --
        inputs --
        ksizes --
        strides --
    """
    if use_shape_rule:
        batch  = inputs[0]
        height = inputs[1]
        width = inputs[2]
        channel = inputs[3]
        f_height = ksizes[1]
        f_width = ksizes[2]
        s_height = strides[1]
        s_width = strides[2]
        #opt.add(height >= 1)
        #opt.add(width >= 1)
        #opt.add(s_height <= f_height)
        #opt.add(s_width <= f_width)

    return


def concat_shape_rules(opt, input_list, dim):
    """
    construct shape rules of conv2d

    Arguments:
        opt -- description
        input_list -- description
        dim -- description
    """
    # if use_shape_rule:
    #     dim_shape = []

    #     for input in input_list:
    #         dim_shape.append(input[_dim])

    #     index = 0
    #     first = dim_shape[0]

    #     for shape in dim_shape[1:]:
    #         opt.add(first == shape)
    return


def reshape_shape_rules(opt, inputs, outputs):
    """
    construct shape rules of reshape

    Arguments:
        opt -- description
        inputs -- description
        new_shape -- description
    """
    if use_shape_rule:
        pass
        # opt.add(inputs[0] == outputs[0])
        # opt.add(outputs[1] == 1)
        # opt.add(outputs[2] == 1)
        # opt.add(outputs[3] == inputs[1] * inputs[2] * inputs[3])
    return
