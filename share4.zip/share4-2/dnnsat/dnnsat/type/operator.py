from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

class Operator(object):
    name = 0
    input_tensors = []
    output_tensors = []
    hyperparamters = []

    def __init__(self, name, input_tensors, output_tensors, hyperparameters):
        self.name = name
        self.input_tensors = input_tensors
        self.output_tensors = output_tensors
        self.hyperparameters = hyperparameters
        
    def check():
        pass

class Conv2D(Operator):

    def check():
        pass
