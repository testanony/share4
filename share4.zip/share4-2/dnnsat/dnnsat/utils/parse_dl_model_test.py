import click
import logging
import json
import subprocess
import json
import sys
import parser_entry as parser
from keras.applications.vgg16 import VGG16
import os


def check_lib():
    retry_count = 3
    while retry_count:
        try:
            import mmdnn
            break
        except:
            os.system('pip install mmdnn==0.3.0')
            retry_count -= 1
            continue


# test keras 2.1.6 passed
def dnn_cost_api_example():
    model = VGG16(weights='imagenet')
    model_file = "vgg16_keras.h5"
    model.save(model_file)

    framework = "keras"
    model_ir = "vgg16_ir"
    config = "vgg_cifar_spec.json"

    parser.parse(framework, model_file, model_ir)
    parser.gen_ir(model_ir + ".json", config)
    return


if __name__ == "__main__":
    dnn_cost_api_example()
