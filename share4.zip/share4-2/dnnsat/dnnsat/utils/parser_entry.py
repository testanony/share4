import click
import logging
import json
import subprocess
import json
import sys
import os
import inspect
currentdir = os.path.dirname(
    os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

HELP_VERBOSE = 'Whether to display debug level log messages.'


@click.group()
@click.option('--verbose', is_flag=True, help=HELP_VERBOSE)
def cli(verbose):
    if verbose:
        logger.setLevel(logging.DEBUG)


@cli.command()
@click.option('--spec_file', '-s', help='model spec path name')
@click.option('--config', '-c', help='spec config file path')
def analysis(spec_file, config):
    _analysis(spec_file, config)
    return


def _analysis(spec_file, config):
    """parse model file and generate analysis report"""
    #print("{}, {}".format(spec_file, config))

    with open(spec_file) as exec_spec_file:
        spec = json.load(exec_spec_file)
        try:
            dnnsat_spec_file = "dnnsat_" + spec_file
            cmd = "python dnnsat/utils/ir_transformer.py parse-mmdnn-to-json -i {} -o {}".format( \
                    spec_file,
                    dnnsat_spec_file
                    )
            print("Please execute cmd: {}".format(cmd))
            #result = subprocess.check_output([cmd], shell=True)
            #print(result)
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                "command '{}' return with error (code {}): {}".format(
                    e.cmd, e.returncode, e.output))

        return


def download_pretrained_model():
    cmd = "mmdownload -f {} -n {}".format( \
            "keras",
            "vgg16")
    result = subprocess.check_output([cmd], shell=True)
    print(result)
    return


def parse(framework, model_file, model_ir):
    cmd = "mmtoir -f {} -w {} -o {}".format( \
            framework,
            model_file,
            model_ir)
    print("Please execute cmd: {}".format(cmd))
    #result = subprocess.check_output([cmd], shell=True)
    #print(result)
    return


def gen_ir(spec_file, config):
    _analysis(spec_file, config)
    return


if __name__ == "__main__":
    cli()
