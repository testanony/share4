"""Code generation of DnnSAT solver shape inference equations
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from z3 import *
from logger import logger
import math
from dnnsat.param import *


### Convolution
def _conv2d_output_shape(_inputs, _filters, _strides, _padding):
    """Returns the output tensor shape.
    nn.Convolution2D Layers 
    Ref: 
    """
    n, h, w, c = _inputs
    kernel_h, kernel_w, in_channel, out_channel = _filters
    _, stride_h, stride_w, _ = _strides

    out_height_valid = 0
    out_width_valid = 0
    out_height_same = 0
    out_width_same = 0

    #if _padding == 'VALID':
    out_height_valid = (h - kernel_h + 1) / stride_h
    out_width_valid = (w - kernel_w + 1) / stride_w
    #else: # self._padding == 'SAME':
    out_height_same = _inputs[1]  # h / stride_h
    out_width_same = _inputs[2]  # w / stride_w

    out_height = _padding[0] * out_height_valid + _padding[1] \
                * out_height_same
    out_width = _padding[0] * out_width_valid + _padding[1] * out_width_same

    # assert out_height != 0
    # assert out_width != 0
    return [n, out_height, out_width, out_channel]


### Pool
def _pool2d_output_shape(_inputs, _kernel, _strides, _padding):
    """Returns the output tensor shape. 
    nn.Pooling Layers 
    """
    n, h, w, c = _inputs
    _, kernel_h, kernel_w, _ = _kernel
    _, stride_h, stride_w, _ = _strides

    out_height = 0
    out_width = 0
    # if _padding == 'VALID':
    #     out_height = int(
    #         math.ceil(float(h - kernel_h + 1) / float(stride_h)))
    #     out_width = int(
    #         math.ceil(float(w - kernel_w + 1) / float(stride_w)))
    #     # self._pad_h = 0
    #     # self._pad_w = 0
    # elif _padding == 'SAME':
    #     out_height = int(math.ceil(float(h) / float(stride_h)))
    #     out_width = int(math.ceil(float(w) / float(stride_w)))

    #if _padding == 'VALID':
    out_height_valid = (h - kernel_h + 1) / stride_h
    out_width_valid = (w - kernel_w + 1) / stride_w
    #else: # self._padding == 'SAME':
    out_height_same = _inputs[1]  #h / stride_h
    out_width_same = _inputs[2]  #w / stride_w

    out_height = _padding[0] * out_height_valid + _padding[1] \
                * out_height_same
    out_width = _padding[0] * out_width_valid + _padding[1] * out_width_same

    return [n, out_height, out_width, c]


### Activation
def _activation_output_shape(_inputs):
    """Returns the output tensor shape.
    nn.Activations supports: 
    27 ops

    ELU
    Hardshrink
    Hardtanh
    LeakyReLU
    LogSigmoid
    MultiheadAttention
    PReLU
    ReLU
    ReLU6
    RReLU
    SELU
    CELU
    GELU
    Sigmoid
    Softplus
    Softshrink
    Softsign
    Tanh
    Tanhshrink
    Threshold

    Softmin
    Softmax
    Softmax2d
    LogSoftmax
    AdaptiveLogSoftmaxWithLoss

    Ref: https://pytorch.org/docs/stable/nn.html#elu 
    """
    return _inputs


def _softmax_output_shape(_inputs):
    """Returns the output tensor shape.
    nn.softmax
    Ref: https://pytorch.org/docs/stable/nn.html#softmax
    """
    return _inputs


### BatchNorm
def _batchnorm2d_output_shape(_inputs):
    """Returns the output tensor shape.
    nn.BatchNorm2d
    Ref: https://pytorch.org/docs/stable/nn.html#torch.nn.BatchNorm2d
    """
    return _inputs


### Dropout
def _dropout2d_output_shape(_inputs):
    """Returns the output tensor shape.
    nn.Dropout2d
    Ref: https://pytorch.org/docs/stable/nn.html#dropout
    """
    return _inputs


### Concat
def _concate_output_shape(_inputs_list, _dim):
    """Returns the output tensor shape.
    nn.concate
    Ref:
    """
    logger.debug("concate _inputs_list {} ".format(_inputs_list))
    assert len(_inputs_list) > 1
    _outputs = []

    for i in _inputs_list[0]:
        _outputs.append(i)

    new_dim = 0

    for tensor in _inputs_list:
        new_dim += tensor[_dim]

    _outputs[_dim] = new_dim
    return _outputs


def _squeeze_output_shape(_inputs):
    """Returns the output tensor shape.
    squeeze
    Ref: https://pytorch.org/docs/stable/torch.html#torch.squeeze
    """
    _output = []
    for i in _inputs:
        if i != 1:
            _output.append(i)
    return _output


def _transpose_output_shape(_inputs, _dim1, _dim2):
    """Returns the output tensor shape.
    transpose
    Ref: https://pytorch.org/docs/stable/torch.html#torch.transpose
    """
    _outputs = []
    i = 0

    for item in _inputs:
        if i != _dim1 and i != _dim2:
            _outputs.append(item)
        elif i == _dim1:
            _outputs.append(_inputs[_dim2])
        else:  # i == dim2
            _outputs.append(_inputs[_dim1])
        i += 1

    return _outputs


def _reshape_output_shape(_inputs, _new_shape):
    """Returns the output tensor shape.
    reshape
    Ref: https://pytorch.org/docs/stable/torch.html#torch.squeeze
    """
    inp = 1
    for i in _inputs:
        if i != 0:
            inp *= i

    sp = 1
    for j in _new_shape:
        if j != 0:
            sp *= j

    assert inp == sp
    return _new_shape


def _unsqueeze_output_shape(_inputs, _dim):
    """Returns the output tensor shape.
    unqueeze
    Ref: https://pytorch.org/docs/stable/torch.html#torch.unsqueeze
    """
    _outputs = []
    i = 0

    for item in _inputs:
        if i != _dim:
            _outputs.append(item)
        else:
            _outputs.append(1)
        i += 1

    return _outputs


### Pointwise Ops
def _elementwise_output_shape(_inputs):
    """Returns the output tensor shape.
    pointwise
    53 ops
    abs
    acos
    add
    addcdiv
    addcmul
    angle
    asin
    atan
    atan2
    bitwise_not
    bitwise_xor
    ceil
    clamp
    conj
    cos
    cosh
    div
    digamma
    erf
    erfc
    erfinv
    exp
    expm1
    floor
    fmod
    frac
    imag
    lerp
    lgamma
    log
    log10
    log1p
    log2
    logical_not
    logical_xor
    mul
    mvlgamma
    neg
    polygamma
    pow
    real
    reciprocal
    remainder
    round
    rsqrt
    sigmoid
    sign
    sin
    sinh
    sqrt
    tan
    tanh
    trunc

    Ref: https://pytorch.org/docs/stable/torch.html#pointwise-ops
    """
    return _inputs


def _add_output_shape(_inputs):
    """Returns the output tensor shape.
    add
    Ref: 
    """
    assert len(_inputs) == 2
    assert len(_inputs[0]) == len(_inputs[1])
    return _inputs[0]


### RNN
def _rnn_output_shape(_mode,
                      _seq_len,
                      _batch,
                      _input_size,
                      _num_layers,
                      _num_directions,
                      _hidden_size,
                      _output_dim=1):

    dimIn = []
    dimIn.append(_batch)
    dimIn.append(_input_size)
    dimIn.append(1)
    dimOut = []
    dimOut.append(_batch)

    if _num_directions == 2:
        dimOut.append(_hidden_size * 2)
    else:
        dimOut.append(_hidden_size * 1)

    dimOut.append(_output_dim)

    # calculating total elements per each
    outputTensorSize = dimOut[0] * dimOut[1] * dimOut[2]
    #return outputTensorSize
    return [dimOut[0], dimOut[1], dimOut[2]]
