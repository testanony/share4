from logger import logger
from dnnsat.gen_solver_constraint import *
import numpy as np
import math


def statistics_networks(layer_list, output_file):
    """
    statistic operators and edges for graph

    Arguments:
        layer_list {[type]} -- [description]
        output_file {[type]} -- [description]
    """

    operators_num = len(layer_list)
    edges_num = 0
    for layer in layer_list:
        print("layer: ", str(layer))
        edges_num += 1
    output_file.write("net operators_num {} \n".format(operators_num))
    output_file.write("net edges num {} \n".format(edges_num))
    return


def statistics_search_spaces(search_space, output_file):
    """
    search spaces sizes

    Arguments:
        search_space --
        output_file --
    """

    if len(search_space) == 0:
        return

    search_space_size = 1
    interval_hyperparams = 0
    choice_hyperparams = 0
    space_dic = {}

    for layer_name in search_space["layers"]:
        for hyperparam in search_space["layers"][layer_name]:
            if hyperparam == "parents":
                continue
            logger.debug("{}{}".format(layer_name, hyperparam))

            if search_space["layers"][layer_name][hyperparam]["_type"] \
                == "randint":
                interval = \
                    search_space["layers"][layer_name][hyperparam]["_value"]
                left = interval[0]
                right = interval[1]
                logger.debug("assert interval")
                assert_interval(left, right)
                temp = 1

                for i in range(len(right)):
                    if left[i] < right[i]:
                        hyper_range = right[i] - left[i] + 1
                        temp *= hyper_range
                        space_dic["{}_{}_{}".format(layer_name, hyperparam, i)]\
                            = hyper_range

                search_space_size *= temp
                interval_hyperparams += 1
            elif search_space["layers"][layer_name][hyperparam]["_type"] \
                == "choice":
                hyper_size = len(\
                    search_space["layers"][layer_name][hyperparam]["_value"])
                search_space_size *= hyper_size
                choice_hyperparams += 1
                space_dic["{}_{}".format(layer_name, hyperparam)] \
                            = hyper_size
            else:
                continue

    output_file.write("search space size {}\n, {} T, {} P, {} Z, {} Y\n\n"\
        .format(search_space_size, \
        search_space_size/math.pow(1000, 4), \
        search_space_size/math.pow(1000, 5), \
        search_space_size/math.pow(1000, 7), \
        search_space_size/math.pow(1000, 8)))
    # https://en.wikipedia.org/wiki/Terabyte
    output_file.write("hyperparam size: {}\n".format(len(space_dic)))
    for h in space_dic:
        output_file.write("{}:{}\n".format(h, space_dic[h]))
    return search_space_size
