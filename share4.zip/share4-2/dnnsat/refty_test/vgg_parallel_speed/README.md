# Refty Speed Testing

## 1. Prerequest

```
conda activate py_3.6_env
```

## 2. How to run

```
cd dnncost/dnnsat/
./refty_test/vgg_parallel_speed/vgg_speed_test.sh > refty_parallel_exp_log.txt

# from log trace time, etc.

# Or direct use commands
THREAD=10
TASK=10
python ./dnnsat/parallel_dist_launcher.py -thn $THREAD -nf vgg_16.json -ss vgg_16_search_space.json -o thread_$THREAD_task_$TASK -tn $TASK

```

Outputs:
```
# times statistics
time_statistics.txt

# search spaces
results folder

## NOTE 

Error: due to use python3.8., please use python 3.6
```
    _cell_set_template_code = _make_cell_set_template_code()
  File "/home/testcluster/anaconda3/lib/python3.8/site-packages/pyspark/cloudpickle.py",                  line 126, in _make_cell_set_template_code
    return types.CodeType(
TypeError: an integer is required (got type bytes)
```

Refer solving [doc](https://blog.csdn.net/qq_37797234/article/details/106212273)