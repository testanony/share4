from z3 import *
# reference:https://ericpony.github.io/z3py-tutorial/advanced-examples.htm

solver = Solver()
TensorFormat = Datatype('tensor_format')
TensorFormat.declare('N')
TensorFormat.declare('C')
TensorFormat.declare('H')
TensorFormat = TensorFormat.create()
Conv2D0 = Const('{}'.format("Conv2D0"), TensorFormat)
solver.add(Or(Conv2D0 == TensorFormat.C, Conv2D0 == TensorFormat.H))

while solver.check() == sat:
    m = solver.model()
    solver.add(Or([sym() != m[sym] for sym in m.decls()]))
    print(m)

