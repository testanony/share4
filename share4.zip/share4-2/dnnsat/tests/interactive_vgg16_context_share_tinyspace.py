# from __future__ import absolute_import
# from __future__ import division
# from __future__ import print_function

import logging
import os
import click
import sys
sys.path.append('../dnnsat')
import time
from dnnsat.csp_solving import constraint_solving
from logger import logger
from dnnsat.dnnsat import DnnSAT
from dnnsat.csp_solving import check
from paleo.graph import OperationGraph
from paleo import device
import json
import argparse

parser = argparse.ArgumentParser(description='Perf experiment for Refty')
parser.add_argument('-sss',
                    '--search_space_size',
                    default=0,
                    type=int,
                    help='search_space size')

def test_model():
    args = parser.parse_args()
    device_name = "P40"
    init_start = time.time()
    alexnet_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv1-2": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool1": {
                            "parents": ["conv1-2"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv2-1": {
                            "parents": ["pool1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 128],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv2-2": {
                            "parents": ["conv2-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 128, 128],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool2": {
                            "parents": ["conv2-2"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv3-1": {
                            "parents": ["pool2"],
                            "type": "Convolution",
                            "filter": [3, 3, 128, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv3-2": {
                            "parents": ["conv3-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv3-3": {
                            "parents": ["conv3-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool3": {
                            "parents": ["conv3-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv4-1": {
                            "parents": ["pool3"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv4-2": {
                            "parents": ["conv4-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv4-3": {
                            "parents": ["conv4-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool4": {
                            "parents": ["conv4-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv5-1": {
                            "parents": ["pool4"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv5-2": {
                            "parents": ["conv5-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv5-3": {
                            "parents": ["conv5-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool5": {
                            "parents": ["conv5-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "fc6": {
                            "parents": ["pool5"],
                            "type": "Convolution",
                            "filter": [7, 7, 512, 4096],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "fc7": {
                            "parents": ["fc6"],
                            "type": "Convolution",
                            "filter": [1, 1, 4096, 4096],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "dropout7": {
                            "parents": ["fc7"],
                            "type": "Dropout",
                            "dropout_keep_prob": 0.5
                        },
                        "fc8": {
                            "parents": ["dropout7"],
                            "type": "Convolution",
                            "filter": [1, 1, 4096, 1000],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": null
                        },
                        "softmax": {
                            "parents": ["fc8"],
                            "type": "Softmax",
                            "num_classes": 1000
                        }
                    }
                }
                """)

    # 50 ss
    # search_space = json.loads("""
    #             {
    #             "name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 1,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ],
    #                             [
    #                                 50,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ]
    #                         ]
    #                     }
    #                 }
    #             }
    #         }
    # """)

    # space 100
    # search_space = json.loads("""
    #             {
    #             "name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 1,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ],
    #                             [
    #                                 100,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ]
    #                         ]
    #                     }
    #                 }
    #             }
    #         }
    # """)

    # tiny space 20000
    # search_space = json.loads("""
    #             {
    #             "name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 1,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ],
    #                             [
    #                                 20000,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ]
    #                         ]
    #                     }
    #                 }
    #             }
    #         }
    # """)

    # search_space = json.loads("""{
    #                 "name": "VGG 16 - FROM SLIM",
    #                 "layers": {
    #                     "conv1-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 3, 64], [5, 5, 3, 64]]}
    #                     },
    #                     "conv1-2": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 64, 64], [5, 5, 64, 64]]}
    #                     },
    #                     "conv2-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 64, 128], [5, 5, 64, 128]]}
    #                     },
    #                     "conv2-2": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 128, 128], [5, 5, 128, 128]]}
    #                     },
    #                     "conv3-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 128, 256], [5, 5, 128, 256]]}
    #                     },
    #                     "conv3-2": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 256, 256], [5, 5, 256, 256]]}
    #                     },
    #                     "conv3-3": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 256, 256], [5, 5, 256, 256]]}
    #                     },
    #                     "conv4-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 256, 512], [5, 5, 256, 512]]}
    #                     },
    #                     "conv4-2": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 512, 512], [5, 5, 512, 512]]}
    #                     },
    #                     "conv4-3": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 512, 512], [5, 5, 512, 512]]}
    #                     },
    #                     "conv5-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 512, 512], [5, 5, 512, 512]]}
    #                     },
    #                     "conv5-2": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 512, 512], [5, 5, 512, 512]]}
    #                     },
    #                     "conv5-3": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 512, 512], [5, 5, 512, 512]]}
    #                     }
    #                 }
    #             }
    # """)

    # 3^10 = 59049 seach space, 11~13s context overhead, 0.058 space overhead

    # search_space = json.loads("""{
    #                 "name": "VGG 16 - FROM SLIM",
    #                 "layers": {
    #                     "conv1-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 3, 64], [5, 5, 3, 64]]}
    #                     },
    #                     "conv1-2": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 64, 64], [5, 5, 64, 64]]}
    #                     },
    #                     "conv2-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 64, 128], [5, 5, 64, 128]]}
    #                     },
    #                     "conv2-2": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 128, 128], [5, 5, 128, 128]]}
    #                     },
    #                     "conv3-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 128, 256], [5, 5, 128, 256]]}
    #                     }
    #                 }
    #             }
    # """)

    # Tiny Space
    # 

    # search_space = json.loads("""{
    #                 "name": "VGG 16 - FROM SLIM",
    #                 "layers": {
    #                     "conv1-1": {
    #                         "filter": {"_type": "randint", "_value": [[3, 3, 3, 64], [5, 5, 3, 64]]}
    #                     }
    #                 }
    #             }
    # """)

    # # tiny space 3840/12=320 3840/8=480 3840/4=960 3840/1 =3840
    # search_space = json.loads("""
    #             {
    #             "name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 1,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ],
    #                             [
    #                                 3840,
    #                                 224,
    #                                 224,
    #                                 3
    #                             ]
    #                         ]
    #                     }
    #                 }
    #             }
    #         }
    # """)

  # InceptionV3 full search space 59,049
    # search_space = json.loads("""
    #             {
    #             "name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 24,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     },
    #                 "Conv2d_1a_3x3": {
    #                     "filter": {"_type": "randint", "_value": [[1, 1, 3, 32], [3, 3, 3, 32]]}
    #                 },
    #                 "Conv2d_2a_3x3": {
    #                     "filter": {"_type": "randint", "_value": [[1, 1, 32, 32], [3, 3, 32, 32]]}
    #                 },
    #                 "Conv2d_2b_3x3": {
    #                     "filter": {"_type": "randint", "_value": [[1, 1, 32, 64], [3, 3, 32, 64]]}
    #                 }
    #             }
    #         }
    # """)


    inception_spec = json.loads("""
{
    "name": "Inception v3",
    "layers": {
        "data": {
            "parents": [],
            "type": "Input",
            "tensor": [16,229,229,3]
        },
        "Conv2d_1a_3x3": {
            "parents": ["data"],
            "type": "Convolution",
            "filter": [3, 3, 3, 32],
            "padding": "VALID",
            "strides": [1, 2, 2, 1],
            "activation_fn": "relu",
            "normalizer_fn": "batch_norm"
        },
        "Conv2d_2a_3x3": {
            "parents": ["Conv2d_1a_3x3"],
            "type": "Convolution",
            "filter": [3, 3, 32, 32],
            "padding": "VALID",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu",
            "normalizer_fn": "batch_norm"
        },
         "Conv2d_2b_3x3": {
            "parents": ["Conv2d_2a_3x3"],
            "type": "Convolution",
            "filter": [3, 3, 32, 64],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu",
            "normalizer_fn": "batch_norm"
        },
        "MaxPool_3a_3x3": {
            "parents": ["Conv2d_2b_3x3"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "Conv2d_3b_1x1": {
            "parents": ["MaxPool_3a_3x3"],
            "type": "Convolution",
            "filter": [1, 1, 64, 80],
            "padding": "VALID",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu",
            "normalizer_fn": "batch_norm"
        },
        "Conv2d_4a_3x3": {
            "parents": ["Conv2d_3b_1x1"],
            "type": "Convolution",
            "filter": [3, 3, 80, 192],
            "padding": "VALID",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu",
            "normalizer_fn": "batch_norm"
        },
        "MaxPool_5a_3x3": {
            "parents": ["Conv2d_4a_3x3"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "Mixed_5b": {
            "type": "Block",
            "parents": ["MaxPool_5a_3x3"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 192, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 192, 48],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_5x5": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [5, 5, 48, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 192, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_3x3": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 64, 96],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_3x3": {
                    "parents": ["Branch_2/Conv2d_0b_3x3"],
                    "type": "Convolution",
                    "filter": [3, 3, 96, 96],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 192, 32],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/Conv2d_0b_5x5",
                        "Branch_2/Conv2d_0c_3x3",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_5c": {
            "type": "Block",
            "parents": ["Mixed_5b/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 256, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 256, 48],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_5x5": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [5, 5, 48, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 256, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_3x3": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 64, 96],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_3x3": {
                    "parents": ["Branch_2/Conv2d_0b_3x3"],
                    "type": "Convolution",
                    "filter": [3, 3, 96, 96],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 256, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/Conv2d_0b_5x5",
                        "Branch_2/Conv2d_0c_3x3",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_5d": {
            "type": "Block",
            "parents": ["Mixed_5c/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 288, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 288, 48],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_5x5": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [5, 5, 48, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 288, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_3x3": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 64, 96],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_3x3": {
                    "parents": ["Branch_2/Conv2d_0b_3x3"],
                    "type": "Convolution",
                    "filter": [3, 3, 96, 96],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 288, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/Conv2d_0b_5x5",
                        "Branch_2/Conv2d_0c_3x3",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_6a": {
            "type": "Block",
            "parents": ["Mixed_5d/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_1a_3x3": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [3, 3, 288, 384],
                    "padding": "VALID",
                    "strides": [1, 2, 2, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 288, 64],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_3x3": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 64, 96],
                    "padding": "VALID",
                    "strides": [1, 2, 2, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/MaxPool_1a_3x3": {
                    "parents": [],
                    "type": "Pooling",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 2, 2, 1],
                    "padding": "VALID"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_1a_3x3",
                        "Branch_1/Conv2d_0b_3x3",
                        "Branch_2/MaxPool_1a_3x3"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_6b": {
            "type": "Block",
            "parents": ["Mixed_6a/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 128],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_1x7": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 128, 128],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_7x1": {
                    "parents": ["Branch_1/Conv2d_0b_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 128, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 128],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_7x1": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [7, 1, 128, 128],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_1x7": {
                    "parents": ["Branch_2/Conv2d_0b_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 128, 128],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0d_7x1": {
                    "parents": ["Branch_2/Conv2d_0c_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 128, 128],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0e_1x7": {
                    "parents": ["Branch_2/Conv2d_0d_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 128, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/Conv2d_0b_7x1",
                        "Branch_2/Conv2d_0e_1x7",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_6c": {
            "type": "Block",
            "parents": ["Mixed_6b/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_1x7": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_7x1": {
                    "parents": ["Branch_1/Conv2d_0b_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 160, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_7x1": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [7, 1, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_1x7": {
                    "parents": ["Branch_2/Conv2d_0b_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0d_7x1": {
                    "parents": ["Branch_2/Conv2d_0c_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0e_1x7": {
                    "parents": ["Branch_2/Conv2d_0d_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 160, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/Conv2d_0b_7x1",
                        "Branch_2/Conv2d_0e_1x7",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_6d": {
            "type": "Block",
            "parents": ["Mixed_6c/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_1x7": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_7x1": {
                    "parents": ["Branch_1/Conv2d_0b_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 160, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_7x1": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [7, 1, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_1x7": {
                    "parents": ["Branch_2/Conv2d_0b_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0d_7x1": {
                    "parents": ["Branch_2/Conv2d_0c_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 160, 160],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0e_1x7": {
                    "parents": ["Branch_2/Conv2d_0d_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 160, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/Conv2d_0b_7x1",
                        "Branch_2/Conv2d_0e_1x7",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_6e": {
            "type": "Block",
            "parents": ["Mixed_6d/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_1x7": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_7x1": {
                    "parents": ["Branch_1/Conv2d_0b_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_7x1": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [7, 1, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_1x7": {
                    "parents": ["Branch_2/Conv2d_0b_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0d_7x1": {
                    "parents": ["Branch_2/Conv2d_0c_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0e_1x7": {
                    "parents": ["Branch_2/Conv2d_0d_7x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/Conv2d_0b_7x1",
                        "Branch_2/Conv2d_0e_1x7",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_7a": {
            "type": "Block",
            "parents": ["Mixed_6e/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_0/Conv2d_1a_3x3": {
                    "parents": ["Branch_0/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 192, 320],
                    "padding": "VALID",
                    "strides": [1, 2, 2, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 768, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_1x7": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [1, 7, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_7x1": {
                    "parents": ["Branch_1/Conv2d_0b_1x7"],
                    "type": "Convolution",
                    "filter": [7, 1, 192, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_1a_3x3": {
                    "parents": ["Branch_1/Conv2d_0b_7x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 192, 192],
                    "padding": "VALID",
                    "strides": [1, 2, 2, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/MaxPool_1a_3x3": {
                    "parents": [],
                    "type": "Pooling",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 2, 2, 1],
                    "padding": "VALID"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_1a_3x3",
                        "Branch_1/Conv2d_1a_3x3",
                        "Branch_2/MaxPool_1a_3x3"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_7b": {
            "type": "Block",
            "parents": ["Mixed_7a/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 1280, 320],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                 "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 1280, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_1x3": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [1, 3, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_3x1": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 1, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/concat": {
                    "parents": [
                        "Branch_1/Conv2d_0b_1x3",
                        "Branch_1/Conv2d_0b_3x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 1280, 448],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_3x3": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 448, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_1x3": {
                    "parents": ["Branch_2/Conv2d_0b_3x3"],
                    "type": "Convolution",
                    "filter": [1, 3, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0d_3x1": {
                    "parents": ["Branch_2/Conv2d_0b_3x3"],
                    "type": "Convolution",
                    "filter": [3, 1, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/concat": {
                    "parents": [
                        "Branch_2/Conv2d_0c_1x3",
                        "Branch_2/Conv2d_0d_3x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 1280, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/concat",
                        "Branch_2/concat",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Mixed_7c": {
            "type": "Block",
            "parents": ["Mixed_7b/concat"],
            "endpoint": "concat",
            "layers": {
                "Branch_0/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 2048, 320],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                 "Branch_1/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 2048, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_1x3": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [1, 3, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/Conv2d_0b_3x1": {
                    "parents": ["Branch_1/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 1, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_1/concat": {
                    "parents": [
                        "Branch_1/Conv2d_0b_1x3",
                        "Branch_1/Conv2d_0b_3x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                },
                "Branch_2/Conv2d_0a_1x1": {
                    "parents": [],
                    "type": "Convolution",
                    "filter": [1, 1, 2048, 448],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0b_3x3": {
                    "parents": ["Branch_2/Conv2d_0a_1x1"],
                    "type": "Convolution",
                    "filter": [3, 3, 448, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0c_1x3": {
                    "parents": ["Branch_2/Conv2d_0b_3x3"],
                    "type": "Convolution",
                    "filter": [1, 3, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/Conv2d_0d_3x1": {
                    "parents": ["Branch_2/Conv2d_0b_3x3"],
                    "type": "Convolution",
                    "filter": [3, 1, 384, 384],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "Branch_2/concat": {
                    "parents": [
                        "Branch_2/Conv2d_0c_1x3",
                        "Branch_2/Conv2d_0d_3x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                },
                "Branch_3/AvgPool_0a_3x3": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 3, 3, 1],
                    "strides": [1, 1, 1, 1],
                    "padding": "SAME"
                },
                "Branch_3/Conv2d_0b_1x1": {
                    "parents": ["Branch_3/AvgPool_0a_3x3"],
                    "type": "Convolution",
                    "filter": [1, 1, 2048, 192],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": "relu",
                    "normalizer_fn": "batch_norm"
                },
                "concat": {
                    "parents": [
                        "Branch_0/Conv2d_0a_1x1",
                        "Branch_1/concat",
                        "Branch_2/concat",
                        "Branch_3/Conv2d_0b_1x1"
                    ],
                    "type": "Concatenate",
                    "dim": 3
                }
            }
        },
        "Logits": {
            "type": "Block",
            "parents": ["Mixed_7c/concat"],
            "endpoint": "Conv2d_1c_1x1",
            "layers": {
                "AvgPool_1a_8x8": {
                    "parents": [],
                    "type": "AvgPool",
                    "ksize": [1, 8, 8, 1],
                    "strides": [1, 2, 2, 1],
                    "padding": "VALID"
                },
                "Dropout_1b": {
                    "parents": ["AvgPool_1a_8x8"],
                    "type": "Dropout",
                    "dropout_keep_prob": 0.5
                },
                "Conv2d_1c_1x1": {
                    "parents": ["Dropout_1b"],
                    "type": "Convolution",
                    "filter": [1, 1, 2048, 1000],
                    "padding": "SAME",
                    "strides": [1, 1, 1, 1],
                    "activation_fn": null,
                    "normalizer_fn": null
                }
            }
        },
        "softmax": {
            "parents": ["Logits/Conv2d_1c_1x1"],
            "type": "Softmax",
            "num_classes": 1000
        }
    }
}""")

    # search space  50,100,200,500,4920,7381,14762,59049
    # Warmup time 69.5s, 0.007s without domain build, domain build 0.26s
    # [2021-08-30 07:46:40,076;DEBUG;interactive_vgg16_context_share_tinyspace.py:1675 -           test_model() ] check result sat
    # warmup time 65.38094902038574 s, check per solution time [0.2658724784851074, 0.28935980796813965, 0.2803332805633545, 0.2634282112121582, 0.2675497531890869, 0.2805943489074707, 0.2795379161834717, 0.2664463520050049, 0.27294063568115234, 0.28308725357055664] s
    # search_space = json.loads("""
    #             {
    #             "name": "Inception v3",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 24,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }
    #                 }
    #             }}""")
    # search_space = json.loads("""{"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 24,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }},
    #                 "Conv2d_1a_3x3": {
    #                     "filter": {"_type": "randint", "_value": [[1, 1, 3, 32], [3, 3, 3, 32]]}
    #                 },
    #                 "Conv2d_2a_3x3": {
    #                     "filter": {"_type": "randint", "_value": [[1, 1, 32, 32], [3, 3, 32, 32]]}
    #                 },
    #                 "Conv2d_2b_3x3": {
    #                     "filter": {"_type": "randint", "_value": [[1, 1, 32, 64], [3, 3, 32, 64]]}
    #                 }
    #             }}""")

    # search_space = json.loads("""
    #         {"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 24,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }},
    #                 "Conv2d_1a_3x3": {
    #                     "filter": {"_type": "choice", "_value": [[1, 1, 3, 32], [2, 2, 3, 32], [3, 3, 3, 32]]}
    #                 },
    #                 "Conv2d_2a_3x3": {
    #                     "filter": {"_type": "choice", "_value": [[1, 1, 32, 32], [2, 2, 32, 32],[3, 3, 32, 32]]}
    #                 },
    #                 "Conv2d_2b_3x3": {
    #                     "filter": {"_type": "choice", "_value": [[1, 1, 32, 64], [2, 2, 32, 64], [3, 3, 32, 64]]}
    #                 }
    #             }}""")

    #50 ss warmup time 65.45200514793396 s, check per solution time [7.615781307220459] s total time 73.06727910041809
    # search_space_50 = json.loads("""
    #         {"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 20,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }}
    #             }}""")
    # warmup time 66.9765841960907 s, check per solution time [16.851526260375977] s total time 83.82754325866699
    # search_space_100 = json.loads("""
    #         {"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 26,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }}
    #             }}""")
    # 200 ss warmup time 72.8518283367157 s, check per solution time [37.3297860622406] s total time 110.18091249465942
    # search_space_200 = json.loads("""
    #         {"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 38,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }}
    #             }}""")
    
    # 500 ss warmup time 65.2633593082428 s, check per solution time [81.66332626342773] s total time 146.92617201805115
    # search_space_500 = json.loads("""
    #         {"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 71,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }}
    #             }}""")
    # 4920 warmup time 65.86247110366821 s, check per solution time [906.9612512588501] s total time 972.8231539726257
    # search_space_4920 = json.loads("""
    #         {"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 562,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }}
    #             }}""")
    # 7381 warmup time 65.95671844482422 s, check per solution time [1675.135110616684] s total time 1741.0913639068604

    # search_space_7381 = json.loads("""
    #         {"name": "nets/vgg16.json_4",
    #             "layers": {
    #                 "data": {
    #                     "tensor": {
    #                         "_type": "randint",
    #                         "_value": [
    #                             [
    #                                 16,
    #                                 299,
    #                                 299,
    #                                 3
    #                             ],
    #                             [
    #                                 836,
    #                                 301,
    #                                 301,
    #                                 3
    #                             ]
    #                         ]
    #                     }}
    #             }}""")
    # warmup time 64.91883325576782 s, check per solution time [6765.244819879532] s total time 6830.1629683971405

    if args.search_space_size == 14762: 
        search_space_14762 = json.loads("""
                {"name": "nets/vgg16.json_4",
                    "layers": {
                        "data": {
                            "tensor": {
                                "_type": "randint",
                                "_value": [
                                    [
                                        16,
                                        299,
                                        299,
                                        3
                                    ],
                                    [
                                        1656,
                                        301,
                                        301,
                                        3
                                    ]
                                ]
                            }}
                    }}""")
        search_space = search_space_14762

    if args.search_space_size == 59049:
        search_space_59049 = json.loads("""
                {"name": "nets/vgg16.json_4",
                    "layers": {
                        "data": {
                            "tensor": {
                                "_type": "randint",
                                "_value": [
                                    [
                                        16,
                                        299,
                                        299,
                                        3
                                    ],
                                    [
                                        6577,
                                        301,
                                        301,
                                        3
                                    ]
                                ]
                            }}
                    }}""")

    if args.search_space_size == 29524:
        search_space_29524 = json.loads("""
                {"name": "nets/vgg16.json_4",
                    "layers": {
                        "data": {
                            "tensor": {
                                "_type": "randint",
                                "_value": [
                                    [
                                        16,
                                        299,
                                        299,
                                        3
                                    ],
                                    [
                                        3264,
                                        301,
                                        301,
                                        3
                                    ]
                                ]
                            }}
                    }}""")
        search_space = search_space_29524
    # armup time 75.71819472312927 s, check per solution time [10473.686694383621] s total time 10549.404260396957

    if args.search_space_size == 14762:
        search_space_14762 = json.loads("""
                {"name": "nets/vgg16.json_4",
                    "layers": {
                        "data": {
                            "tensor": {
                                "_type": "randint",
                                "_value": [
                                    [
                                        16,
                                        299,
                                        299,
                                        3
                                    ],
                                    [
                                        1656,
                                        301,
                                        301,
                                        3
                                    ]
                                ]
                            }}
                    }}""")
        search_space = search_space_14762
    # search space  50,100,200,500,4920,7381,14762,59049

    # 3690,1845,1230
   # search_space = {}
    # op:  input
    # Inceptionv3 warmup time 3.515742063522339 s, check per solution time [0.18738079071044922] s total time 3.7025859355926514,         paleo warmup time 0.005815744400024414, constraint context warmup time 3.1760740280151367
    # VGG  check per solution time [0.0452423095703125] s total time 0.8169183731079102,         paleo warmup time 0.0009160041809082031, constraint context warmup time 0.6766495704650879
    # Alexnet  check per solution time [0.029897689819335938] s total time 0.6089394092559814,         paleo warmup time 0.0006275177001953125, constraint context warmup time 0.5086839199066162
    # 2 op for single op exp
    # 3 op for seq2seq, add, concat
    vgg_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv1-2": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool1": {
                            "parents": ["conv1-2"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv2-1": {
                            "parents": ["pool1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 128],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv2-2": {
                            "parents": ["conv2-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 128, 128],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool2": {
                            "parents": ["conv2-2"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv3-1": {
                            "parents": ["pool2"],
                            "type": "Convolution",
                            "filter": [3, 3, 128, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv3-2": {
                            "parents": ["conv3-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv3-3": {
                            "parents": ["conv3-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool3": {
                            "parents": ["conv3-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv4-1": {
                            "parents": ["pool3"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv4-2": {
                            "parents": ["conv4-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv4-3": {
                            "parents": ["conv4-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool4": {
                            "parents": ["conv4-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv5-1": {
                            "parents": ["pool4"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv5-2": {
                            "parents": ["conv5-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv5-3": {
                            "parents": ["conv5-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool5": {
                            "parents": ["conv5-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "fc6": {
                            "parents": ["pool5"],
                            "type": "Convolution",
                            "filter": [7, 7, 512, 4096],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "fc7": {
                            "parents": ["fc6"],
                            "type": "Convolution",
                            "filter": [1, 1, 4096, 4096],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "dropout7": {
                            "parents": ["fc7"],
                            "type": "Dropout",
                            "dropout_keep_prob": 0.5
                        },
                        "fc8": {
                            "parents": ["dropout7"],
                            "type": "Convolution",
                            "filter": [1, 1, 4096, 1000],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": null
                        },
                        "softmax": {
                            "parents": ["fc8"],
                            "type": "Softmax",
                            "num_classes": 1000
                        }
                    }
                }
                """)

    alex_spec = json.loads("""
    {
    "name": "AlexNet V2 One weird trick - From SLIM",
    "layers": {
        "data": {
            "parents": [],
            "type": "Input",
            "tensor": [128, 224, 224, 3]
        },
        "conv1": {
            "parents": ["data"],
            "type": "Convolution",
            "filter": [11, 11, 3, 64],
            "padding": "VALID",
            "strides": [1, 4, 4, 1],
            "activation_fn": "relu"
        },
        "pool1": {
            "parents": ["conv1"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "conv2": {
            "parents": ["pool1"],
            "type": "Convolution",
            "filter": [5, 5, 64, 192],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "pool2": {
            "parents": ["conv2"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "conv3": {
            "parents": ["pool2"],
            "type": "Convolution",
            "filter": [3, 3, 192, 384],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "conv4": {
            "parents": ["conv3"],
            "type": "Convolution",
            "filter": [3, 3, 384, 384],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "conv5": {
            "parents": ["conv4"],
            "type": "Convolution",
            "filter": [3, 3, 384, 256],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "pool5": {
            "parents": ["conv5"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "fc6": {
            "parents": ["pool5"],
            "type": "Convolution",
            "filter": [5, 5, 256, 4096],
            "padding": "VALID",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "dropout6": {
            "parents": ["fc6"],
            "type": "Dropout",
            "dropout_keep_prob": 0.5
        },
        "fc7": {
            "parents": ["dropout6"],
            "type": "Convolution",
            "filter": [1, 1, 4096, 4096],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "dropout7": {
            "parents": ["fc7"],
            "type": "Dropout",
            "dropout_keep_prob": 0.5
        },
        "fc8": {
            "parents": ["dropout7"],
            "type": "Convolution",
            "filter": [1, 1, 4096, 1000],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": null
        },
        "softmax": {
            "parents": ["fc8"],
            "type": "Softmax",
            "num_classes": 1000
        }
    }
}
""")
    # op2  check per solution time [0.011435747146606445] s total time 0.06473731994628906,         paleo warmup time 0.0002455711364746094, constraint context warmup time 0.04230833053588867

    op2 =  json.loads("""
    {
    "name": "AlexNet V2 One weird trick - From SLIM",
    "layers": {
        "data": {
            "parents": [],
            "type": "Input",
            "tensor": [128, 224, 224, 3]
        },
        "conv1": {
            "parents": ["data"],
            "type": "Convolution",
            "filter": [11, 11, 3, 64],
            "padding": "VALID",
            "strides": [1, 4, 4, 1],
            "activation_fn": "relu"
        }}}
    """)
    # op3 check per solution time [0.013171195983886719] s total time 0.14812517166137695,         paleo warmup time 0.0002903938293457031, constraint context warmup time 0.1119534969329834
    op3 =  json.loads("""{
    "name": "AlexNet V2 One weird trick - From SLIM",
    "layers": {
        "data": {
            "parents": [],
            "type": "Input",
            "tensor": [128, 224, 224, 3]
        },
        "conv1": {
            "parents": ["data"],
            "type": "Convolution",
            "filter": [11, 11, 3, 64],
            "padding": "VALID",
            "strides": [1, 4, 4, 1],
            "activation_fn": "relu"
        },
        "pool1": {
            "parents": ["conv1"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        }}}""")

    mnist_spec =  json.loads("""{
        "name": "concat_op",
        "layers": {
            "data1": {
                "parents": [],
                "type": "Input",
                "datatype": "float32",
                "dataformat": ["N", "C", "H", "W"],
                "tensor": [128, 224, 224, 3]
            },
            "data2": {
                "parents": [],
                "type": "Input",
                "datatype": "float32",
                "dataformat": ["N", "C", "H", "W"],
                "tensor": [128, 224, 224, 3]
            },
            "concat": {
                "parents": [
                    "data1",
                    "data2"
                ],
                "datatype": "float32",
                "dataformat": ["N", "C", "H", "W"],
                "type": "Concatenate",
                "dim": 3
            }
        }
    }""")
    #alex_spec = vgg_spec
    alexnet_spec = mnist_spec #alex_spec#inception_spec#alex_spec
    #alexnet_spec = op2
    #alexnet_spec = op3
    if args.search_space_size == 0:
        search_space = {}
    total_start = time.time()
    paleo_time_start = time.time()
    dnnsat = DnnSAT(net=alexnet_spec)
    paleo_time_end = time.time()
    dnnsat_time_start = time.time()
    sym_name_dic = dnnsat.warm_up(device_name=device_name, search_space=search_space)
    dnnsat_time_end = time.time()
    logger.info("sym_name_dic {}".format(sym_name_dic))
    init_end = time.time()
    # tiny space 50, per space 1.88s
    # tiny space 100, per space 3.78s
    # tiny space 200, per space 7.613s
    # tiny space 320, per space 12.16s
    # tiny space 480, per space 18.9s
    # tiny space 960, per space 37.4s
    # tiny space 3840, per space 170.5s
    
    time_list = []
    space_num = 1

    for i in range(space_num):
        start = time.time()
        result = dnnsat.interactive_check(device_name=device_name, search_space=search_space, sym_name_dic = sym_name_dic)
        end = time.time()
        logger.debug("check result {}".format(result))
        time_list.append(end -start)

    total_end = time.time()
    print("warmup time {} s, check per solution time {} s total time {}, \
        paleo warmup time {}, constraint context warmup time {}"\
        .format(init_end - init_start, time_list, total_end - total_start, \
        paleo_time_end - paleo_time_start, dnnsat_time_end - dnnsat_time_start))

test_model()
