#! /bin/bash
export PYTHONPATH=$(pwd):$PYTHONPATH
python3 dnnsat/unit_test/shape_infer_test.py "$@"
