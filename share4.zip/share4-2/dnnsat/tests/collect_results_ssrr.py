import os
import sys 
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)  

root_folder = "results/autodnnsat"
file_ss = "dnnsat_global_statistic.txt"

for filename in os.listdir(root_folder):
    fname = "{}/{}/{}".format(root_folder, filename, file_ss)
    print(fname)
    if os.path.isfile(fname):
        with open(fname, 'r') as f:
            text_list = f.readlines()
            print("File {}".format(filename))
            for l in text_list:
                if "search space ratio" in l:
                    words = l.split(" ")
                    count = float(words[len(words) - 1])
                    print("search space pruning rate {}".format(count))
                    print("search space pruning rate {}".format(
                        (1 - count) * 100))
                if "SAT solutions count" in l:
                    words = l.split(" ")
                    count = int(words[len(words) - 1])
                    print("SAT solutions count {}".format(count))
                if "search space count" in l:
                    words = l.split(" ")
                    count = int(words[len(words) - 1])
                    print("search space count {}".format(count))
