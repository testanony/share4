import os
import click
import sys
#sys.path.append("..") 
#from logger import logger
import logging
import subprocess
import json
def list_folders(dir):
    subdirs = [x[0] for x in os.walk(dir)]
    return subdirs


HELP_VERBOSE = 'Whether to display debug level log messages.'
HELP_DEVICE_NAME = 'Device to estimate.'
logger = logging.getLogger('root')
FORMAT = "[%(filename)s:%(lineno)s - %(funcName)20s() ] %(message)s"
logging.basicConfig(stream=sys.stdout, format=FORMAT)
logger.setLevel(logging.DEBUG)

@click.group()
@click.option('--verbose', is_flag=True, help=HELP_VERBOSE)
def cli(verbose):
    if verbose:
        logger.setLevel(logging.DEBUG)
        
@cli.command()
@click.option('--folder', default='/home/testcluster/zhengxian/dnncost/dnnsat/results/vgg_13_total/')
def entry(folder):
    stat_file = folder + '/stat.json'
    with open(stat_file, 'r+') as stat:
        data = json.load(stat)
        cnt = 0
        too_weak_cnt = 0
        too_weak_lst = []
        too_strong_cnt = 0
        too_strong_lst = []
        while True:
            if cnt in data:
                error_case = data[cnt]['error']
                if error_case["real_count"] == 0:
                    too_weak_cnt += 1
                    too_weak_lst.append(cnt)
                else:
                    too_strong_cnt += 1
                    too_strong_lst.append(cnt)
            else:
                break
        data["strong"] = dict()
        data["strong"]["cnt"] = too_strong_cnt
        data["strong"]["lst"] = too_weak_lst
        data["weak"]  = dict()
        data["weak"]["cnt"]   = too_weak_cnt
        data["strong"]["lst"] = too_strong_lst
        #json.dump(data, )
                    
                
if __name__ == '__main__':
    #sub_folders = list_folders("/home/testcluster/zhengxian/dnncost/dnnsat/sample/pytorch/vgg_13_total/")
    print("in entry")
    entry()