cd ..
mkdir results/flatten
python3 main.py sample/pytorch/flatten/flatten.json --device_name=TITAN_X --output_folder=results/flatten --search_space_path=sample/pytorch/flatten/flatten_search_space.json >> results/flatten/log
