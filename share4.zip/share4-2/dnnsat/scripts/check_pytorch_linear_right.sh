cd ..
rm -rf results/linear/
mkdir results/linear
python3 main.py sample/pytorch/linear/linear.json --device_name=TITAN_X --output_folder=results/linear --search_space_path=sample/pytorch/linear/linear_search_space.json >> results/linear/log