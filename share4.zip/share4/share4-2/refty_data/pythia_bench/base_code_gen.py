class BaseNet(object):
    """Base class """
    def __init__(self):
        return

    def get_net_json(self):
        return

    def get_search_space(self):
        return

    def get_tensorflow_code_gen_str(self, hyper_dic, root_folder, suffix):
        return

    def get_pytorch_code_gen_str(self):
        return

    def get_pythia_code_gen_str(self):
        return

    def launch_code(self, 
                    args, \
                    container_id, \
                    code_folder, \
                    real_run_callback
                    ):
        return