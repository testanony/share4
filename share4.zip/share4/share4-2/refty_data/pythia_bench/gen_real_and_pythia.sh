python3 refty_pythia_compare_bench_gen_test_case.py --container_id b66c3705c3cf --code_folder "/bench6path/yanjga/pythia_exp/dnncost/refty_data/pythia_bench/"
