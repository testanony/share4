from code_gen_test_launcher import *
import copy
from base_code_gen import *


class ConcatOp(BaseNet):
    """Concat. """
    def __init__(self):
        super(ConcatOp, self).__init__()

    def get_net_json(self):
        self.net_json = json.loads("""{
        "name": "concat_op",
        "layers": {
            "data1": {
                "parents": [],
                "type": "Input",
                "datatype": "float32",
                "dataformat": ["N", "C", "H", "W"],
                "tensor": [128, 224, 224, 3]
            },
            "data2": {
                "parents": [],
                "type": "Input",
                "datatype": "float32",
                "dataformat": ["N", "C", "H", "W"],
                "tensor": [128, 224, 224, 3]
            },
            "concat": {
                "parents": [
                    "data1",
                    "data2"
                ],
                "datatype": "float32",
                "dataformat": ["N", "C", "H", "W"],
                "type": "Concatenate",
                "dim": 3
            }
        }
    }""")
        return self.net_json

    def get_search_space(self):
        self.search_space = copy.deepcopy(self.net_json)
        layers = self.search_space["layers"]
        # NOTE: please config param.py as True before evaluation
        layers["data1"]["dataformat"] = {
            "_type": "choice",
            "_value": [["N", "C", "H", "W"], 
                       ["N", "H", "C", "W"]]
        }

        layers["data1"]["datatype"] = {
            "_type": "choice",
            "_value": ["float32", 
                       "bool"]
        }

        return self.search_space

    def launch_code(self, \
                    args, \
                    net_object, \
                    model_name, \
                    root_folder, \
                    container_id, \
                    code_folder, \
                    real_run_callback
                    ):

        layers = self.search_space["layers"]
        print(self.search_space)
        t1_list = layers["data1"]["dataformat"] ["_value"]
        t2_list = layers["data1"]["datatype"] ["_value"]

        for tensor1_format in t1_list:
            for tensor1_datatype in t2_list:
                temp_net = copy.deepcopy(self.net_json)
                temp_net_layers = temp_net["layers"]
                # overwrite the hyper dic for code real code rewritten
                hyper_dic = {}
                temp_net_layers["data1"]["dataformat"] = tensor1_format
                hyper_dic["data1_dataformat_0"] = tensor1_format[0]
                hyper_dic["data1_dataformat_1"] = tensor1_format[1]
                hyper_dic["data1_dataformat_2"] = tensor1_format[2]
                hyper_dic["data1_dataformat_3"] = tensor1_format[3]

                temp_net_layers["data1"]["datatype"] = tensor1_datatype
                hyper_dic["data1_datatype"] = tensor1_datatype

                real_run_callback(args, \
                                net_object, \
                                model_name, \
                                root_folder, \
                                hyper_dic, \
                                temp_net, \
                                container_id, \
                                code_folder
                                )
        return

    def get_tensorflow_code_gen_str(self, hyper_dic, root_folder, suffix):
        if not os.path.exists(root_folder):
            os.makedirs(root_folder)
        print(hyper_dic)
        print(hyper_dic.get("conv1_kernel_h"))
        import_part = """import tensorflow as tf
assert tf.__version__ >= "1.0"\n"""
        
        hyper_param_part = """tf_type_list = {
    "float32": tf.float32,
    "float64": tf.float64,
    "int32": tf.int32,
    "bool": tf.bool,
    "string": tf.string,
}

op1_dtype = {}
op1_dtype = tf_type_list[op1_dtype]
op1_height = {}
op1_width = {}
op1_channel = {}
op1_batch_size =  {}

op2_dtype = {}
op2_dtype = tf_type_list[op2_dtype]
op2_height = {}
op2_width = {}
op2_channel =  {}
op2_batch_size =  {}
axis_param = {}\n""".format( \
                    hyper_dic.get("op1_dtype", "float32"), \
                    hyper_dic.get("op1_height", 224), \
                    hyper_dic.get("op1_width", 224), \
                    hyper_dic.get("op1_channel", 3), \
                    hyper_dic.get("op1_batch_size", 32), \
                    hyper_dic.get("op2_dtype", "float32"), \
                    hyper_dic.get("op2_height", 224), \
                    hyper_dic.get("op2_width", 224), \
                    hyper_dic.get("op2_channel", 3), \
                    hyper_dic.get("op2_batch_size", 32), \
                    hyper_dic.get("axis", 3) \
                    )

        net_part= """
a = tf.constant(0, dtype = tf.float32, \
    shape = [op1_batch_size, op1_height, op1_width, op1_channel], name="input_a")
b = tf.constant(0, dtype = tf.float32, \
    shape = [op2_batch_size, op2_height, op2_width, op2_channel], name="input_b")
c = tf.concat([a, b], axis = axis_param)\n
        """
        regular_part = """
sess = tf.Session()
output = sess.run(c)
print("run concat operator")
        """
    
        # if not os.path.exists(model_name):
        #     os.makedirs(model_name)
            
        file_name = "{}/{}_tf.py".format(root_folder, suffix)

        with open(file_name, "w") as f:
            f.write(import_part)
            f.write(hyper_param_part)
            f.write(net_part)
            f.write(regular_part)

        return file_name

    def get_pytorch_code_gen_str(self, \
                                hyper_dic, \
                                root_folder, \
                                suffix):
        if not os.path.exists(root_folder):
            os.makedirs(root_folder)
        import_part = """import torch
import torch.nn as nn
import torch.nn.parallel
import torch.optim
import torch.utils.data
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import time
from torch.autograd import Variable\n"""
        
        hyper_param_part = """
torch_type_list = {
    "float32": torch.float32,
    "float64": torch.float64,
    "int32": torch.int32,
    "bool": torch.bool
}

op1_dtype      = {} 
op1_dtype      = torch_type_list[op1_dtype]
op1_height     = {}
op1_width      = {}
op1_channel    = {}
op1_batch_size = {}

op2_dtype      = {}
op2_dtype      = torch_type_list[op2_dtype]
op2_height     = {}
op2_width      = {}
op2_channel    = {}
op2_batch_size = {}
epochs = 1
axis = {}
\n""".format( \
            hyper_dic.get("op1_dtype", "float32"), \
            hyper_dic.get("op1_height", 224), \
            hyper_dic.get("op1_width", 224), \
            hyper_dic.get("op1_channel", 3), \
            hyper_dic.get("op1_batch_size", 32), \
            hyper_dic.get("op2_dtype", "float32"), \
            hyper_dic.get("op2_height", 224), \
            hyper_dic.get("op2_width", 224), \
            hyper_dic.get("op2_channel", 3), \
            hyper_dic.get("op2_batch_size", 32), \
            hyper_dic.get("axis", 3) \
            )

        net_part = """
class AddOp(nn.Module):
    def __init__(self):
        super(AddOp, self).__init__()

    def forward(self, x1, x2):
        out = torch.cat((x1, x2), dim = axis)
        return out
        """
        regular_part = """
def main():
    cpu = True
    device = 0
    batch_size = 8
    model = AddOp()
    a = Variable(torch.zeros(op1_batch_size, op1_height, op1_width, \
                    op1_channel, dtype = op1_dtype)) 
    b = Variable(torch.zeros(op2_batch_size, op2_height, op2_width, \
                    op2_channel, dtype = op2_dtype)) 
    if cpu:
        model.cpu()
    else:
        model.cuda()
        device_id = int(device)
        torch.cuda.set_device(device_id)

    for epoch in range(0, epochs):
        output = model(a, b) 
        print("epoch {} finished".format(epoch))

if __name__ == '__main__':
    main()
        """
    
        # if not os.path.exists(model_name):
        #     os.makedirs(model_name)
            
        file_name = "{}/{}_pytorch.py".format(root_folder, suffix)

        with open(file_name, "w") as f:
            f.write(import_part)
            f.write(hyper_param_part)
            f.write(net_part)
            f.write(regular_part)

        return file_name


    def get_pythia_code_gen_str(self):
        return None
