from code_gen_test_launcher import *
import copy
from base_code_gen import *


class AlexNet(BaseNet):
    """Conv2D. """
    def __init__(self):
        super(AlexNet, self).__init__()

    def get_net_json(self):
        self.net_json = json.loads("""{
    "name": "alexnet",
    "layers": {
        "data": {
            "parents": [],
            "type": "Input",
            "tensor": [128, 224, 224, 3]
        },
        "conv1": {
            "parents": ["data"],
            "type": "Convolution",
            "filter": [11, 11, 3, 64],
            "padding": "VALID",
            "strides": [1, 4, 4, 1],
            "activation_fn": "relu"
        },
        "pool1": {
            "parents": ["conv1"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "conv2": {
            "parents": ["pool1"],
            "type": "Convolution",
            "filter": [5, 5, 64, 192],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "pool2": {
            "parents": ["conv2"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "conv3": {
            "parents": ["pool2"],
            "type": "Convolution",
            "filter": [3, 3, 192, 384],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "conv4": {
            "parents": ["conv3"],
            "type": "Convolution",
            "filter": [3, 3, 384, 256],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "conv5": {
            "parents": ["conv4"],
            "type": "Convolution",
            "filter": [3, 3, 256, 256],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "pool5": {
            "parents": ["conv5"],
            "type": "Pooling",
            "ksize": [1, 3, 3, 1],
            "strides": [1, 2, 2, 1],
            "padding": "VALID"
        },
        "fc6": {
            "parents": ["pool5"],
            "type": "Convolution",
            "filter": [5, 5, 256, 4096],
            "padding": "VALID",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "dropout6": {
            "parents": ["fc6"],
            "type": "Dropout",
            "dropout_keep_prob": 0.5
        },
        "fc7": {
            "parents": ["dropout6"],
            "type": "Convolution",
            "filter": [1, 1, 4096, 4096],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": "relu"
        },
        "dropout7": {
            "parents": ["fc7"],
            "type": "Dropout",
            "dropout_keep_prob": 0.5
        },
        "fc8": {
            "parents": ["dropout7"],
            "type": "Convolution",
            "filter": [1, 1, 4096, 1000],
            "padding": "SAME",
            "strides": [1, 1, 1, 1],
            "activation_fn": null
        },
        "softmax": {
            "parents": ["fc8"],
            "type": "Softmax",
            "num_classes": 1000
        }
    }
}
""")
        return self.net_json

    def get_search_space(self):
        self.search_space = copy.deepcopy(self.net_json)
        layers = self.search_space["layers"]

        layers["data"]["tensor"] = {
            "_type": "choice",
            "_value": [[1, 224, 224, 3],
                       [8, 224, 224, 3]],
        }

        layers["conv1"]["filter"] = {
            "_type": "choice",
            "_value": [[500, 500, 3, 64], 
                       [3, 3 ,3,  64]],
        }

        layers["conv1"]["filter"]["_value"] = [[3, 3, 3, 64], 
                                                [5, 5, 3, 64], 
                                                [7, 7, 3, 64], 
                                                [9, 9, 3, 64]]

        layers["conv1"]["strides"] = {
            "_type": "choice",
            "_value": [[1, 1, 1, 1], 
                       [1, 2 ,2, 1],
                       [1, 4, 4, 1],
                       [1, 8, 8, 1]]
        }

        layers["pool1"]["ksize"] = {
            "_type": "choice",
            "_value": [[1, 1, 1, 1],
                       [1, 2, 2, 1],
                       [1, 4, 4, 1],
                       [1, 8, 8, 1]]
        }

        layers["pool1"]["strides"] = {
            "_type": "choice",
            "_value": [[1, 1, 1, 1],
                       [1, 2, 2, 1],
                       [1, 4, 4, 1],
                       [1, 8, 8, 1]]
        }

        

        # layers["conv2"]["filter"]["_value"] = [ [5, 5, 64, 192], \
        #                                         [11, 11, 64, 192], \
        #                                         [33, 33, 64, 192], \
        #                                         [55, 55, 64, 192], \
        #                                         [5, 3, 64, 192], \
        #                                         [500, 500, 64, 192], \
        #                                         [50, 50, 64, 192]]
        return self.search_space

    def launch_code(self, \
                    args, \
                    net_object, \
                    model_name, \
                    root_folder, \
                    container_id, \
                    code_folder, \
                    real_run_callback
                    ):

        layers = self.search_space["layers"]
        print(self.search_space)
        in_lst = layers["data"]["tensor"]["_value"]
        c_list = layers["conv1"]["filter"]["_value"]
        stride1_lst = layers["conv1"]["strides"]["_value"]
        k_list = layers["pool1"]["ksize"]["_value"]
        stride2_lst = layers["pool1"]["strides"]["_value"]
        for in_data in in_lst:
            for filter in c_list:
                for stride1 in stride1_lst:
                    for ksize in k_list:
                        for stride2 in stride2_lst:
                            temp_net = copy.deepcopy(self.net_json)
                            temp_net_layers = temp_net["layers"]
                            # overwrite the hyper dic for code real code rewritten
                            hyper_dic = {}
                            #temp_net_layers = ut1_MNIST_spec_origin["layers"]
                            temp_net_layers["data"]["tensor"] = in_data
                            hyper_dic["batch_size"]  = in_data[0]
                            temp_net_layers["conv1"]["filter"]  = filter 
                            temp_net_layers["conv1"]["strides"] = stride1 
                            hyper_dic["conv1_kernel_h"] = filter[0]
                            hyper_dic["conv1_kernel_w"] = filter[1]
                            hyper_dic["conv1_stride"]   = stride1[1]
                            hyper_dic["conv1_kernel_c"] = filter[3]

                            temp_net_layers["pool1"]["ksize"] = ksize
                            hyper_dic["pool_kernel_h"] = ksize[1]
                            hyper_dic["pool_kernel_w"] = ksize[2]

                            temp_net_layers["pool1"]["strides"] = stride2
                            hyper_dic["pool_stride"] = stride2[1]

                            hyper_dic["epoch"] = 1
                            real_run_callback(args, \
                                            net_object, \
                                            model_name, \
                                            root_folder, \
                                            hyper_dic, \
                                            temp_net, \
                                            container_id, \
                                            code_folder
                                            )
        return

    def get_tensorflow_code_gen_str(self, hyper_dic, root_folder, suffix):
        if not os.path.exists(root_folder):
            os.makedirs(root_folder)
        print(hyper_dic)
        print(hyper_dic.get("conv1_kernel_h"))
        import_part = """import tensorflow.contrib.slim as slim
import tensorflow as tf
import numpy as np
import numpy as np
slim = tf.contrib.slim
trunc_normal = lambda stddev: tf.truncated_normal_initializer(0.0, stddev)\n"""
        
        hyper_param_part = """conv1_kernel_h = {}\n
conv1_kernel_w = {}
conv1_kernel_c = {} 
conv1_stride  = {}
pool_kernel_h = {}
pool_kernel_w = {}
pool_stride   = {}
bz            = {}
conv2_kernel_c = 64 
conv2_kernel_w = 5
conv2_kernel_h = 5
conv3_kernel_h = 3
conv4_kernel_h = 3
conv5_kernel_h = 3\n""".format( \
                    hyper_dic.get("conv1_kernel_h", 5), \
                    hyper_dic.get("conv1_kernel_w", 5), \
                    hyper_dic.get("conv1_kernel_c", 3), \
                    hyper_dic.get("conv1_stride",  4),
                    hyper_dic.get("pool_kernel_h", 2), \
                    hyper_dic.get("pool_kernel_w", 2), \
                    hyper_dic.get("pool_stride",  2), \
                    hyper_dic.get("batch_size", 64)
                    )

        net_part= """
def alexnet_v2(inputs,
               num_classes=1000,
               is_training=True,
               dropout_keep_prob=0.5,
               spatial_squeeze=False,
               scope='alexnet_v2',
               global_pool=False):
    with tf.variable_scope(scope, 'alexnet_v2', [inputs]) as sc:
        end_points_collection = sc.original_name_scope + '_end_points'
        # Collect outputs for conv2d, fully_connected and max_pool2d.
        with slim.arg_scope([slim.conv2d, slim.fully_connected, slim.max_pool2d],
                            outputs_collections=[end_points_collection]):
            net = slim.conv2d(inputs, conv1_kernel_c, [conv1_kernel_h, conv1_kernel_w], conv1_stride, padding='VALID',
                              scope='conv1')
            net = slim.max_pool2d(net, [pool_kernel_h, pool_kernel_w], pool_stride, scope='pool1')
            net = slim.conv2d(net, conv2_kernel_c, [conv2_kernel_h, conv2_kernel_w], scope='conv2')
            net = slim.max_pool2d(net, [3, 3], 2, scope='pool2')
            net = slim.conv2d(net, 384, [conv3_kernel_h, conv3_kernel_h], scope='conv3')
            net = slim.conv2d(net, 384, [conv4_kernel_h, conv4_kernel_h], scope='conv4')
            net = slim.conv2d(net, 256, [conv5_kernel_h, conv5_kernel_h], scope='conv5')
            net = slim.max_pool2d(net, [3, 3], 2, scope='pool5')

            # Use conv2d instead of fully_connected layers.
            with slim.arg_scope([slim.conv2d],
                                weights_initializer=trunc_normal(0.005),
                                biases_initializer=tf.constant_initializer(0.1)):
                net = slim.conv2d(net, 4096, [5, 5], padding='VALID',
                                  scope='fc6')
                net = slim.dropout(net, dropout_keep_prob, is_training=is_training,
                                   scope='dropout6')
                net = slim.conv2d(net, 4096, [1, 1], scope='fc7')
                # Convert end_points_collection into a end_point dict.
                end_points = slim.utils.convert_collection_to_dict(
                    end_points_collection)
                if global_pool:
                    net = tf.reduce_mean(net, [1, 2], keep_dims=True, name='global_pool')
                    end_points['global_pool'] = net
                if num_classes:
                    net = slim.dropout(net, dropout_keep_prob, is_training=is_training,
                                       scope='dropout7')
                    net = slim.conv2d(net, num_classes, [1, 1],
                                      activation_fn=None,
                                      normalizer_fn=None,
                                      biases_initializer=tf.zeros_initializer(),
                                      scope='fc8')
                    if spatial_squeeze:
                        net = tf.squeeze(net, [1, 2], name='fc8/squeezed')
                    end_points[sc.name + '/fc8'] = net
            return net, end_points
        """
        regular_part = """
def main():
    iter = 1
    width = 224
    height = 224
    channel = 3
    classes = 1000
    batch_size = bz
    format = "NHWC"

    if format == "NCHW":
        x = tf.placeholder(tf.float32, shape=[None, channel, width, height], name='Input')
        y = tf.placeholder(tf.float32, shape=[None, classes], name='Output')
        inputs = np.float32(np.random.random((batch_size, channel, width, height)))
        label = np.float32(np.random.random((batch_size, classes)))
    else: 
        x = tf.placeholder(tf.float32, shape=[None, width, width, channel], name='Input')
        y = tf.placeholder(tf.float32, shape=[None, classes], name='Output')
        inputs = np.float32(np.random.random((batch_size, width, height, channel)))
        label = np.float32(np.random.random((batch_size, classes)))

    with tf.Session() as sess:
        logits, _ = alexnet_v2(inputs)
        sess.run(tf.global_variables_initializer())

        for s in range(iter):
            # sess.run(optimizer, feed_dict={x: inputs, y: label})
             print("finished batch")

if __name__ == '__main__':
    main()

        """
    
        # if not os.path.exists(model_name):
        #     os.makedirs(model_name)
            
        file_name = "{}/{}_tf.py".format(root_folder, suffix)

        with open(file_name, "w") as f:
            f.write(import_part)
            f.write(hyper_param_part)
            f.write(net_part)
            f.write(regular_part)

        return file_name

    def get_pytorch_code_gen_str(self, \
                                hyper_dic, \
                                root_folder, \
                                suffix):
        if not os.path.exists(root_folder):
            os.makedirs(root_folder)
        import_part = """import torch
import torch.nn as nn
import torch.nn.parallel
import torch.optim
import torch.utils.data
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import time\n"""
        
        hyper_param_part = """conv1_kernel_h = {}\n
conv1_kernel_w = {}
conv1_kernel_c = {} 
conv1_stride   = {}
pool_kernel_h  = {}
pool_kernel_w  = {}
pool_stride    = {}
bz             = {}
conv2_kernel_c = 64 
conv2_kernel_w = 5
conv2_kernel_h = 5
conv3_kernel_h = 3
conv4_kernel_h = 3
conv5_kernel_h = 3\n""".format( \
                    hyper_dic.get("conv1_kernel_h", 5), \
                    hyper_dic.get("conv1_kernel_w", 5), \
                    hyper_dic.get("conv1_kernel_c", 3), \
                    hyper_dic.get("conv1_stride",  4),
                    hyper_dic.get("pool_kernel_h", 2), \
                    hyper_dic.get("pool_kernel_w", 2), \
                    hyper_dic.get("pool_stride",  2), \
                    hyper_dic.get("batch_size", 64)
                    )

        net_part = """
class AlexNet(nn.Module):
    
    def __init__(self, num_classes: int = 1000) -> None:
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, conv1_kernel_c, kernel_size=conv1_kernel_h, stride=conv1_stride, padding=0), # make it as valid
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=pool_kernel_h, stride=pool_stride),
            nn.Conv2d(conv1_kernel_c, conv2_kernel_c, kernel_size=conv2_kernel_h, padding=int(conv2_kernel_h/2 -1)),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(conv2_kernel_c, 384, kernel_size=conv3_kernel_h, padding=int(conv3_kernel_h/2 - 1)),
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=conv4_kernel_h, padding=int(conv4_kernel_h/2 - 1)),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=conv5_kernel_h, padding=int(conv5_kernel_h/2 - 1)),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
        )
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(
            nn.Dropout(),
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x
        """
        regular_part = """
def main():
    cpu = True
    device = 0
    batch_size = bz
    num_classes = 1000
    epochs = 1
    image_shape = [3, 224, 224]

    model = AlexNet(num_classes=num_classes)

    if cpu:
        model.cpu()
    else:
        model.cuda()
        device_id = int(device)
        torch.cuda.set_device(device_id)

    dataset_train = torchvision.datasets.FakeData(size=(batch_size*3),image_size=image_shape,num_classes=num_classes,transform=transforms.Compose([transforms.ToTensor()]))

    train_loader = torch.utils.data.DataLoader(dataset_train, 
        batch_size=batch_size, shuffle=False)

    criterion = nn.CrossEntropyLoss()
    if cpu:
        criterion = criterion.cpu()
    else:
        print("use CUDA")
        criterion = criterion.cuda()
    optimizer = torch.optim.SGD(model.parameters(), 0.001) 

    for epoch in range(0, epochs):
        for i, (input, target) in enumerate(train_loader):
            start = time.time()
            print(input.shape)
            print(target.shape)
            print("input type {}".format(input.type()))
            if cpu == False:
                input = input.cuda()
                target = target.cuda()
            output = model(input)
            print(type(output))
            loss = criterion(output, target)
            optimizer.zero_grad()
            loss.backward() 
            optimizer.step() 
            end = time.time()
            print("time {}".format(end - start))
        print("epoch {} finished".format(epoch))

if __name__ == '__main__':
    main()
        """
    
        # if not os.path.exists(model_name):
        #     os.makedirs(model_name)
            
        file_name = "{}/{}_pytorch.py".format(root_folder, suffix)

        with open(file_name, "w") as f:
            f.write(import_part)
            f.write(hyper_param_part)
            f.write(net_part)
            f.write(regular_part)

        return file_name


    def get_pythia_code_gen_str(self):
        return None
