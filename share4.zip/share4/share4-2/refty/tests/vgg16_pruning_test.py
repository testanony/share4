import subprocess
import os
import asyncio
from subprocess import Popen, PIPE
import glob
import json


def read_search_space_file(path="nets/vgg16.json"):
    """[Read search space and construct json dic]
    
    Keyword Arguments:
        path {str} -- [path] (default: {"nets/vgg16.json"})
    
    Returns:
        [type] -- [search space dic]
    """
    with open(path) as f:
        search_space = json.load(f)
        return search_space


def construct_search_space_and_constraint(NETFILE, SEARCH_SPACE, index,
                                          constraint):
    file_json = read_search_space_file(NETFILE)

    search_space = {
        "constraints": [],
        "name": "{}_{}".format(NETFILE, index),
        "cube_contract": "False",
        "layers": {}
    }

    op = "lt"
    print(constraint)
    if "fwd_time" in constraint:
        fwd_time = constraint["fwd_time"]
        search_space["constraints"].append({"constraint": "fwd_time", "max": fwd_time})

    if "mem" in constraint:
        mem = constraint["mem"]  #16*1024*1024*1024
        search_space["constraints"].append({"constraint": "mem", "max": mem})

    if "fwd_FLOPs" in constraint:
        fwd_FLOPs = constraint["fwd_FLOPs"]  #128*1024*1024*1024
        search_space["constraints"].append({"constraint": "fwd_FLOPs", "max": fwd_FLOPs})

    if "weight" in constraint:
        weight = constraint["weight"]  #64*1024*1024
        search_space["constraints"].append({"constraint": "weight", "max": weight})

    # large search space test
    bz_start = 1
    bz_end = 256
    filter_start = 640
    filter_end = 128
    hy_offset = 0
    hs_offset = 0
    h_count = 1
    c_count = 1

    for layer_name in file_json["layers"]:
        print(layer_name)
        layer_spec = file_json["layers"][layer_name]
        if "tensor" in layer_spec:
            search_space["layers"][layer_name] = {}
            search_space["layers"][layer_name]["tensor"] = {"_type": "randint", "_value": \
                [[bz_start, \
                int(layer_spec["tensor"][1]), \
                int(layer_spec["tensor"][2]), \
                int(layer_spec["tensor"][3])], \
                [bz_end, \
                int(layer_spec["tensor"][1]), \
                int(layer_spec["tensor"][2]), \
                int(layer_spec["tensor"][3])]]}

        if "filter" in layer_spec and c_count <= 1:
            search_space["layers"][layer_name] = {}
            print("enter {}".format(layer_name))
            search_space["layers"][layer_name]["filter"] = {"_type": "choice", "_value": \
                [[1, \
                1, \
                int(layer_spec["filter"][2]), \
                int(layer_spec["filter"][3])],
                [3, \
                3, \
                int(layer_spec["filter"][2]), \
                int(layer_spec["filter"][3])], \
                [5, \
                5, \
                int(layer_spec["filter"][2]), \
                int(layer_spec["filter"][3]) \
                ]]}
            c_count += 1

        if "filter" in layer_spec and "fc" in layer_name and h_count <= 1:
            search_space["layers"][layer_name] = {}
            print("enter {}".format(layer_name))
            search_space["layers"][layer_name]["filter"] = {"_type": "choice", "_value": \
                [[int(layer_spec["filter"][0]), \
                int(layer_spec["filter"][1]), \
                int(layer_spec["filter"][2]), \
                1024], \
                [int(layer_spec["filter"][0]), \
                int(layer_spec["filter"][1]), \
                int(layer_spec["filter"][2]), \
                4096],
                [int(layer_spec["filter"][0]), \
                int(layer_spec["filter"][1]), \
                int(layer_spec["filter"][2]), \
                10240],
                [int(layer_spec["filter"][0]), \
                int(layer_spec["filter"][1]), \
                int(layer_spec["filter"][2]), \
                512],
                [int(layer_spec["filter"][0]), \
                int(layer_spec["filter"][1]), \
                int(layer_spec["filter"][2]), \
                128]]}
            h_count += 1

    output_path = SEARCH_SPACE.replace(".json",
                                       "_{}.json".format(index)).replace(
                                           "nets", "nets/auto")

    with open(output_path, 'w') as outfile:
        json.dump(search_space, outfile, indent=4)
        outfile.flush()
    return output_path


def construct_single_constraint_file(model_name, constraint, \
    index, ss_type):
    NET_FOLDER = "nets"

    if model_name == "vgg16":
        NET_FILE = "{}/vgg16.json".format(NET_FOLDER)
        SEARCH_SPACE = "{}/{}".format(NET_FOLDER, "vgg16_search_space.json")
        in_shape = 224

    SEARCH_SPACE = construct_search_space_and_constraint(NET_FILE, \
        SEARCH_SPACE, index, constraint)
    print(SEARCH_SPACE)

    if "mem" not in constraint:
        constraint["mem"] = 0

    if "fwd_time" not in constraint:
        constraint["fwd_time"] = 0

    if "fwd_FLOPs" not in constraint:
        constraint["fwd_FLOPs"] = 0

    if "weight" not in constraint:
        constraint["weight"] = 0

    OUT_FOLDER="results/autorefty/{}_{}_{}_{}_{}_{}_{}_{}_{}/".format(\
                                                    model_name, \
                                                    "mem", \
                                                    constraint["mem"], \
                                                    "fwd_time", \
                                                    constraint["fwd_time"], \
                                                    "fwd_FLOPs", \
                                                    constraint["fwd_FLOPs"], \
                                                    "weight", \
                                                    constraint["weight"])
    return NET_FOLDER, NET_FILE, SEARCH_SPACE, OUT_FOLDER


cmd_list = []


def construct_cmd(model_name, constraint, index, ss_type):
    if ss_type != "multiconstraint":
        NET_FOLDER, NET_FILE, SEARCH_SPACE, OUT_FOLDER = \
            construct_single_constraint_file(model_name, \
                constraint, index, ss_type)
    else:
        NET_FOLDER, NET_FILE, SEARCH_SPACE, OUT_FOLDER = \
            construct_multi_constraint_file(model_name, \
                constraint, index, ss_type)

    print(SEARCH_SPACE)
    if not os.path.isdir(OUT_FOLDER):
        os.makedirs(OUT_FOLDER)

    try:
        cmd = "./refty.sh {} \
            --device_name={} \
            --output_folder={} \
            --search_space_path={} >> {}/log.txt".format( \
                NET_FILE,
                "TITAN_X",
                OUT_FOLDER,
                SEARCH_SPACE,
                OUT_FOLDER)
        print(cmd)
        cmd_list.append(cmd)
    except subprocess.CalledProcessError as e:
        raise RuntimeError("command '{}' return with error (code {})".format(\
            e.cmd, e.returncode))


def batch_vgg16_pruning_test():
    for model_name in ["vgg16"]:
        index = 0
        #for constraint_type in ["mem", "weight", "fwd_time", "fwd_FLOPs"]:
        for constraint_type in ["fwd_time"]:
            constraints = []
            if constraint_type == "mem":
                for constraint in [12*1024*1024*1024, 8*1024*1024*1024, \
                    6*1024*1024*1024]:
                    ss_type = "bz_filter"
                    constraints.append({constraint_type: constraint})
                    const = {constraint_type: constraint}
                    construct_cmd(model_name, const, index, \
                        ss_type)
                    index += 1
                    constraints = []

            if constraint_type == "weight":
                for constraint in [
                        128 * 1024 * 1024, 1024 * 1024 * 1024,
                        512 * 1024 * 1024
                ]:
                    ss_type = "bz_filter"
                    constraints.append({constraint_type: constraint})
                    const = {constraint_type: constraint}
                    construct_cmd(model_name, const, index, \
                        ss_type)
                    index += 1
                    constraints = []

            if constraint_type == "fwd_time":
                for constraint in [1000, 800, 10]:
                    ss_type = "bz_filter"
                    constraints.append({constraint_type: constraint})
                    const = {constraint_type: constraint}
                    construct_cmd(model_name, const, index, \
                        ss_type)
                    index += 1
                    constraints = []

            if constraint_type == "fwd_FLOPs":
                for constraint in [4 * 1024*1024*1024*1024, \
                    3.5 * 1024*1024*1024*1024, 3 * 1024*1024*1024*1024]:
                    ss_type = "bz_filter"
                    constraints.append({constraint_type: constraint})
                    const = {constraint_type: constraint}
                    construct_cmd(model_name, const, index, \
                        ss_type)
                    index += 1
                    constraints = []

def batch_vgg16_all_constraint_pruning_batch_experiment():
    for model_name in ["vgg16"]:
        index = 0
        #for constraint_type in ["mem", "weight", "fwd_time", "fwd_FLOPs"]:
        constraints = {}
        c1 = {"mem":12*1024*1024*1024, "weight":1024  * 1024 * 1024, \
            "fwd_time":1000, "fwd_FLOPs":4 * 1024*1024*1024*1024}
        c2 = {"mem":8*1024*1024*1024, "weight": 512 * 1024 * 1024, \
            "fwd_time":800, "fwd_FLOPs":3.5 * 1024*1024*1024*1024}
        c3 = {"mem":6*1024*1024*1024, "weight": 128  * 1024 * 1024, \
            "fwd_time":10, "fwd_FLOPs":3 * 1024*1024*1024*1024}
        constraints_set = [c1,c2,c3]
        for constraints in constraints_set:
            ss_type = "bz_filter"
            construct_cmd(model_name, constraints, index, \
                            ss_type)
            index += 1

#batch_vgg16_pruning_test()

def batch_vgg16_all_constraint_pruning_test():
    for model_name in ["vgg16"]:
        index = 0
        #for constraint_type in ["mem", "weight", "fwd_time", "fwd_FLOPs"]:
        constraints = {}
        for constraint_type in ["mem", "weight", "fwd_time", "fwd_FLOPs"]:
            if constraint_type == "mem":
                for constraint in [12*1024*1024*1024]:
                    ss_type = "bz_filter"
                    constraints[str(constraint_type)] = constraint

            if constraint_type == "weight":
                #for constraint in [128 * 1024 * 1024]:
                for constraint in [1024 * 1024 * 1024]:
                    ss_type = "bz_filter"
                    constraints[str(constraint_type)] = constraint

            if constraint_type == "fwd_time":
                #for constraint in [1000]:
                for constraint in [1000]:
                    ss_type = "bz_filter"
                    constraints[str(constraint_type)] = constraint


            if constraint_type == "fwd_FLOPs":
                for constraint in [4 * 1024*1024*1024*1024]:
                    ss_type = "bz_filter"
                    constraints[str(constraint_type)] = constraint

            
        construct_cmd(model_name, constraints, index, \
                         ss_type)

experiment_type = "all_constraint_batch"

if experiment_type == "all_constraint_batch":
    batch_vgg16_all_constraint_pruning_batch_experiment()
elif experiment_type == "seperate_constraint":
    batch_vgg16_pruning_test()

procs_list = []

for _cmd in cmd_list:
    procs_list.append(Popen(_cmd, shell=True))
    print(_cmd)

output = [p.wait() for p in procs_list]
