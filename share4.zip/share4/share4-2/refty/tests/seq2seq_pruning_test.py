import time
from z3 import *
import subprocess
import os
import asyncio
from subprocess import Popen, PIPE
import glob
import json

root_path = "results/autorefty"

cmd_list = []

def construct_cmd(model_name, constraint_type, constraint, index):
    OUT_FOLDER = "{}/seq2seq_constraint_type_{}_constraint_{}_index_{}".format(\
        root_path, str(constraint_type), str(constraint), index)

    if not os.path.isdir(OUT_FOLDER):
        os.makedirs(OUT_FOLDER)

    try:
        cmd = "python refty/rnn_cost_solve.py --ctype {} --csize {} \
            > {}/refty_search_spaces_statistic.txt".format(
            constraint_type,
            constraint,
            OUT_FOLDER)
        #print(cmd)
        cmd_list.append(cmd)
    except subprocess.CalledProcessError as e:
        raise RuntimeError("command '{}' return with error (code {})".format(e.cmd, e.returncode))


def all_constraint_test_all():
    print("enter all constraint test all")
    for model_name in ["LSTM"]: # "GRU"
        constraint_type_list = 'mem-weight-fwd_time-fwd_FLOPs'
        constraint_size_list_1 = '{}-{}-{}-{}'.format(600 * 1024 * 1024, 128*1024*1024, 50, 64)
        constraint_size_list_2 = '{}-{}-{}-{}'.format(409 * 1024 * 1024, 64*1024*1024, 30, 4)
        constraint_size_list_3 = '{}-{}-{}-{}'.format(308 * 1024 * 1024, 32*1024, 1, 1)
        constraint_size_lists = [constraint_size_list_1, constraint_size_list_2,\
            constraint_size_list_3]

        index = 0
        for constraint_size_list in constraint_size_lists:
            construct_cmd(model_name, constraint_type_list, \
                constraint_size_list, index)
            index += 1

def single_constraint_time_test_all():
    for model_name in ["LSTM"]: # "GRU"
        for constraint_type in ["mem", "weight", "fwd_time", "fwd_FLOPs"]:
            index = 0
            constraints = []

            if constraint_type == "weight":
                for constraint in [128*1024*1024, 64*1024*1024, 32*1024*1024]:
                    ss_type = "multiconstraint" 
                    construct_cmd(model_name, constraint_type, constraint, index)
                    index += 1

            if constraint_type == "fwd_time":
                for constraint in [50, 30, 1]: # seconds
                    ss_type = "multiconstraint" 
                    construct_cmd(model_name, constraint_type, constraint, index)
                    index += 1

            if constraint_type == "fwd_FLOPs":
                for constraint in [64, 4, 1]:
                    ss_type = "multiconstraint" 
                    construct_cmd(model_name, constraint_type, constraint, index)
                    index += 1

            if constraint_type == "mem":
                for constraint in [600 * 1024 * 1024, 409 * 1024 * 1024, 308 * 1024 * 1024]:
                    ss_type = "multiconstraint" 
                    construct_cmd(model_name, constraint_type, constraint, index)
                    index += 1

experiment_type = "all_constraint_test_all" #"single_test"

if experiment_type == "single_test":
    single_constraint_time_test_all()
else: 
    all_constraint_test_all()   

procs_list = []

for _cmd in cmd_list:
    procs_list.append(Popen(_cmd, shell=True))
    print(_cmd)

output = [p.wait() for p in procs_list]