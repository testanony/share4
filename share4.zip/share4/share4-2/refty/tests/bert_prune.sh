#! /bin/sh
NET_FOLDER=nets/bert
NET_FILE=nets/bert/bert.json
OUT_FOLDER=results/bert
OUT_FILE=results/bert/log

if [[ -d $OUT_FOLDER ]];then
    rm -rf $OUT_FOLDER
fi

mkdir -p results
mkdir -p $OUT_FOLDER

/usr/bin/time -v python3 main.py $NET_FILE \
    --device_name=TITAN_X \
    --output_folder=$OUT_FOLDER \
    --search_space_path=$NET_FOLDER/bert_search_space.json > $OUT_FILE