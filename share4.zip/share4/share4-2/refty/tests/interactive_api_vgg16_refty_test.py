# from __future__ import absolute_import
# from __future__ import division
# from __future__ import print_function

# import logging
# import os
# import click
# import sys
# sys.path.append('../refty')
# import time
# from refty.csp_solving import constraint_solving
# from logger import logger
# from refty.refty import refty
# from refty.csp_solving import check
# from paleo.graph import OperationGraph
# from paleo import device
# import json
# from refty.refty import Refty


def test_model():
    init_start = time.time()
    device_name = "P40"
    vgg16_spec_test = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv1-2": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool1": {
                            "parents": ["conv1-2"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv2-1": {
                            "parents": ["pool1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 128],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv2-2": {
                            "parents": ["conv2-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 128, 128],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool2": {
                            "parents": ["conv2-2"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv3-1": {
                            "parents": ["pool2"],
                            "type": "Convolution",
                            "filter": [3, 3, 128, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv3-2": {
                            "parents": ["conv3-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv3-3": {
                            "parents": ["conv3-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 256],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool3": {
                            "parents": ["conv3-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv4-1": {
                            "parents": ["pool3"],
                            "type": "Convolution",
                            "filter": [3, 3, 256, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv4-2": {
                            "parents": ["conv4-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv4-3": {
                            "parents": ["conv4-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool4": {
                            "parents": ["conv4-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "conv5-1": {
                            "parents": ["pool4"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv5-2": {
                            "parents": ["conv5-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv5-3": {
                            "parents": ["conv5-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 512, 512],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "pool5": {
                            "parents": ["conv5-3"],
                            "type": "Pooling",
                            "ksize": [1, 2, 2, 1],
                            "strides": [1, 2, 2, 1],
                            "padding": "VALID"
                        },
                        "fc6": {
                            "parents": ["pool5"],
                            "type": "Convolution",
                            "filter": [7, 7, 512, 4096],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "fc7": {
                            "parents": ["fc6"],
                            "type": "Convolution",
                            "filter": [1, 1, 4096, 4096],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "dropout7": {
                            "parents": ["fc7"],
                            "type": "Dropout",
                            "dropout_keep_prob": 0.5
                        },
                        "fc8": {
                            "parents": ["dropout7"],
                            "type": "Convolution",
                            "filter": [1, 1, 4096, 1000],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": null
                        },
                        "softmax": {
                            "parents": ["fc8"],
                            "type": "Softmax",
                            "num_classes": 1000
                        }
                    }
                }
                """)

    alexnet1_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        }
                    }
                }
                """)

    alexnet2_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)


    alexnet3_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv1-2": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)

    alexnet4_error_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv1-2": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [300, 300, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                        ,
                        "conv1-3": {
                            "parents": ["conv1-2"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)
 
    alexnet4_error_rank_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv1-2": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [300, 300, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                        ,
                        "conv1-3": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)

    alexnet5_multi_error_rank_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        },
                        "conv1-2": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                        ,
                        "conv1-3": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [300, 300, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                        ,
                        "conv1-4": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [300, 300, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                        ,
                        "conv1-5": {
                            "parents": ["conv1-1"],
                            "type": "Convolution",
                            "filter": [3, 3, 64, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)


    alexnet_2_dtype_format_op_error_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "datatype": "float32",
                            "dataformat": ["N", "C", "H", "W"],
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "datatype": "float32",
                            "dataformat": ["N", "H", "W", "C"],
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)


    alexnet_2_dtype_format_op_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "datatype": "float32",
                            "dataformat": ["N", "C", "H", "W"],
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "datatype": "float32",
                            "dataformat": ["N", "C", "H", "W"],
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)

    alexnet_3_dtype_format_op_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "datatype": "float32",
                            "dataformat": ["N", "C", "H", "W"],
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "datatype": "float32",
                            "dataformat": ["N", "H", "W", "C"],
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)

    alexnet_3_dtype_format_op_spec = json.loads("""{
                    "name": "VGG 16 - FROM SLIM",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "datatype": "float32",
                            "dataformat": ["N", "C", "H", "W"],
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "datatype": "float32",
                            "dataformat": ["N", "H", "W", "C"],
                            "filter": [3, 3, 3, 64],
                            "padding": "SAME",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)
    concat_test = json.loads("""
    {
        "name": "concat_op",
        "layers": {
            "data": {
                "parents": [],
                "type": "Input",
                "tensor": [128, 224, 224, 3]
            },
            "data": {
                "parents": [],
                "type": "Input",
                "tensor": [128, 224, 224, 3]
            },
            "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
            ,
            "conv1-2": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [4, 4, 3, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
            ,
            "concat": {
                "parents": [
                    "conv1-1",
                    "conv1-2"
                ],
                "type": "Concatenate",
                "dim": 3
            }
        }
    }
    """)


    concat_test2 = json.loads("""
    {
        "name": "concat_op",
        "layers": {
            "data": {
                "parents": [],
                "type": "Input",
                "tensor": [128, 224, 224, 3]
            },
            "data": {
                "parents": [],
                "type": "Input",
                "tensor": [128, 224, 224, 3]
            },
            "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [4, 4, 3, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
            ,
            "conv1-2": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [4, 4, 3, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
            ,
            "concat": {
                "parents": [
                    "conv1-1",
                    "conv1-2"
                ],
                "type": "Concatenate",
                "dim": 3
            }
        }
    }
    """)

    search_space = {}
    #refty = refty(net=alexnet_2_dtype_format_op_error_spec)
    #refty = refty(net=concat_test2)

    total_start = time.time()
    paleo_time_start = time.time()
    refty = refty(net=concat_test2)
    paleo_time_end = time.time()
    refty_time_start = time.time()
    sym_name_dic = refty.warm_up(device_name=device_name, search_space=search_space)
    refty_time_end = time.time()
    logger.debug("sym_name_dic {}".format(sym_name_dic))
    init_end = time.time()
    
    time_list = []
    space_num = 1

    for i in range(space_num):
        start = time.time()
        result = refty.interactive_check(device_name=device_name, search_space=search_space, sym_name_dic = sym_name_dic)
        end = time.time()
        logger.debug("check result {}".format(result))
        time_list.append(end -start)

    total_end = time.time()
    logger.info("warmup time {} s, check per solution time {} s total time {}, \
        paleo warmup time {}, constraint context warmup time {}"\
        .format(init_end - init_start, time_list, total_end - total_start, \
        paleo_time_end - paleo_time_start, refty_time_end - refty_time_start))

def motivating_example():
    import sys
    sys.path.append('../')
    import json
    from refty.refty import Refty

    tiny_net_error = json.loads("""{
                    "name": "tiny net",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3000, 3000, 3, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)

    tiny_net_correct = json.loads("""{
                    "name": "tiny net",
                    "layers": {
                        "data": {
                            "parents": [],
                            "type": "Input",
                            "tensor": [128, 224, 224, 3]
                        },
                        "conv1-1": {
                            "parents": ["data"],
                            "type": "Convolution",
                            "filter": [3, 3, 3, 64],
                            "padding": "VALID",
                            "strides": [1, 1, 1, 1],
                            "activation_fn": "relu"
                        }
                    }
                }
                """)

    search_space = {}
    refty = Refty(net=tiny_net_error)
    sym_name_dic = refty.warm_up(device_name = "P100", search_space=search_space)
    result = refty.interactive_check(device_name = "P100", search_space=search_space, sym_name_dic = sym_name_dic)

    # refty = refty(net=tiny_net)
    # sym_name_dic = refty.warm_up(device_name = "P100", search_space=search_space)
    # result = refty.interactive_check(device_name = "P100", search_space=search_space, sym_name_dic = sym_name_dic)


#test_model()
motivating_example()
