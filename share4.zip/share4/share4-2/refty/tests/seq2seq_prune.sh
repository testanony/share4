#! /bin/sh
NET_FOLDER=nets/
NET_FILE=nets/seq2seq.json
OUT_FOLDER=results/seq2seq
OUT_FILE=results/seq2seq/log

if [ -d $OUT_FOLDER ];then
    rm -rf $OUT_FOLDER
fi
mkdir -p $OUT_FOLDER

python3 main.py $NET_FILE \
    --device_name=TITAN_X \
    --output_folder=$OUT_FOLDER \
    --search_space_path=$NET_FOLDER/seq2seq_search_space.json  |& tee $OUT_FILE