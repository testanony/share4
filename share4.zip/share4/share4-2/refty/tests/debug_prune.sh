#! /bin/sh
NET_FOLDER=nets/
NET_FILE=nets/debug.json
OUT_FOLDER=results/tmp
OUT_FILE=results/tmp/log

if [ -d $OUT_FOLDER ];then
    rm -rf $OUT_FOLDER
fi
mkdir -p $OUT_FOLDER

python3 main.py $NET_FILE \
    --device_name=TITAN_X \
    --output_folder=$OUT_FOLDER \
    --search_space_path=$NET_FOLDER/debug_search_space.json >> $OUT_FILE