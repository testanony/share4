"""[Distribued Solver Launcher]
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import subprocess
import os
import sys
from operator import add
from pyspark.sql import SparkSession
import time
import random


def z3_solving(index, data, use_multi_constraint = True):
    root_path = "results/autorefty"

    def construct_cmd(model_name, constraint_type, constraint, index):
        OUT_FOLDER = "{}/seq2seq_constraint_type_{}_constraint_{}_index_{}"\
            .format(root_path, constraint_type, constraint, index)

        if not os.path.isdir(OUT_FOLDER) and not os.path.exists(OUT_FOLDER):
            os.makedirs(OUT_FOLDER)
        
        try:
            cmd = "python refty/rnn_cost_solve.py --ctype {} \
                --csize {} --batch {} --interval {} --use_filter {} \
                --hidden_size \"{}\"\
                > {}/refty_search_spaces_statistic_{}.txt".format(
                constraint_type, constraint, batch_size, 1, use_filter,
                "16,20", OUT_FOLDER, random.randint(0, 1000))
            #print(cmd)
            result = subprocess.check_output([cmd], shell=True)
        except subprocess.CalledProcessError as e:
            raise RuntimeError("command '{}' return with error (code {})"\
                .format(e.cmd, e.returncode))

    def single_constraint_time_test_all():
        print("user single constraint")
        for model_name in ["LSTM"]:
            for constraint_type in ["fwd_FLOPs"]:
                index = 0
                constraints = []

                if constraint_type == "fwd_FLOPs":
                    for constraint in [5120000 * 1024 * 1024 * 1024 * 1024]:
                        construct_cmd(model_name, constraint_type, constraint,
                                      index)
                        index += 1

    
    

    single_constraint_time_test_all()
    return []


if __name__ == "__main__":
    result_array = {}

    for thread_num in [12, 8, 4, 1]:
        for interval_task_num in [2400, 480, 240, 48, 24, thread_num]:
            for use_filter in [0, 1]:
                start = time.time()
                bz_max = 4800
                batch_size = "{},{}".format(1, int(bz_max / interval_task_num))
                spark = SparkSession\
                    .builder\
                    .master("local[{}]".format(thread_num))\
                    .appName("distributed solving")\
                    .getOrCreate()
                search_spaces = spark.sparkContext.parallelize(range(0, bz_max),\
                                interval_task_num)
                results = search_spaces.mapPartitionsWithIndex(z3_solving)\
                            .collect()
                end = time.time()
                print("thread {}, task_num {}, bz range {}, use filter{}, time {}"\
                    .format(thread_num, interval_task_num, bz_max, use_filter, end - start))
                result_array["{}_{}_{}".format(thread_num, interval_task_num, use_filter)] \
                    = end - start
                spark.stop()

    baseline = 0

    for i in result_array:
        number = result_array[i]
        if number > baseline:
            baseline = number

    for i in result_array:
        print("thread num {}, results {}, speedup {}".format(i, \
            result_array[i], baseline / result_array[i]))
