# from __future__ import absolute_import
# from __future__ import division
# from __future__ import print_function

import logging
import os
import click
import sys
sys.path.append('../refty')
import time
from refty.refty import refty
from logger import logger
from refty.csp_solving import constraint_solving
from refty.csp_solving import check
from paleo.graph import OperationGraph
from paleo import device
import json


def test_model():
    device_name = "P40"

    alexnet_spec = json.loads("""{
                        "name": "Seq2Seq",
                        "layers": {
                            "cell1": {
                                "parents": [],
                                "type": "lstm", 
                                "batch": [128], 
                                "input_size": [1024],
                                "seq_len": [128],
                                "num_layers": [12],
                                "num_directions": [1], 
                                "hidden_size": [16],
                                "output_dim": [1]
                            }
                        }
                    }
                """)

    search_space = json.loads("""{
                    "constraints": [{"constraint": "fwd_FLOPs", "max": 10000000000000}]
                }""")

    search_space_4 = json.loads("""{
                    "constraints": [
                        {"constraint": "fwd_FLOPs", "max": 10000000000000}, 
                        {"constraint": "fwd_FLOPs", "max": 10000000000000}, 
                        {"constraint": "fwd_FLOPs", "max": 10000000000000}, 
                        {"constraint": "fwd_FLOPs", "max": 10000000000000}]
                }""")

    refty = refty(net=alexnet_spec)
    result = refty.check(device_name=device_name, search_space=search_space)
    logger.info("check result {}".format(result))

test_model()
