#! /bin/bash
export PYTHONPATH=$(pwd):$PYTHONPATH
python3 refty/unit_test/shape_infer_test.py "$@"
