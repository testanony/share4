from z3 import *
# reference:https://ericpony.github.io/z3py-tutorial/advanced-examples.htm

solver = Solver()
TensorDataType = Datatype('tensor_datatype')
TensorDataType.declare('int')
TensorDataType.declare('float32')
TensorDataType.declare('float64')
TensorDataType = TensorDataType.create()
Conv2D0 = Const('{}'.format("Conv2D0"), TensorDataType)
solver.add(Or(Conv2D0 == TensorDataType.float32, Conv2D0 == TensorDataType.float64))

while solver.check() == sat:
    m = solver.model()
    solver.add(Or([sym() != m[sym] for sym in m.decls()]))
    print(m)

