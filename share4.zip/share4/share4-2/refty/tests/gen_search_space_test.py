import json
from csp_solving import *


def read_search_space_file(path="nets/vgg16.json"):
    """
    Read search space and construct json dic
    
    Keyword Arguments:
        path {str} -- [path] (default: {"nets/search_space.json"})
    
    Returns:
        [type] -- [search space dic]
    """
    with open(path) as f:
        search_space = json.load(f)
        assert search_space is None
        return search_space


root = "nets/refty_test/"
file_list = [
    "vgg16.json", "resnet50.json", "nas_edge_unit_test.json",
    "mobilenetv2.json", "densenet.json", "alexnet.json"
]

for file_path in file_list:
    file_json = read_search_space_file("{}{}".format(root, file_path))

    search_space = {
        "constraint": {
            "mem": {
                "size": 100,
                "op": "gt"
            }
        },
        "name": file_path,
        "cube_contract": "False",
        "layers": {}
    }

    # large search space test
    bz_offset = 1000
    hy_offset = 5
    hs_offset = 1

    for layer_name in file_json["layers"]:
        print(layer_name)
        layer_spec = file_json["layers"][layer_name]
        search_space["layers"][layer_name] = {}

        if "tensor" in layer_spec:
            search_space["layers"][layer_name]["tensor"] = \
                {"_type": "randint", "_value": \
                [layer_spec["tensor"], \
                [layer_spec["tensor"][0] + bz_offset, \
                layer_spec["tensor"][1] + hy_offset, \
                layer_spec["tensor"][2] + hy_offset, \
                layer_spec["tensor"][3] + hy_offset]]}

        if "filter" in layer_spec:
            search_space["layers"][layer_name]["filter"] = \
                {"_type": "randint", "_value": \
                [layer_spec["filter"], \
                [layer_spec["filter"][0] + 1, \
                layer_spec["filter"][1] + 1, \
                layer_spec["filter"][2], \
                layer_spec["filter"][3]]]}

        # if "strides" in layer_spec:
        #     search_space["layers"][layer_name]["strides"] = {"_type": "randint", "_value": \
        #         [layer_spec["strides"], \
        #         [layer_spec["strides"][0], \
        #         layer_spec["strides"][1] + hs_offset, \
        #         layer_spec["strides"][2] + hs_offset, \
        #         layer_spec["strides"][3]]]}

        if "ksize" in layer_spec:
            search_space["layers"][layer_name]["ksize"] = \
                {"_type": "randint", "_value": \
                [layer_spec["ksize"], \
                [layer_spec["ksize"][0], \
                layer_spec["ksize"][1] + hy_offset, \
                layer_spec["ksize"][2] + hy_offset, \
                layer_spec["ksize"][3]]]}

    output_path = "{}{}".format(root, \
        file_path.replace(".json", "_search_space_gen.json"))

    with open(output_path, 'w') as outfile:
        json.dump(search_space, outfile, indent=4)

    # small search space test
    bz_offset = 5
    hy_offset = 1
    hs_offset = 1
    count_limit = 0
    for layer_name in file_json["layers"]:
        print(layer_name)
        layer_spec = file_json["layers"][layer_name]
        search_space["layers"][layer_name] = {}

        if "tensor" in layer_spec:
            search_space["layers"][layer_name]["tensor"] = \
                {"_type": "randint", "_value": \
                [layer_spec["tensor"], \
                [layer_spec["tensor"][0] + bz_offset, \
                layer_spec["tensor"][1] + hy_offset, \
                layer_spec["tensor"][2] + hy_offset, \
                layer_spec["tensor"][3] + hy_offset]]}

        if "filter" in layer_spec and count_limit < 2:
            search_space["layers"][layer_name]["filter"] = \
                {"_type": "randint", "_value": \
                [layer_spec["filter"], \
                [layer_spec["filter"][0] + 1, \
                layer_spec["filter"][1] + 1, \
                layer_spec["filter"][2], \
                layer_spec["filter"][3]]]}
            count_limit += 1

        # if "strides" in layer_spec:
        #     search_space["layers"][layer_name]["strides"] = {"_type": "randint", "_value": \
        #         [layer_spec["strides"], \
        #         [layer_spec["strides"][0], \
        #         layer_spec["strides"][1] + hs_offset, \
        #         layer_spec["strides"][2] + hs_offset, \
        #         layer_spec["strides"][3]]]}

        # if "ksize" in layer_spec:
        #     search_space["layers"][layer_name]["ksize"] = {"_type": "randint", "_value": \
        #         [layer_spec["ksize"], \
        #         [layer_spec["ksize"][0], \
        #         layer_spec["ksize"][1] + hy_offset, \
        #         layer_spec["ksize"][2] + hy_offset, \
        #         layer_spec["ksize"][3]]]}

    output_path = "{}{}".format(root, \
        file_path.replace(".json", "_search_space_gen_small.json"))

    with open(output_path, 'w') as outfile:
        json.dump(search_space, outfile, indent=4)
