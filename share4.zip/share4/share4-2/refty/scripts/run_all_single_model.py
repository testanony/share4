# <<<<<<< HEAD
import os
import click
import sys
#sys.path.append("..") 
#from logger import logger
import logging
import subprocess
import json

def list_folders(dir):
    subdirs = [x[0] for x in os.walk(dir)]
    return subdirs


HELP_VERBOSE = 'Whether to display debug level log messages.'
HELP_DEVICE_NAME = 'Device to estimate.'
logger = logging.getLogger('root')
FORMAT = "[%(filename)s:%(lineno)s - %(funcName)20s() ] %(message)s"
logging.basicConfig(stream=sys.stdout, format=FORMAT)
logger.setLevel(logging.DEBUG)

@click.group()
@click.option('--verbose', is_flag=False, help=HELP_VERBOSE)
def cli(verbose):
    if verbose:
        logger.setLevel(logging.DEBUG)
        
def stat(sub_folders, output_folder, framework_type):
    actual_positive = 0
    actual_negative = 0
    true_positive = 0
    false_positive = 0
    true_negative = 0 
    false_nega = 0
    for folder in sub_folders:
        base_name = os.path.basename(folder)
        sub_out_folder = output_folder + base_name
        cmp_file = sub_out_folder + "/cmp.json"
        try:
            with open(cmp_file, 'r') as f:
                cmp_dict = json.load(f)
                if cmp_dict["real_count"] == 1:
                    actual_positive += 1
                    if cmp_dict["check_count"] == 0:
                        false_nega += 1
                    else:
                        true_positive += 1
                else:
                    actual_negative += 1
                    if cmp_dict["check_count"] == 0:
                        true_negative  += 1
                    else:
                        false_positive += 1
        except Exception as e:
            print(str(e))
    if actual_positive != 0: 
        true_positive_rate  = float(float(true_positive)/float(actual_positive))
    else: 
        true_positive_rate  = - 1
    if actual_negative != 0:
        false_positive_rate = float(float(false_positive)/float(actual_negative))
    else:
        false_positive_rate = -1
    if actual_negative != 0:
        true_negative_rate  = float(float(true_negative)/float(actual_negative))
    else:
        true_negative_rate = -1
    if actual_positive != 0:
        false_negative_rate = float(float(false_nega)/float(actual_positive))
    else:
        false_negative_rate = - 1
    stat_file = output_folder + '/stat_{}.json'.format(framework_type)
    with open(stat_file, 'r+') as f:
        stat_dict = json.load(f)
        stat_dict['true_positive']       = true_positive
        stat_dict['actual_positive']     = actual_positive
        stat_dict['false_positive']      = false_positive
        stat_dict['false_negative']      = false_nega
        stat_dict['true_negative']       = true_negative
        stat_dict['actual_negative']     = actual_negative
        stat_dict['true_positive_rate']  = true_positive_rate
        stat_dict['false_positive_rate'] = false_positive_rate
        stat_dict['true_negative_rate']  = true_negative_rate
        stat_dict['false_negative_rate'] = false_negative_rate
        f.seek(0)
        f.truncate()
        json.dump(stat_dict, f, indent=4)
        
@cli.command()
@click.option('--input_folder',  default='/home/testcluster/zhengxian/dnncost/refty/sample/pytorch/vgg_16_all/')
@click.option('--output_folder', default='/home/testcluster/zhengxian/dnncost/refty/results/pt_vgg_16_total/')
@click.option('--net_name', default= "vgg_16")
@click.option('--need_check', default=True)
@click.option('--framework_type', default= "others")

def entry(input_folder, output_folder, net_name, need_check, framework_type):
   
    if not os.path.exists(output_folder):
        os.mkdir(output_folder)
    sub_folders = list(filter(lambda folder: os.path.basename(folder) != "", list_folders(input_folder)))
    total_cnt = len(sub_folders)
    stop_cnt = total_cnt
    base_value = 0
    cursor = base_value
    processes = []
    total_process = 12
    output_folders = []
    process_num = int(stop_cnt/total_process)
    real_sub_folders = []
    task_num = 0
    cmd_lst = []
    if need_check:
        for p in range(total_process):
            cmd_str = ""
            for i in range(process_num):
                if task_num >= stop_cnt:
                    break
                folder = sub_folders[task_num]
                base_name = os.path.basename(folder)
                if base_name != "":
                    real_sub_folders.append(folder)
                    task_num += 1
                    cursor += 1
                    sub_out_folder = output_folder + base_name
                    output_folders.append(sub_out_folder)
                    mkdir_cmd = "mkdir {}".format(sub_out_folder)
                    run_cmd = "python3 main.py {}/{}.json --device_name=TITAN_X \
                                        --output_folder={} \
                                        >> {}/log".format(
                                        folder, net_name, sub_out_folder, sub_out_folder)
                    cmd_str += mkdir_cmd + ";" + run_cmd + ";"
                else:
                    task_num += 1
                    stop_cnt += 1
                    cursor += 1
                    base_value += 1
            cmd_lst.append(cmd_str)
        last_cmd_str = cmd_lst[-1]
        for i in range(task_num, stop_cnt):
            folder = sub_folders[i]
            base_name = os.path.basename(folder)
            if base_name != "":
                real_sub_folders.append(folder)
                cursor += 1
                sub_out_folder = output_folder + base_name
                mkdir_cmd = "mkdir {}".format(sub_out_folder)
                run_cmd = "python3 main.py {}/{}.json --device_name=TITAN_X \
                                        --output_folder={} \
                                        >> {}/log".format(
                                        folder, net_name, sub_out_folder, sub_out_folder)
                last_cmd_str += mkdir_cmd + ";" + run_cmd + ";"
        cmd_lst[-1] = last_cmd_str
        for cmd in cmd_lst:
            print(cmd)
            p = subprocess.Popen(cmd,
                                shell=True,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT)
            p.stdout.close()
            processes.append(p)
        for p in processes:
            p.wait()
    stat_dict = dict()
    cnt = 0
    cursor = 0
    extra_catched_error = 0
    un_catched_error    = 0
    for folder in sub_folders:
        if cursor == stop_cnt:
            break
        base_name = os.path.basename(folder)
        sub_out_folder = output_folder + base_name
        if base_name != "":
            cursor += 1
            net_file = folder + "/{}.json".format(net_name)
            cmp_file = sub_out_folder + "/cmp.json"
            try:
                with open(net_file, 'r') as f:
                    with open(cmp_file, 'r+') as cmp:
                        data = json.load(f)
                        cmp_dict = json.load(cmp)
                        exception_flag = 'exception'
                        if framework_type == "tensorflow":
                            exception_flag = "exception_tensorflow"
                        if framework_type == "pytorch":
                            exception_flag = "exception_pytorch"
                        if "exception" in data or exception_flag in data:
                            cmp_dict["real_count"] = 0
                        else:
                            cmp_dict["real_count"] = 1
                        if cmp_dict['real_count'] != cmp_dict['check_count']:
                            stat_dict[cnt]          = dict()
                            stat_dict[cnt]['error'] = cmp_dict
                            stat_dict[cnt]['in']    = folder
                            stat_dict[cnt]['out']   = sub_out_folder
                            cnt += 1
                            if cmp_dict['real_count'] == 1:
                                extra_catched_error += 1
                            elif cmp_dict['real_count'] == 0:
                                un_catched_error += 1
                        cmp.seek(0)
                        cmp.truncate()
                        json.dump(cmp_dict, cmp)
            except Exception as e:
                print(str(e))
    stat_dict['extra_catched_error'] = extra_catched_error
    stat_dict['un_catched_error']    = un_catched_error
    stat_dict['error_rate'] = round(float((cnt)/total_cnt), 5)
    stat_file = output_folder + '/stat_{}.json'.format(framework_type)
    with open(stat_file, 'w') as f:
        json.dump(stat_dict, f, indent=4)
    stat(real_sub_folders, output_folder, framework_type)

if __name__ == '__main__':
    #sub_folders = list_folders("/home/testcluster/zhengxian/dnncost/refty/sample/pytorch/vgg_13_total/")
    print("in entry")
# =======
# import os
# import click
# import sys
# #sys.path.append("..") 
# #from logger import logger
# import logging
# import subprocess
# import json
# def list_folders(dir):
#     subdirs = [x[0] for x in os.walk(dir)]
#     return subdirs


# HELP_VERBOSE = 'Whether to display debug level log messages.'
# HELP_DEVICE_NAME = 'Device to estimate.'
# logger = logging.getLogger('root')
# FORMAT = "[%(filename)s:%(lineno)s - %(funcName)20s() ] %(message)s"
# logging.basicConfig(stream=sys.stdout, format=FORMAT)
# logger.setLevel(logging.DEBUG)

# @click.group()
# @click.option('--verbose', is_flag=False, help=HELP_VERBOSE)
# def cli(verbose):
#     if verbose:
#         logger.setLevel(logging.DEBUG)
        
# def stat(sub_folders, output_folder):
#     actual_positive = 0
#     actual_negative = 0
#     true_positive = 0
#     false_positive = 0
#     true_negative = 0 
#     false_nega = 0
#     for folder in sub_folders:
#         base_name = os.path.basename(folder)
#         sub_out_folder = output_folder + base_name
#         cmp_file = sub_out_folder + "/cmp.json"
#         try:
#             with open(cmp_file, 'r') as f:
#                 cmp_dict = json.load(f)
#                 if cmp_dict["real_count"] == 1:
#                     actual_positive += 1
#                     if cmp_dict["check_count"] == 0:
#                         false_nega += 1
#                     else:
#                         true_positive += 1
#                 else:
#                     actual_negative += 1
#                     if cmp_dict["check_count"] == 0:
#                         true_negative  += 1
#                     else:
#                         false_positive += 1
#         except Exception as e:
#             print(str(e))
#     true_positive_rate  = float(true_positive/actual_positive)
#     false_positive_rate = float(false_positive/actual_negative)
#     true_negative_rate  = float(true_negative/actual_negative)
#     false_negative_rate = float(false_nega/actual_positive)
#     stat_file = output_folder + '/stat.json'
#     with open(stat_file, 'r+') as f:
#         stat_dict = json.load(f)
#         stat_dict['true_positive']       = true_positive
#         stat_dict['actual_positive']     = actual_positive
#         stat_dict['false_positive']      = false_positive
#         stat_dict['false_negative']      = false_nega
#         stat_dict['true_negative']       = true_negative
#         stat_dict['actual_negative']     = actual_negative
#         stat_dict['true_positive_rate']  = true_positive_rate
#         stat_dict['false_positive_rate'] = false_positive_rate
#         stat_dict['true_negative_rate']  = true_negative_rate
#         stat_dict['false_negative_rate'] = false_negative_rate
#         f.seek(0)
#         f.truncate()
#         json.dump(stat_dict, f, indent=4)
        
# @cli.command()
# @click.option('--input_folder',  default='/home/testcluster/zhengxian/dnncost/refty/sample/pytorch/vgg_16_all/')
# @click.option('--output_folder', default='/home/testcluster/zhengxian/dnncost/refty/results/pt_vgg_16_total/')
# @click.option('--net_name', default= "vgg_16")
# @click.option('--need_check', default=True)
# def entry(input_folder, output_folder, net_name, need_check):
   
#     if not os.path.exists(output_folder):
#         os.mkdir(output_folder)
#     sub_folders = list(filter(lambda folder: os.path.basename(folder) != "", list_folders(input_folder)))
#     total_cnt = len(sub_folders)
#     stop_cnt = total_cnt
#     base_value = 0
#     cursor = base_value
#     processes = []
#     total_process = 12
#     output_folders = []
#     process_num = int(stop_cnt/total_process)
#     real_sub_folders = []
#     task_num = 0
#     cmd_lst = []
#     if need_check:
#         for p in range(total_process):
#             cmd_str = ""
#             for i in range(process_num):
#                 if task_num >= stop_cnt:
#                     break
#                 folder = sub_folders[task_num]
#                 base_name = os.path.basename(folder)
#                 if base_name != "":
#                     real_sub_folders.append(folder)
#                     task_num += 1
#                     cursor += 1
#                     sub_out_folder = output_folder + base_name
#                     output_folders.append(sub_out_folder)
#                     mkdir_cmd = "mkdir {}".format(sub_out_folder)
#                     run_cmd = "python3 main.py {}/{}.json --device_name=TITAN_X \
#                                         --output_folder={} \
#                                         >> {}/log".format(
#                                         folder, net_name, sub_out_folder, sub_out_folder)
#                     cmd_str += mkdir_cmd + ";" + run_cmd + ";"
#                 else:
#                     task_num += 1
#                     stop_cnt += 1
#                     cursor += 1
#                     base_value += 1
#             cmd_lst.append(cmd_str)
#         last_cmd_str = cmd_lst[-1]
#         for i in range(task_num, stop_cnt):
#             folder = sub_folders[i]
#             base_name = os.path.basename(folder)
#             if base_name != "":
#                 real_sub_folders.append(folder)
#                 cursor += 1
#                 sub_out_folder = output_folder + base_name
#                 mkdir_cmd = "mkdir {}".format(sub_out_folder)
#                 run_cmd = "python3 main.py {}/{}.json --device_name=TITAN_X \
#                                         --output_folder={} \
#                                         >> {}/log".format(
#                                         folder, net_name, sub_out_folder, sub_out_folder)
#                 last_cmd_str += mkdir_cmd + ";" + run_cmd + ";"
#         cmd_lst[-1] = last_cmd_str
#         for cmd in cmd_lst:
#             p = subprocess.Popen(cmd,
#                                 shell=True,
#                                     stdout=subprocess.PIPE,
#                                     stderr=subprocess.STDOUT)
#             p.stdout.close()
#             processes.append(p)
#         for p in processes:
#             p.wait()
#     stat_dict = dict()
#     cnt = 0
#     cursor = 0
#     extra_catched_error = 0
#     un_catched_error    = 0
#     for folder in sub_folders:
#         if cursor == stop_cnt:
#             break
#         base_name = os.path.basename(folder)
#         sub_out_folder = output_folder + base_name
#         if base_name != "":
#             cursor += 1
#             net_file = folder + "/{}.json".format(net_name)
#             cmp_file = sub_out_folder + "/cmp.json"
#             try:
#                 with open(net_file, 'r') as f:
#                     with open(cmp_file, 'r+') as cmp:
#                         data = json.load(f)
#                         cmp_dict = json.load(cmp)
#                         if "exception" in data:
#                             cmp_dict["real_count"] = 0
#                         else:
#                             cmp_dict["real_count"] = 1
#                         if cmp_dict['real_count'] != cmp_dict['check_count']:
#                             stat_dict[cnt]          = dict()
#                             stat_dict[cnt]['error'] = cmp_dict
#                             stat_dict[cnt]['in']    = folder
#                             stat_dict[cnt]['out']   = sub_out_folder
#                             cnt += 1
#                             if cmp_dict['real_count'] == 1:
#                                 extra_catched_error += 1
#                             elif cmp_dict['real_count'] == 0:
#                                 un_catched_error += 1
#                         cmp.seek(0)
#                         cmp.truncate()
#                         json.dump(cmp_dict, cmp)
#             except Exception as e:
#                 print(str(e))
#     stat_dict['extra_catched_error'] = extra_catched_error
#     stat_dict['un_catched_error']    = un_catched_error
#     stat_dict['error_rate'] = round(float((cnt)/total_cnt), 5)
#     stat_file = output_folder + '/stat.json'
#     with open(stat_file, 'w') as f:
#         json.dump(stat_dict, f, indent=4)
#     stat(real_sub_folders, output_folder)

# if __name__ == '__main__':
#     #sub_folders = list_folders("/home/testcluster/zhengxian/dnncost/refty/sample/pytorch/vgg_13_total/")
#     print("in entry")
# >>>>>>> master
    entry()