cd ..
python3 main.py sample/pytorch/vgg13_right/vgg_13.json --device_name=TITAN_X --output_folder=results/vgg13_no_ss_right >> results/vgg13_no_ss_right/log