cd ..
python3 scripts/run_all_single_model.py