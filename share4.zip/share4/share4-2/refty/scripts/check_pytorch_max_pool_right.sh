cd ..
mkdir results/max_pool
python3 main.py sample/pytorch/max_pool/max_pool.json --device_name=TITAN_X --output_folder=results/max_pool --search_space_path=sample/pytorch/max_pool/max_pool_search_space.json >> results/max_pool/logls
