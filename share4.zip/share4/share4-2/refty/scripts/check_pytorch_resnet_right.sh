cd ..
python3 main.py sample/pytorch/resnet101/resnet_101.json --device_name=TITAN_X --output_folder=results/resnet101  >> results/resnet101/log