cd ..
REPO_PATH=/home/testcluster/yanjga/pythia_exp/dnncost
MODEL_NAME=mnist_pythia
# /home/testcluster/yanjga/pythia_exp/dnncost/refty/scripts/
python3 $REPO_PATH/refty/scripts/run_all_single_model_pythia_statistic.py --input_folder=$REPO_PATH/refty_data/pythia_bench/mnist_pythia_refty_test/ --output_folder=$REPO_PATH/refty/results/$MODEL_NAME/ --net_name=$MODEL_NAME
