from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import logging
import os
import click
from paleo.graph import OperationGraph
from paleo import device
from logger import logger
from refty.csp_solving import constraint_solving
from refty.csp_solving import check
from refty.refty import refty
import json

HELP_VERBOSE = 'Whether to display debug level log messages.'
HELP_DEVICE_NAME = 'Device to estimate.'


@click.group()
@click.option('--verbose', is_flag=True, help=HELP_VERBOSE)
def cli(verbose):
    if verbose:
        logger.setLevel(logging.DEBUG)


@cli.command()
@click.argument('netspec_files', nargs=-1)
@click.option('--device_name', default='TITAN_X', help=HELP_DEVICE_NAME)
@click.option('--output_folder', default='/tmp')
@click.option('--search_space_path', default=None)
@click.option('--parallel', default=False)
@click.option('--is_for_rnn', default=False)
@click.option('--diagnosis', default=False)
def refty_entry(netspec_files, device_name, output_folder, search_space_path, \
                 parallel, is_for_rnn, diagnosis):

    if  diagnosis:
        global use_refty_op_topo_solving
        global use_refty_diagnosis_mode
        use_refty_op_topo_solving = True
        use_refty_diagnosis_mode = True 

    for netspec_file in netspec_files:
        refty = refty(netspec_file, for_rnn=is_for_rnn)
        if parallel:
            refty.parallel_prune(device_name,
                                 output_folder,
                                 search_space_path=search_space_path)
        else: 
            refty.prune(device_name,
                         output_folder,
                         search_space_path=search_space_path)


if __name__ == '__main__':
    refty_entry()
