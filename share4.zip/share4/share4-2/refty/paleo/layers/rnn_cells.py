"""Definitions of RNN Cells."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
from paleo.layers import base


class RNN(base.BaseLayer):
    def __init__(self, name, inputs, cell_type, seq_len, num_layers,
                 num_directions, hidden_size, output_dim):
        super(RNN, self).__init__(name, cell_type)
        self._name = name
        self._inputs = inputs
        #self._outputs = [self._inputs[0], output_dim]
        self._layertype = cell_type
        self._seq_len = seq_len
        self._batch_size = self._inputs[0]
        self._input_size = self._inputs[1]
        self._num_layers = num_layers
        self._num_directions = num_directions
        self._hidden_size = hidden_size
        self._output_dim = output_dim