from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import logging
from logger import logger
import os
import click
import onnx
from onnx import shape_inference
import google.protobuf.json_format as json_format

HELP_VERBOSE = 'Whether to display debug level log messages.'

@click.group()
@click.option('--verbose', is_flag=True, help=HELP_VERBOSE)
def cli(verbose):
    if verbose:
        logger.setLevel(logging.DEBUG)

@cli.command()
@click.argument('onnx_files', nargs=-1)
def dump_IR(onnx_files):
    print(onnx_files)
    for onnx_file in onnx_files:
        portion = os.path.splitext(onnx_file)
        if os.path.exists(onnx_file) and portion[1] == '.onnx':
            onnx_model = onnx.load(onnx_file)
            json_str = json_format.MessageToJson(onnx_model.graph, preserving_proto_field_name=True)
            filename = portion[0] + '.json'
            with open(filename, "w") as of:
                of.write(json_str)
            print("IR network structure is saved.")

if __name__ == '__main__':
    dump_IR()
