from z3 import *
from refty.param import *
from logger import logger
import time 

def get_solver_opt(ctx=None):
    if use_opt:
        if ctx == None:
            return Optimize()
        else:
            return Optimize(ctx=ctx)
    else:
        if ctx == None:
            s = reftySolver()
            if use_unsatcore:
                s.set(unsat_core=True)
            return s
        else:
            s = reftySolver(ctx=ctx)
            if use_unsatcore:
                s.set(unsat_core=True)
            return s


class reftySolver(Solver):
    """
    Add sub class and switch to call unsat core and avoid code change for 
    refty

    Args:
        Solver 
    """
    def __init__(self, solver=None, ctx=None, logFile=None):
        super().__init__(solver, ctx, logFile)
        self.ctx = ctx
        self.cond_list = []
        self.cache_add = False # Support cache constraint add one time functions
        self.flag = False

    def set_add_flag(self, cache_add):
        self.cache_add = cache_add


    def push_add(self, *args):
        self.cond_list.append(*args)      

    def pop_add(self):
        start = time.time()
        if use_unsatcore:
            super().assert_and_track(self.cond_list, '{}'.format(str(self.cond_list)))
        else:
            super().add(And(self.cond_list, self.ctx))
        end = time.time()
        self.cond_list = []
        logger.debug("add batch constraint {} time".format(end - start))

    def add_annotate(self, flag, reason):
        self.flag = flag
        self.reason = reason 

    def pop(self):
        super().pop()
        logger.debug("pop constraint")

    def add(self, *args):
        """
        Add constraints.
        >>> x = Int('x')
        >>> g = Goal()
        >>> g.add(x > 0, x < 2)
        >>> g
        [x > 0, x < 2]
        """
        if not self.cache_add:
            # if use_unsatcore:
            #     logger.debug(str(args[0]))
            #     super().assert_and_track(*args, '{}'.format(str(args[0])))
            # else:
            #     super().add(*args)
            if use_unsatcore:
                logger.debug(str(args[0]))
                try: 
                    #if self.flag == False:
                    super().assert_and_track(*args, '{}'.format(str(args[0])))
                    # else:
                    #     super().assert_and_track(*args, '{}'.format(str(self.reason)))
                    #     self.flag = False
                    #     self.reason = ""
                except Exception as e:
                    logger.debug("exception in solver unsat core {}".format(e))
            else:
                super().add(*args)
        else:
            self.push_add(*args)

    # def model():
    #     return solver.model()
