from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from type.tensor import *

class HyperparamterTensor(Tensor):
    def __init__(self, op_name, tensor_name, rank, ctx, layer_id, op_type):
        super(HyperparamterTensor, self).__init__(rank, ctx, op_name, tensor_name, layer_id, op_type)

class Hyperparameter(object):
    name = 0
    domain_type = "choice" # other is range
    domain = []

    def __init__(self, name, domain_type, domain):
        self.name = name
        self.domain_type = domain_type
        self.domain = domain 
        
    def check():
        return
