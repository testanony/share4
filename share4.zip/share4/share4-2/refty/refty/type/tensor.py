from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from init_var_sym import *
#from type.datatype_enum import TensorDataType
#from type.dataformat_enum import TensorFormat

hyper_dict = {'IN': ['input'], 
              'conv2d': ['filter', 'stride', 'padding'],
              'pool2d': ['kernel', 'stride', 'padding'],
              'Flatten': ['output_shape'],
              'Linear': ['filter', 'stride']}

class NetSpec:
    def __init__(self, num):
        self.net_spec = dict()
        self.layer_num = num
        self.input_rank = 4
        
        
    def add(self, layer_id, op, rank):
        if layer_id == 0:
            print("op: ", op)
            #assert op == 'data'
            self.input_rank = rank
        else:
            self.net_spec[layer_id] = (op, rank)
        
    def to_solution(self, model):
        def get_in_tensor(layer_id, rank, model_dict):
            name = "{}:{}:{}".format(layer_id, "IN", "input")
            ret = ""
            value = []
            for j in range(rank):
                re_name = name+':{}'.format(j)
                if re_name in model_dict:
                    value.append(model_dict[re_name])
            ret += name +'=' + ' '.join(value) + '\n'
            return ret
        
        def get_out_tensor(layer_id, rank, model_dict):
            name = "{}:{}:{}".format(layer_id, "OUT", "output")
            ret = ""
            value = []
            for j in range(rank):
                re_name = name+':{}'.format(j)
                if re_name in model_dict:
                    value.append(model_dict[re_name])
            ret += name +':' + ' '.join(value) + '\n'
            return ret
        
        ret = ""
        input_tensor = "0:IN:input"
        value = []
        print("real model: ", model)
        model_dict = dict()
        for i in model.decls():
            model_dict[i.name()] = "{}".format(model[i])
        print("model dict: ", model_dict)
        for i in range(self.input_rank):
            value.append(model_dict[input_tensor+':{}'.format(i)])
        ret += input_tensor+':' + ' '.join(value)
        ret += '\n'
        value = []
        print("layer num: ", self.layer_num)
        for i in range(1, self.layer_num): 
            op, rank = self.net_spec[i]
            ret += "---------" + op + "---------\n"
            ret += get_in_tensor(i, rank, model_dict)
            if op in hyper_dict:
                for hyper in hyper_dict[op]:
                    name = "{}:{}:{}".format(i, op, hyper)
                    for j in range(rank):
                        real_name = name+':{}'.format(j)
                        if real_name in model_dict:
                            value.append(model_dict[real_name])
                    ret += name +':' + ' '.join(value) + '\n'
                    value = []
            elif op == "reshape":
                pass
            else:
                ret += "[doen't attach]" + op + "\n"
            ret += get_out_tensor(i, rank, model_dict)
            ret += "---------" + op + "---------\n"
        return ret

# DataFormat = Datatype('DataFormat')
# DataFormat.declare('N')
# DataFormat.declare('C')
# DataFormat.declare('H')
# DataFormat.declare('W')
# DataFormat.declare('S')
# DataFormat.declare('E') 

# DataFormat = DataFormat.create()

# dataformat_dic = {
#     'N':DataFormat.N,
#     'C':DataFormat.C,
#     'H':DataFormat.H,
#     'W':DataFormat.W,
#     'S':DataFormat.S,
#     'E':DataFormat.E
# }

# DataType = Datatype('DataType')
# DataType.declare('string')
# DataType.declare('char')
# DataType.declare('int8')
# DataType.declare('int32')
# DataType.declare('float32')
# DataType.declare('float64')

#DataType = DataType.create()

# datatype_dic = {
#     "int8": DataType.int32,
#     "int32": DataType.int32,
#     "float32": DataType.float32,
#     "float64": DataType.float64,
#     "double": DataType.float64,
#     "char": DataType.char,
#     "string": DataType.string,
# }

dataformat_dic = {
    'N':0,
    'C':1,
    'H':2,
    'W':3,
    'S':4,
    'E':5
}

datatype_dic = {
    "int8": 0,
    "int32": 1,
    "float32": 2,
    "float64": 3,
    "double": 4,
    "char": 5,
    "string": 6,
}

class Tensor(object):
    def __init__(self, rank, ctx, op_name, tensor_name, layer_id, 
                 op_type = "unkown", data_type = None):
        self.rank = rank
        self.op_name = op_name
        self.op_type = op_type
        self.tensor_name = tensor_name
        self.layer_id = layer_id
        self.symbol_name_prefix = '{}:{}:{}:{}'.format(\
                self.layer_id, self.op_type, self.op_name, self.tensor_name)
        self.ctx = ctx
        self.init_all_dims(ctx)

    def init_all_dims(self, ctx):
        names = []
        for i in range(self.rank):
            names.append('{}:{}'.format(self.symbol_name_prefix, i))
        self.name = ' '.join(names)
        self.dims_symbol = init_solver_variables(self.name, ctx)

    def get_all_dims(self):
        return self.dims_symbol


class InputTensor(Tensor):
    def __init__(self, rank, ctx, layer_id):
        super(InputTensor, self).__init__(rank, ctx, "IN", "input", layer_id, op_type="data")
        self.data_type = init_solver_variables('{}:datatype'.format(self.symbol_name_prefix), ctx)
        self.init_all_dataformats()

    def init_all_dataformats(self):
        names = []
        for i in range(self.rank):
            names.append('{}:dataformat:{}'.format(self.symbol_name_prefix, i)) 
        self.data_format_name = ' '.join(names)
        self.data_format = init_solver_variables(self.data_format_name, self.ctx) 


class OutputTensor(Tensor):
    def __init__(self, rank, ctx, layer_id):
        super(OutputTensor, self).__init__(rank, ctx, "OUT", "output", layer_id, op_type="data")
