"""[Distribued Solver Launcher]
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import subprocess
import os
import sys
import inspect
currentdir = os.path.dirname(
    os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)
from operator import add
from pyspark.sql import SparkSession
from refty.gen_solver_constraint import *
from refty.gen_solver_variable import *
from logger import logger
import argparse
import time
from refty.param import *

parser = argparse.ArgumentParser()
parser.add_argument('-nf',
                    '--net_file',
                    type=str,
                    help='')
parser.add_argument('-thn',
                    '--thread_num',
                    type=int,
                    help='')
parser.add_argument('-ss',
                    '--search_space_path',
                    type=str,
                    help='')
parser.add_argument('-d',
                    '--device',
                    type=str,
                    default = "P40",
                    help='')
parser.add_argument('-o',
                    '--output_path',
                    type=str,
                    help='')
parser.add_argument('-tn',
                    '--task_number',
                    type=int,
                    help='')
parser.add_argument('-di',
                    '--diagnosis',
                    type=int,
                    help='')

class ParallelLauncher:
    def __init__(self,
                 thread_num=1,
                 master="local",
                 app_name="parallel solving"):
        if master == "local":
            master = "local[{}]".format(thread_num)

        self.spark = SparkSession \
            .builder \
            .master(master) \
            .appName(app_name) \
            .getOrCreate()

    def parse_search_space(search_space_path, task_number):
        print("search_space_path {}".format(search_space_path))
        search_space = read_search_space_file(path=search_space_path)
        print("search space {}".format(search_space))
        search_space_list, a, b, c = parallel_search_space_analysis(search_space, \
                                                                    degree = task_number)
        print(search_space_list)
        parallel_degree = len(search_space_list)
        # logger.debug("parallel degree {}".format(parallel_degree))
        print("task number {} search space len {}".format(task_number, len(search_space_list)))
        assert task_number <= len(search_space_list)
        return search_space_list

    def parallel_solving(self, net_file, search_space_list, device, \
                         output_path, \
                         task_number = 5, \
                         diagnosis = False):
        """
        parallel solving through pyspark

        Args:
            net_file : [description
            search_space_path : [description
            device : [description
        """
        print("search_space_path {}".format(search_space_path))
        search_space = read_search_space_file(path=search_space_path)
        print("search space {}".format(search_space))
        search_space_list, a, b, c = parallel_search_space_analysis(search_space, \
                                                                    degree = task_number)
        print(search_space_list)
        parallel_degree = len(search_space_list)
        logger.debug("parallel degree {}".format(parallel_degree))
        print("task number {} search space len {}".format(task_number, len(search_space_list)))
        assert task_number <= len(search_space_list)
        search_spaces = self.spark.sparkContext.parallelize(search_space_list, \
                                                            task_number)
        if not os.path.exists(output_path):
            os.mkdir(output_path)

        def csp_solving(index, search_spaces):
            output_path = "results"

            solutions = []
            for search_space in search_spaces:
                print("index {} search_space {}".format(index, search_space))
                sf = "./results/s_p_{}.json".format(index)
                with open(sf, 'w') as outfile:
                    print(search_space)
                    json.dump(search_space, outfile)
                output_path = output_path + "/test_dist_{}".format(index)
                if not os.path.exists(output_path):
                    os.mkdir(output_path)
                cmd = "./refty.sh {} \
                        --device_name={}  \
                        --search_space_path={} \
                        --output_folder={} \
                        --diagnosis={}>> {}".format( \
                            net_file,
                            "P40",
                            sf,
                            output_path,
                            diagnosis,
                            output_path+"/log")
                print(cmd)
                result = subprocess.check_output([cmd], shell=True)
                solution = ""
                # with open(output_path + "/{}" \
                #     .format("sub_search_space_{}_statistics.txt" \
                #         .format(index)), 'r') as results_file:
                #     solution = results_file.read()
                solutions.append(solution)
            return solutions

        results = search_spaces.mapPartitionsWithIndex(csp_solving) \
                    .collect()

    def parallel_solving_nets(self, net_file_list, device, \
                         output_path, \
                         task_number = 5, \
                         diagnosis = False):
        """
        parallel solving through pyspark

        Args:
            net_file : [description
            search_space_path : [description
            device : [description
        """
       
        search_spaces = self.spark.sparkContext.parallelize(net_file_list, \
                                                            task_number)
        if not os.path.exists(output_path):
            os.mkdir(output_path)

        def csp_solving(index, net_file_list):
            output_path = "results"

            solutions = []
            for net_file_item in net_file_list:
                print("index {} net_file_item {}".format(index, net_file_item))
                sf = "./results/s_p_{}.json".format(index)

                with open(sf, 'w') as outfile:
                    print(net_file_item)
                    json.dump(net_file_item, outfile)
                
                output_path = output_path + "/test_dist_{}".format(index)

                if not os.path.exists(output_path):
                    os.mkdir(output_path)

                cmd = "./refty.sh {} \
                        --device_name={}  \
                        --output_folder={} \
                        --diagnosis={}>> {}".format( \
                            net_file_item,
                            "P40",
                            output_path,
                            diagnosis,
                            output_path+"/log")
                print(cmd)
                result = subprocess.check_output([cmd], shell=True)
                solution = ""
                # with open(output_path + "/{}" \
                #     .format("sub_search_space_{}_statistics.txt" \
                #         .format(index)), 'r') as results_file:
                #     solution = results_file.read()
                solutions.append(solution)
            return solutions

        results = search_spaces.mapPartitionsWithIndex(csp_solving) \
                    .collect()

    def close():
        self.spark.stop()

def search_space_exp_test():
    args = parser.parse_args()

    if  args.diagnosis == 1:
        diagnosis = True
    else:
        diagnosis = False

    with open("time_statistics.txt", "a") as f:
        launcher = ParallelLauncher(thread_num = args.thread_num)
        start = time.time()
        
        launcher.parallel_solving(net_file = args.net_file, \
                                search_space_path = parse_search_space(args.search_space_path, args.task_number), \
                                device = args.device, \
                                output_path = args.output_path, \
                                task_number = args.task_number, \
                                diagnosis = diagnosis)
        end = time.time()
        f.write("thread num {} tiny space num {} time {} \n"\
                .format(args.thread_num, args.task_number, end - start))

def generated_netfile_list_test():
    from product_search_space_exp import product_search_space
    net_file_list = product_search_space()
    args = parser.parse_args()

    if  args.diagnosis == 1:
        diagnosis = True
    else:
        diagnosis = False

    with open("time_statistics.txt", "a") as f:
        launcher = ParallelLauncher(thread_num = args.thread_num)
        start = time.time()
        
        launcher.parallel_solving_nets(net_file_list = net_file_list, \
                                  device = args.device, \
                                  output_path = args.output_path, \
                                  task_number = args.task_number, \
                                  diagnosis = diagnosis)
        end = time.time()
        f.write("thread num {} tiny space num {} time {} \n"\
                .format(args.thread_num, args.task_number, end - start))


if __name__ == "__main__":
    # search space pruning test
    # search_space_exp_test()

    # sigle trial each solving test
    generated_netfile_list_test()
   
