import os
import click
from paleo.graph import OperationGraph
from paleo import device
from logger import logger
from refty.csp_solving import constraint_solving
from refty.csp_solving import check
from refty.csp_solving import interactive_check
import json
from refty.parallel_dist_launcher import ParallelLauncher

class RnnGraph():
    def __init__(self, netfile):
        self.netfile = netfile
        with open(self.netfile, "r") as f:
            net = json.load(f)

class Refty():
    def __init__(self, netspec_file=None, net=None, for_rnn=False):
        """Initialize a given network architecture."""
        self.for_rnn = for_rnn
        self.netspec_file = netspec_file
        if for_rnn:
            with open(self.netspec_file, "r") as f:
                self.graph = json.load(f)
            logger.debug("Computation Graphs: {}".format(str(self.graph)))
            self.parallel_launcher = None
        else:
            self.netspec_file = netspec_file
            if netspec_file and not net:
                self.graph = OperationGraph(filename=netspec_file)
                logger.debug('Net IR loaded from {}.'.format(netspec_file))

            if net and not netspec_file:
                self.graph = OperationGraph(net=net)
            logger.debug('Computation Graphs: {}'.format(str(self.graph.nested_list)))
            self.parallel_launcher = None

    def check(self, device_name, search_space=None):
        """
        interactive mode of refty

        Args:
            device_name : device name
            search_space_path : search space path
            Defaults to None.

        Returns:
            SAT or UNSAT
        """
        device_spec = device.DEVICES[device_name]

        return check(layer_list=self.graph.topology_order,
                     device_spec=device_spec,
                     search_space=search_space)

    def warm_up(self, device_name, search_space=None):
        """
        interactive mode of refty

        Args:
            device_name : device name
            search_space_path : search space path
            Defaults to None.

        Returns:
            SAT or UNSAT
        """
        device_spec = device.DEVICES[device_name]

        return check(layer_list=self.graph.topology_order,
                     device_spec=device_spec,
                     search_space=search_space,
                     skip_param_domain=True)

    def interactive_check(self, device_name, search_space=None, sym_name_dic = {}):
        """
        interactive mode of refty

        Args:
            device_name : device name
            search_space_path : search space path
            Defaults to None.

        Returns:
            SAT or UNSAT
        """
        device_spec = device.DEVICES[device_name]

        return interactive_check(layer_list=self.graph.topology_order,
                     device_spec=device_spec,
                     search_space=search_space,
                     sym_name_dic = sym_name_dic)

    def prune(self, device_name, output_folder, search_space_path=None):
        """
        pruning mode of refty

        Args:
            device_name : device name
            output_folder : output folder
            search_space_path : search space path. Defaults to None.
        """
        device_spec = device.DEVICES[device_name]

        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        print(search_space_path)
        if not self.for_rnn:
            constraint_solving(output_folder,
                                layer_list=self.graph.topology_order,
                                device_spec=device_spec,
                                search_space_path=search_space_path)
        else:
            constraint_solving(output_folder,
                               layer_list=self.graph["layers"],
                               device_spec=device_spec,
                               search_space_path=search_space_path,
                               for_rnn = self.for_rnn)

    def parallel_prune(self,
                       device_name,
                       output_folder,
                       search_space_path=None):
        if self.parallel_launcher == None:
            self.parallel_launcher = ParallelLauncher(thread_num=5)
        self.parallel_launcher.parallel_solving(self.netspec_file, \
                                          search_space_path, \
                                          device_name, \
                                          output_folder, \
                                          task_number = 5)
        self.parallel_launcher.close()


class Refty(refty):
    def __init__(self, netspec_file=None, net=None, for_rnn=False):
        refty.__init__(self, netspec_file = netspec_file, net = net, for_rnn = for_rnn)