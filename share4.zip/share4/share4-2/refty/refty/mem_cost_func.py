"""Code generation of refty solver memory equations
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from z3 import *
from logger import logger
import math
import numpy as np


def rnn_tensor_cost(mode,
                    seq_len,
                    batch,
                    input_size,
                    num_layers,
                    num_directions,
                    hidden_size,
                    output_dim=1):
    return batch * input_size + \
        batch * hidden_size * num_directions * output_dim


def rnn_in_out_cost(mode,
                    seq_len,
                    batch,
                    input_size,
                    num_layers,
                    num_directions,
                    hidden_size,
                    output_dim=1):

    # set up required dimensions for input, output, and hidden state tensors
    dimIn = []
    dimIn.append(batch)
    dimIn.append(input_size)
    dimIn.append(1)
    dimOut = []
    dimOut.append(batch)

    if num_directions == 2:
        dimOut.append(hidden_size * 2)
    else:
        dimOut.append(hidden_size * 1)

    dimOut.append(output_dim)

    dimHidden = []

    # calculating total elements per each
    inputTensorSize = dimIn[0] * dimIn[1] * dimIn[2]
    outputTensorSize = dimOut[0] * dimOut[1] * dimOut[2]
    return inputTensorSize, outputTensorSize


def rnn_mem(mode,
            seq_len,
            batch,
            input_size,
            num_layers,
            num_directions,
            hidden_size,
            output_dim=1,
            unit=1):
    """
    RNN mem cost func   
    # TODO: does it related with num_directions??
    Arguments:
        seq_len -- 
        batch -- 
        input_size -- 
        num_layers -- 
        num_directions -- 
        hidden_size -- 
    """

    T_ELEM = 4
    num_mats = 2

    if mode == "GRU":
        num_mats = 6
    elif mode == "LSTM":
        num_mats = 8
    else:
        num_mats = 2

    weights = hidden_size * input_size * num_layers * num_mats * T_ELEM

    # set up required dimensions for input, output, and hidden state tensors
    dimIn = []
    dimIn.append(batch)
    dimIn.append(input_size)
    dimIn.append(1)
    dimOut = []
    dimOut.append(batch)

    if num_directions == 2:
        dimOut.append(hidden_size * 2)
    else:
        dimOut.append(hidden_size * 1)

    dimOut.append(output_dim)

    dimHidden = []

    if num_directions == 2:
        dimHidden.append(num_layers * 2)
    else:
        dimHidden.append(num_layers * 1)
    dimHidden.append(batch)
    dimHidden.append(hidden_size)

    # calculating total elements per each
    inputTensorSize = dimIn[0] * dimIn[1] * dimIn[2]
    outputTensorSize = dimOut[0] * dimOut[1] * dimOut[2]
    hiddenTensorSize = dimHidden[0] * dimHidden[1] * dimHidden[2]

    x = seq_len * inputTensorSize * T_ELEM
    y = seq_len * outputTensorSize * T_ELEM
    dx = seq_len * inputTensorSize * T_ELEM
    dy = seq_len * outputTensorSize * T_ELEM
    hx = hiddenTensorSize * T_ELEM
    cx = hiddenTensorSize * T_ELEM
    hy = hiddenTensorSize * T_ELEM
    cy = hiddenTensorSize * T_ELEM
    dhx = hiddenTensorSize * T_ELEM
    dcx = hiddenTensorSize * T_ELEM
    dhy = hiddenTensorSize * T_ELEM
    # cudaErrCheck(cudaMalloc((void **)&dcy, hiddenTensorSize * sizeof(T_ELEM)));
    dcy = hiddenTensorSize * T_ELEM

    sum_mem = weights + x + y + dx + dy + hx + cx + hy + cy + dhx + dcx + dhy + dcy
    return sum_mem / unit
