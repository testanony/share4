from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys
import inspect
import os
import argparse
from z3 import *
import time
import numpy as np
from paleo.device import *
from refty.flops_cost_func import rnn_fwd_FLOPs
from refty.weight_cost_func import rnn_weight
from refty.mem_cost_func import rnn_in_out_cost
from refty.mem_cost_func import rnn_mem
from refty.mem_cost_func import rnn_tensor_cost
from data_type import *

currentdir = os.path.dirname(\
    os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

parser = argparse.ArgumentParser()
parser.add_argument('-ct',
                    '--ctype',
                    type=str,
                    metavar='N',
                    default="",
                    help='')
parser.add_argument('-cs',
                    '--csize',
                    type=str,
                    metavar='N',
                    default="",
                    help='')
parser.add_argument('-seq',
                    '--seqseq',
                    type=int,
                    metavar='N',
                    default=1,
                    help='')
parser.add_argument('-md',
                    '--mode',
                    type=str,
                    metavar='N',
                    default="LSTM",
                    help='')
parser.add_argument('-sl',
                    '--seq_len',
                    type=int,
                    metavar='N',
                    default=128,
                    help='')
parser.add_argument('-bz',
                    '--batch',
                    type=str,
                    metavar='N',
                    default="128,512",
                    help='')
parser.add_argument('-is',
                    '--input_size',
                    type=int,
                    metavar='N',
                    default=1024,
                    help='')
parser.add_argument('-nl',
                    '--num_layers',
                    type=int,
                    metavar='N',
                    default=12,
                    help='')
parser.add_argument('-nd',
                    '--num_directions',
                    type=int,
                    metavar='N',
                    default=1,
                    help='')
parser.add_argument('-hz',
                    '--hidden_size',
                    type=str,
                    metavar='N',
                    default="16,128",
                    help='')
parser.add_argument('-inter',
                    '--interval',
                    type=int,
                    metavar='N',
                    default=50,
                    help='')
parser.add_argument('-filter',
                    '--use_filter',
                    type=int,
                    metavar='N',
                    default=1,
                    help='')

use_int = False
args = parser.parse_args()
constraint_type_list = str(args.ctype).split("-")
constraint_size_list = str(args.csize).split("-")
seqseq = args.seqseq
mode = args.mode

ctx = main_ctx()
batch = init_solver_variable('_batch', ctx)
num_directions = init_solver_variable('_num_directions', ctx)
hidden_size = init_solver_variable('_hidden_size', ctx)
num_layers = init_solver_variable('_num_layers', ctx)
seq_len = init_solver_variable('_seq_len', ctx)
input_size = init_solver_variable('_input_size', ctx)

batch = args.batch.split(",")
num_directions = args.num_directions
hidden_size = args.hidden_size.split(",")
num_layers = args.num_layers
seq_len = args.seq_len
input_size = args.input_size

opt = Optimize()

bz_start = int(batch[0])
bz_end = int(batch[1])
hidden_size_start = int(hidden_size[0])
hidden_size_end = int(hidden_size[1])

hidden_is_option = True
hidden_size = hidden_size_end - hidden_size_start + 1

if hidden_is_option:
    opt.add(_hidden_size >= hidden_size_start)
    opt.add(_hidden_size <= hidden_size_end)
    hidden_size = hidden_size_end - hidden_size_start + 1
else:
    or_clause = [hidden_size == 16, hidden_size == 2048, hidden_size == 5120]
    opt.add(Or(or_clause))
    hidden_size = len(or_clause)

ss_count = (bz_end - bz_start + 1) * (hidden_size)
opt.add(num_directions == 1, num_layers == 12, seq_len == 128,
        input_size == 1024)

if seqseq == 1:
    seq_len *= 2

KB = 1024
MB = 1024 * 1024
GB = 1024 * MB
TB = GB * 1024
PB = TB * 1024
unit = GB

for i in range(len(constraint_type_list)):
    constraint_type = constraint_type_list[i]
    constraint_size = int(constraint_size_list[i])
    if constraint_type == "mem":
        constraint_sym = rnn_mem(mode,
                                 seq_len,
                                 batch,
                                 input_size,
                                 num_layers,
                                 num_directions,
                                 hidden_size,
                                 unit=MB)

        constraint_value = init_solver_variable('constraint_value_mem', ctx)
        sym_value = init_solver_variable('sym_value_mem', ctx)
        opt.add(sym_value == constraint_sym)

        if constraint_type == "mem":
            opt.add(constraint_sym <= constraint_size / MB)
            opt.add(constraint_size / MB == constraint_value)
        else:
            opt.add(constraint_sym >= 0)

    if constraint_type == "weight":
        constraint_sym_weight = rnn_weight(mode,
                                           input_size,
                                           num_layers,
                                           num_directions,
                                           hidden_size,
                                           unit=KB)

        constraint_value_weight = init_solver_variable(
            'constraint_value_weight', ctx)
        sym_value_weight = init_solver_variable('sym_value_weight', ctx)
        opt.add(sym_value_weight == constraint_sym_weight)
        if constraint_type == "weight":
            opt.add(constraint_sym_weight <= _constraint_size / KB)
            opt.add(constraint_size / KB == constraint_value_weight)
        else:
            opt.add(constraint_sym_weight >= 0)

    if constraint_type == "fwd_FLOPs":
        constraint_sym_FLOPs = rnn_fwd_FLOPs(mode,
                                             seq_len,
                                             batch,
                                             input_size,
                                             num_layers,
                                             num_directions,
                                             hidden_size,
                                             unit=GB)

        constraint_value_FLOPs = init_solver_variable('constraint_value_FLOPs',
                                                      ctx)
        sym_value_FLOPs = init_solver_variable('sym_value_FLOPs', ctx)
        opt.add(sym_value_FLOPs == constraint_sym_FLOPs)
        if constraint_type == "fwd_FLOPs":
            opt.add(constraint_sym_FLOPs <= constraint_size)
            opt.add(constraint_size == constraint_value_FLOPs)
        else:
            opt.add(constraint_sym_FLOPs >= 0)

    if constraint_type == "fwd_time":
        print("add forward time constraint {}".format(constraint_size))
        time_unit = 1000 * 1000 * 1000

        #device_type  = "TITAN_X"
        device_type = "P100"  #??
        device = DEVICES[device_type]
        device_FLOPS = device.peek_gflop  #* GB #* 1024 * 1024 * 1024
        device_mem_band = device.mem_bandwidth  #* GB#* 1024 * 1024 * 1024

        flops = rnn_fwd_FLOPs(mode,
                              seq_len,
                              batch,
                              input_size,
                              num_layers,
                              num_directions,
                              hidden_size,
                              unit=1)

        tensor = rnn_tensor_cost(mode, seq_len, batch, input_size, num_layers,
                                 num_directions, hidden_size)
        rw_time = tensor * device_FLOPS
        comp_time = flops * device_mem_band
        constraint_sym_time = (rw_time + comp_time)

        if use_int:
            constraint_value_time = Int('constraint_value_time')
            sym_value_time = Int('sym_value_time')
        else:
            constraint_value_time = init_solver_variable(
                'constraint_value_time', ctx)
            sym_value_time = init_solver_variable('sym_value_time', ctx)
        opt.add(sym_value_time == constraint_sym_time)

        if constraint_type == "fwd_time":
            constraint_fold_size = \
                constraint_size * time_unit * device_mem_band * device_FLOPS
            start = time.time()
            opt.add(constraint_sym_time <= constraint_fold_size)
            opt.add(constraint_size * time_unit == constraint_value_time)
            end = time.time()
            print("add 2 constraints of fwd time {}".format(end - start))
        else:
            opt.add(constraint_sym_time >= 0)

sat_count = 0
opt.push()

interval_split = args.interval
offset = int((bz_end - bz_start) / interval_split)
bz_temp_end = bz_start + offset
bz_temp_start = bz_start

print("bz start {}, bz end {}, offset {}".format(bz_start, bz_end, offset))


def interval_filtering(opt, hyperparam, hyperparam_min, hyperparam_max):
    opt.push()
    opt.add(hyperparam == hyperparam_min)
    sat_flag1 = opt.check()
    if sat_flag1 == sat:
        m = opt.model()
        print("**************")
        for i in m:
            print("{} = {}\n".format(i, m[i]))
        print("**************")
    opt.pop()
    opt.push()
    opt.add(hyperparam == hyperparam_max)
    sat_flag2 = opt.check()
    if sat_flag2 == sat:
        m = opt.model()
        print("**************")
        for i in m:
            print("{} = {}\n".format(i, m[i]))
        print("**************")
    opt.pop()
    print("sat flag 1 {} sat flag 2 {}".format(sat_flag1, sat_flag2))

    if sat_flag1 == sat and sat_flag2 == sat:
        print("all sat start >= {}  end <= {}, sat count {}, ss count {}"\
            .format(hyperparam_min, hyperparam_max, sat_count, ss_count))
        opt.add(hyperparam >= hyperparam_max)
        return True, sat
    elif sat_flag1 == unsat and sat_flag2 == unsat:
        print("all unsat start >= {}  end <= {}, sat count {}, ss count {}"\
            .format(hyperparam_min, hyperparam_max, sat_count, ss_count))
        opt.add(batch >= hyperparam_max)
        return True, unsat
    else:
        return False, None


flag = False
# Begin allsat solve:
while bz_temp_end <= bz_end:
    # interval filtering
    if args.use_filter == 1:
        filter_flag, SAT_flag = \
            interval_filtering(opt = opt, hyperparam = batch, \
                hyperparam_min = bz_temp_start, hyperparam_max = bz_temp_end)

        if filter_flag and SAT_flag == sat:
            sat_count += (bz_temp_end - bz_temp_start + 1) * (hidden_size)
            bz_temp_start = bz_temp_end + 1
            bz_temp_end = bz_temp_start + offset
            if bz_temp_end > bz_end and not flag:
                bz_temp_end = bz_end
                flag = True
            continue
        elif filter_flag and SAT_flag == unsat:
            bz_temp_start = bz_temp_end + 1
            bz_temp_end = bz_temp_start + offset
            if bz_temp_end > bz_end and not flag:
                bz_temp_end = bz_end
                flag = True
            continue

    opt.push()
    opt.add(batch >= bz_temp_start)
    opt.add(batch <= bz_temp_end)
    print("start {} end {}".format(bz_temp_start, bz_temp_end))
    sat_flag = opt.check()
    while sat_flag == sat:
        sat_count += 1
        m = opt.model()
        for i in m:
            print("{} = {}\n".format(i, m[i]))
        opt.add(Not(And([sym() == m[sym] for sym in m.decls()])))
        start = time.time()
        sat_flag = opt.check()
        end = time.time()
        print("return model: {}, \n sat_count {}, solving duration {}, \
            all ss count {}"                            .format(\
        opt.model(), \
        sat_count, \
        end - start,
        ss_count))
    opt.pop()

    bz_temp_start = bz_temp_end + 1
    bz_temp_end = bz_temp_start + offset
    if bz_temp_end > bz_end and not flag:
        bz_temp_end = bz_end
        flag = True


print("constraint_type: {}\nconstraint size: {}\nsearch space ratio {}\n \
    search space count {}\nSAT solutions count {}" \
    .format(\
    constraint_type, \
    constraint_size, \
    float(sat_count / ss_count), \
    ss_count, \
    sat_count))
