from z3 import *
from param import *


def init_solver_variable(name, ctx):
    """
    Initialize varible as configured types

    Args:
        name : variable name
        ctx : context
    """
    if use_bit_vec:
        return BitVec(name, bit_len, ctx)
    else:
        return Int(name, ctx)


def init_solver_variables(names, ctx):
    """
    Batch initialize varibles as configured types

    Args:
        name : variable name
        ctx : context
    """
    if use_bit_vec:
        return BitVecs(names, bit_len, ctx)
    else:
        return Ints(names, ctx)
