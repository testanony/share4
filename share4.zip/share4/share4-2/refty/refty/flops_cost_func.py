"""Code generation of refty solver FLOPs equations
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math
import numpy as np
from z3 import *


# Convolution
def conv2d_fwd_FLOPs(inputs, filters, outputs):
    """
    Returns the Conv2d FLOPs.
    nn.Convolution2D Layers 
    """
    # Mul and add per output pixel: kernel_w x kernel_h x in_channel
    flops = 2 * filters[0] * filters[1] * filters[2]
    # Flops per output map.
    flops *= outputs[1] * outputs[2] * filters[3]
    # Flops across multiple input patches.
    flops *= inputs[0]
    return flops


# Pool
def pool2d_fwd_FLOPs(inputs, kernel, outputs):
    """
    Returns the pool2d FLOPs. 
    nn.Pooling Layers 
    """
    # Per output pixel: kernel_w x kernel_h x in_channel
    flops = 2 * kernel[1] * kernel[2] * inputs[3]
    # Flops per output map.
    flops *= outputs[1] * outputs[2]
    # Flops across multiple input patches.
    flops *= inputs[0]
    return flops


# Activation
def activation_fwd_FLOPs(inputs):
    """
    Returns the activation FLOPs.
    nn.Activations supports: 
    27 ops

    ELU
    Hardshrink
    Hardtanh
    LeakyReLU
    LogSigmoid
    MultiheadAttention
    PReLU
    ReLU
    ReLU6
    RReLU
    SELU
    CELU
    GELU
    Sigmoid
    Softplus
    Softshrink
    Softsign
    Tanh
    Tanhshrink
    Threshold

    Softmin
    Softmax
    Softmax2d
    LogSoftmax
    AdaptiveLogSoftmaxWithLoss

    Ref: https://pytorch.org/docs/stable/nn.html#elu 
    """
    flops = np.prod(inputs)
    return flops


def softmax_fwd_FLOPs(inputs):
    """
    Returns the softmax FLOPs
    nn.softmax
    Ref: https://pytorch.org/docs/stable/nn.html#softmax
    """
    flops = np.prod(inputs)
    return flops


### BatchNorm
def batchnorm2d_fwd_FLOPs(inputs):
    """
    Returns the batchnorm2d FLOPs
    nn.BatchNorm2d
    Ref: https://pytorch.org/docs/stable/nn.html#torch.nn.BatchNorm2d
    """
    flops = np.prod(inputs)
    return flops


### Dropout
def dropout2d_fwd_FLOPs(inputs):
    """Returns the dropout FLOPs
    nn.Dropout2d
    Ref: https://pytorch.org/docs/stable/nn.html#dropout
    """
    flops = np.prod(inputs)
    return flops


# Ref: https://pytorch.org/docs/stable/torch.html#indexing-slicing-joining-mutating-ops
def concate_fwd_FLOPs(inputs_list):
    """
    Returns the concate FLOPs
    nn.concate
    Ref: 
    """
    flops = 0
    return flops


def squeeze_fwd_FLOPs(inputs):
    """
    Returns the squeeze FLOPs
    squeeze
    Ref: https://pytorch.org/docs/stable/torch.html#torch.squeeze
    """
    flops = 0
    return flops


def transpose_fwd_FLOPs(inputs, dim1, dim2):
    """Returns the transpose FLOPs
    transpose
    Ref: https://pytorch.org/docs/stable/torch.html#torch.transpose
    """
    flops = 0
    return flops


def reshape_fwd_FLOPs(inputs, new_shape):
    """
    Returns the reshape FLOPs
    reshape
    Ref: https://pytorch.org/docs/stable/torch.html#torch.squeeze
    """
    flops = 0
    return flops


def unsqueeze_fwd_FLOPs(inputs, dim):
    """
    Returns the unsqueeze FLOPs
    unqueeze
    Ref: https://pytorch.org/docs/stable/torch.html#torch.unsqueeze
    """
    flops = 0
    return flops


### Pointwise Ops
def elementwise_fwd_FLOPs(inputs):
    """
    Returns the elementwise FLOPs
    pointwise
    53 ops
    abs
    acos
    add
    addcdiv
    addcmul
    angle
    asin
    atan
    atan2
    bitwise_not
    bitwise_xor
    ceil
    clamp
    conj
    cos
    cosh
    div
    digamma
    erf
    erfc
    erfinv
    exp
    expm1
    floor
    fmod
    frac
    imag
    lerp
    lgamma
    log
    log10
    log1p
    log2
    logical_not
    logical_xor
    mul
    mvlgamma
    neg
    polygamma
    pow
    real
    reciprocal
    remainder
    round
    rsqrt
    sigmoid
    sign
    sin
    sinh
    sqrt
    tan
    tanh
    trunc

    Ref: https://pytorch.org/docs/stable/torch.html#pointwise-ops
    """
    flops = np.prod(inputs)
    return flops


def add_fwd_FLOPs(inputs):
    """
    Returns the add FLOPs
    add
    Ref: 
    """
    assert len(inputs) == 2
    assert len(inputs[0]) == len(inputs[1])
    flops = np.prod(inputs)
    return flops


### RNN
def rnn_fwd_FLOPs(mode,
                  seq_len,
                  batch,
                  input_size,
                  num_layers,
                  num_directions,
                  hidden_size,
                  unit=1):
    """
    Returns the rnn FLOPs
    3 ops
    RNN
    LSTM
    GRU
    
    Ref: https://pytorch.org/docs/stable/nn.html#torch.nn.RNN 
    """

    # TODO
    #num_mats = 6

    if mode == "LSTM":
        num_mats = 8
    elif mode == "GRU":
        num_mats = 6
    else:
        num_mats = 2

    flops = num_mats * 2 * num_directions * hidden_size * hidden_size \
        * seq_len * batch * num_layers
    return flops / unit
