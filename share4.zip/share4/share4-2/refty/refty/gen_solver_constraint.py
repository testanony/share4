"""Generate Z3 CSP constraint symbols
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import json
import copy
from z3 import *
import numpy as np
from shape_inference import concate_output_shape
from logger import logger
from shape_rules import output_shape_positive_shape_rules
from paleo.device import *
from refty.param import *
from refty.utils import ir_op_set
from init_var_sym import *
import time
from refty.shape_inference import floor_z3
from refty.type.tensor import dataformat_dic, datatype_dic

def construct_resource_constraint(search_space, opt, ctx, layer_list,
                                  sym_layer_list, sym_name_dic):
    """[summary]
    construct the constraints of resource

    Args:
        search_space ([type]): [description]
        opt ([type]): [description]
        ctx ([type]): [description]
        layer_list ([type]): [description]
        sym_layer_list ([type]): [description]
        sym_name_dic ([type]): [description]
    """
    # add search space constraints
    if "constraint" in search_space:
        if "mem" in search_space["constraint"]:
            mem_constraint = search_space["constraint"]["mem"][
                "size"]  # 1024*1024*1024
            mem_whole_symbol_origin = init_solver_variable(
                "memory_symbol {}".format(ctx))

            if len(layer_list) == 1 and layer_list[
                    0].layer_op.layertype in ir_op_set.rnn:
                mem_whole_symbol = sym_name_dic[
                    layer_list[0].layer_op.name]["mem"]
            else:
                mem_whole_symbol = construct_fwd_mem_symbol(
                    sym_layer_list, opt, ctx)

            opt.add(mem_whole_symbol == mem_whole_symbol_origin)
            add_mem_constraint(opt,
                               mem_constraint,
                               mem_whole_symbol,
                               sym=search_space["constraint"]["mem"]["op"])

        if "weight" in search_space["constraint"]:
            weight_constraint = search_space["constraint"]["weight"]["size"]
            weight_whole_symbol_origin = init_solver_variable(
                "weight_symbol {}".format(ctx))

            if len(layer_list) == 1 and layer_list[
                    0].layer_op.layertype in ir_op_set.rnn:
                weight_whole_symbol = sym_name_dic[
                    layer_list[0].layer_op.name]["weight"]
            else:
                weight_whole_symbol = construct_weights_symbol(
                    sym_layer_list, opt, ctx)
            add_weight_constraint(
                opt,
                weight_constraint,
                weight_whole_symbol,
                sym=search_space["constraint"]["weight"]["op"])
            opt.add(weight_whole_symbol == weight_whole_symbol_origin)

        if "fwd_FLOPs" in search_space["constraint"]:
            FLOPs_constraint = search_space["constraint"]["fwd_FLOPs"]["size"]
            FLOPs_whole_symbol_origin = init_solver_variable(
                "fwd_FLOPs_symbol {}".format(ctx))

            if len(layer_list) == 1 and layer_list[
                    0].layer_op.layertype in ir_op_set.rnn:
                FLOPs_whole_symbol = sym_name_dic[
                    layer_list[0].layer_op.name]["fwd_FLOPs"]
            else:
                FLOPs_whole_symbol = \
                    construct_fwd_FLOPs_symbol(sym_layer_list, opt, ctx)
            add_FLOPs_constraint(
                opt,
                FLOPs_constraint,
                FLOPs_whole_symbol,
                sym=search_space["constraint"]["fwd_FLOPs"]["op"])
            opt.add(FLOPs_whole_symbol == FLOPs_whole_symbol_origin)

        if "edge_count" in search_space["constraint"]:
            edge_constraint = search_space["constraint"]["edge_count"]["size"]
            edge_whole_symbol_origin = init_solver_variable(
                "edge_count_symbol {}".format(ctx))
            edge_whole_symbol = construct_edge_count_symbol(
                sym_layer_list, opt, ctx)
            add_edge_constraint(
                opt,
                edge_constraint,
                edge_whole_symbol,
                sym=search_space["constraint"]["edge_count"]["op"])

            opt.add(edge_whole_symbol == edge_whole_symbol_origin)

        if "arithmetic_intensity" in search_space["constraint"]:
            ai_constraint = search_space["constraint"]["arithmetic_intensity"][
                "size"]
            # init_solver_variable("arith_intensity_symbol", ctx)

            ai_whole_symbol = \
                construct_arithmetic_intensity_symbol(sym_layer_list, opt, ctx)

            add_arithmetic_intensity_constraint(
                opt,
                ai_constraint,
                ai_whole_symbol,
                sym=search_space["constraint"]["arithmetic_intensity"]["op"])

            opt.add(ai_whole_symbol == ai_whole_symbol_origin)

        if "fwd_time" in search_space["constraint"]:
            # NOTE user type the ms unit of time.
            time_constraint = search_space["constraint"]["fwd_time"]["size"]
            # device_type = "TITAN_X"
            # init_solver_variable("fwd_time_symbol", ctx)

            if len(layer_list) == 1 and layer_list[
                    0].layer_op.layertype in ir_op_set.rnn:
                time_whole_symbol = sym_name_dic[
                    layer_list[0].layer_op.name]["fwd_time"]
                scale_factor = 1
            else:
                time_whole_symbol, scale_factor = \
                    construct_worst_case_fwd_exec_time_symbol(device_spec=device_spec,
                                                              sym_layer_list=sym_layer_list,
                                                              opt=opt,
                                                              ctx=ctx)

            # note constraint as mili seconds
            add_exec_time_constraint(
                opt,
                time_constraint,
                time_whole_symbol,
                scale_factor,
                sym=search_space["constraint"]["fwd_time"]["op"])

            opt.add(time_whole_symbol /
                    scale_factor == time_whole_symbol_origin)


def parse_monotonic_params(search_space):
    """
    parse hypercube for interval contraction]

    Arguments:
        search_space -- 

    Keyword Arguments:
        degree int -- (default: {5})
    """
    degree = num_parallel_degree
    # first version only evaluate batch size
    if "data" in search_space["layers"] and \
        "tensor" in search_space["layers"]["data"] and \
        "randint" in search_space["layers"]["data"]["tensor"]["_type"]:
        left_param_index = 0
        right_param_index = 1
        batch_size_index = 0
        batch_size_min = \
            search_space["layers"]["data"]["tensor"]["_value"][left_param_index]\
                [batch_size_index]
        batch_size_max = \
            search_space["layers"]["data"]["tensor"]["_value"][right_param_index]\
                [batch_size_index]
        logger.debug("batch_size_min {} batch_size_max {}".format(\
            batch_size_min, \
            batch_size_max))
        assert batch_size_min <= batch_size_max
        interval_degree = batch_size_max - batch_size_min
        parallel_degree = np.min([interval_degree - degree + 1, degree])
        offset = int(interval_degree / (parallel_degree) - 1)
        last_align = interval_degree - (parallel_degree - 1) * (offset + 1)
        batch_splitting_lists = []
        temp_start = batch_size_min
        for i in range(parallel_degree - 1):
            batch_splitting_lists.append([temp_start, temp_start + offset])
            temp_start += offset
        batch_splitting_lists.append([temp_start, temp_start + last_align])
        logger.debug("batch_splitting_lists {}".format(batch_splitting_lists))
        return batch_splitting_lists
    else:
        raise AssertionError("can not parse monotonic batch size param")
    return


def parallel_search_space_analysis(search_space, degree=5):
    """
    Analysis search space to construct parallel sub search spaces
    
    Arguments:
        search_space -- HPO and NAS search spaces. Follow NNI style.
    
    Keyword Arguments:
        degree {int} -- Parallel threads number (default: {10})
    
    Returns:
        [type] -- List of search space
    """
    max_degree = degree
    max_param = {}
    avail_degree = 1
    temp_max = 0

    if "layers" not in search_space:
        return [], None, None, None

    for layer_name in search_space["layers"]:
        for hyperparam in search_space["layers"][layer_name]:
            if hyperparam == "parents":
                continue
            logger.debug("layer_name {} hyperparam{}".format(
                layer_name, hyperparam))

            if search_space["layers"][layer_name][hyperparam]["_type"] \
                == "randint":
                interval = \
                    search_space["layers"][layer_name][hyperparam]["_value"]
                left = interval[0]
                right = interval[1]
                assert_interval(left, right)
                for i in range(len(left)):
                    interval_degree = right[i] - left[i] + 1
                    avail_degree = np.min([interval_degree, max_degree])
                    logger.debug("interval_degree {}, max_degree {}, \
                        avail_degree {}, temp_max {} left {}, right {}" \
                            .format( \
                                interval_degree,
                                max_degree,
                                avail_degree,
                                temp_max,
                                left,
                                right))
                    if avail_degree > temp_max:
                        max_param["layer_name"] = layer_name
                        max_param["hyperparam"] = hyperparam
                        max_param["randint_max_degree_index"] = i
                        max_param["split_type"] = "randint"
                        temp_max = avail_degree  #interval_degree
            elif search_space["layers"][layer_name][hyperparam]["_type"] \
                == "choice":
                if len(\
                    search_space["layers"][layer_name][hyperparam]["_value"]) \
                        > temp_max:
                    temp_max = len(search_space["layers"][layer_name] \
                        [hyperparam]["_value"])
                    max_param["layer_name"] = layer_name
                    max_param["hyperparam"] = hyperparam
                    max_param["split_type"] = "choice"
            else:
                continue
    logger.debug("max_param {}".format(max_param))

    if max_param == {}:
        return [], None, None, None

    #assert max_param != {}

    max_degree = np.min([max_degree, temp_max])

    if max_degree <= 2:
        return [search_space], None, None, None
    elif "split_type" in max_param and max_param["split_type"] == "choice":
        hyperparams = search_space["layers"][max_param["layer_name"]] \
            [max_param["hyperparam"]]["_value"]
        search_spaces_list = []
        for item in hyperparams:
            single_copy = copy.deepcopy(search_space)
            single_copy["layers"][max_param["layer_name"]] \
                [max_param["hyperparam"]]["_value"] = [item]
            search_spaces_list.append(single_copy)

        return search_spaces_list, None, None, None
    elif "split_type" in max_param and max_param["split_type"] == "randint":
        left_param_index = 0
        right_param_index = 1
        splitted_interval_list = []
        splitted_interval_info = max_param
        interval = search_space["layers"][max_param["layer_name"]] \
            [max_param["hyperparam"]]["_value"]
        left = interval[left_param_index]
        right = interval[right_param_index]
        randint_max_degree_index = max_param["randint_max_degree_index"]
        assert right[randint_max_degree_index] >= left[randint_max_degree_index]
        interval_degree = right[randint_max_degree_index] \
            - left[randint_max_degree_index]
        search_spaces_list = []
        start_value = search_space["layers"][max_param["layer_name"]] \
            [max_param["hyperparam"]]["_value"][left_param_index]\
                [randint_max_degree_index]
        end_value = search_space["layers"][max_param["layer_name"]] \
            [max_param["hyperparam"]]["_value"][right_param_index]\
                [randint_max_degree_index]
        logger.debug("start value {}, end value {}".format(
            start_value, end_value))

        parallel_degree = np.min([interval_degree - degree + 1, degree])

        if parallel_degree <= 1:
            return [search_space], None, None, None

        offset = int(interval_degree / (parallel_degree) - 1)
        last_align = interval_degree - (parallel_degree - 1) * (offset + 1)

        for i in range(parallel_degree):
            single_copy = copy.deepcopy(search_space)
            logger.debug("start value {}, randint_max_degree_index {}" \
                .format(start_value, randint_max_degree_index))
            single_copy["layers"][max_param["layer_name"]]\
                [max_param["hyperparam"]]["_value"][left_param_index] \
                [randint_max_degree_index] = int(start_value)

            if i >= parallel_degree - 1:
                temp_end = int(start_value + last_align)
                assert temp_end <= end_value
                single_copy["layers"][max_param["layer_name"]]\
                    [max_param["hyperparam"]]["_value"][right_param_index] \
                    [randint_max_degree_index] = int(temp_end)
                search_spaces_list.append(single_copy)
                logger.debug("len(search_spaces_list) {}, start_value {}, \
                    temp_end {}, offset {}, last_algin {}" \
                    .format( \
                        len(search_spaces_list),
                        start_value,
                        temp_end,
                        offset,
                        last_align))
                break
            else:
                temp_end = int(start_value + offset)
                logger.debug("temp_end {} end_value {} i {} \
                    parallel degree {} offset {} int".format(
                    temp_end, end_value, i, parallel_degree, offset))
                assert temp_end <= end_value
                single_copy["layers"][max_param["layer_name"]]\
                    [max_param["hyperparam"]]["_value"][right_param_index] \
                    [randint_max_degree_index] = int(temp_end)
                search_spaces_list.append(single_copy)
                logger.debug("len(search_spaces_list) {}, start_value {}, \
                    temp_end {}, offset {}, last_algin {}" \
                        .format( \
                            len(search_spaces_list),
                            start_value,
                            temp_end,
                            offset,
                            last_align))
            start_value = temp_end + 1
        start_init = search_space["layers"][max_param["layer_name"]] \
            [max_param["hyperparam"]]["_value"][left_param_index] \
                [randint_max_degree_index]
        splitted_interval_list = [start_init, end_value]
        split_meta = {"parallel_degree": parallel_degree, \
            "offset": offset, \
            "last_align": last_align}
        return  search_spaces_list, \
                splitted_interval_list, \
                splitted_interval_info, \
                split_meta
    else:
        raise AssertionError("Parallel search space error")
    return


def read_search_space_file(path="nets/refty_test/search_space.json"):
    """
    Read search space and construct json dic
    
    Keyword Arguments:
        path {str} -- path (default: {"nets/refty_test/search_space.json"})
    
    Returns:
        search space dic
    """
    try:
        with open(path) as f:
            search_space = json.load(f)
            return search_space
    except:
        return {}


# construct forward memory symbol
def construct_fwd_mem_symbol(sym_layer_list, opt, ctx):
    """
    Construct memory symbols
    
    Arguments:
        sym_layer_list -- Layer's hyperparameter symbols
    
    Returns:
        Memory z3 symbols
    """
    mem_whole_symbol = 0
    FLOAT32 = 4

    # simple use forward outputs
    index = 0
    inplace = ["elementwise", "innerproduct", "generic_BatchNorm"]
    for sym_layer in sym_layer_list:
        type_name = sym_layer["type"]

        if type_name in inplace:
            logger.debug("inplace op type_name {}".format(type_name))
            continue

        if type_name in ir_op_set.rnn:
            mem_whole_symbol += sym_layer["mem"]
        else:
            layer_outputs = init_solver_variable("layer_{}_{}_output" \
                .format(sym_layer["name"], index), ctx)

            outputs = sym_layer["outputs"]
            mem_whole_symbol += np.prod(outputs)
            index += 1
            opt.add(layer_outputs == np.prod(outputs))
    mem_whole_symbol *= FLOAT32
    return mem_whole_symbol


def construct_weights_symbol(sym_layer_list, opt, ctx):
    """
    Construct weights symbols
    
    Arguments:
        sym_layer_list -- Layer's hyperparameter symbols
    
    Returns:
        Memory z3 symbols
    """
    weight_whole_symbol = 0
    FLOAT32 = 4

    # simple use forward outputs
    index = 0
    for sym_layer in sym_layer_list:
        layer_weights = init_solver_variable("layer_{}_{}_weight" \
            .format(sym_layer["name"], index), ctx)
        weights = 0
        bias = 0

        if "weights" in sym_layer:
            weights = sym_layer["weights"]
            weight_whole_symbol += np.prod(weights)
            opt.add(layer_weights == np.prod(weights))

        # if "bias" in sym_layer:
        #     bias = sym_layer["weights"]
        #     weight_whole_symbol += np.prod(bias)

        index += 1

    weight_whole_symbol *= FLOAT32
    return weight_whole_symbol


# construct forward FLOPs symbol
def construct_fwd_FLOPs_symbol(sym_layer_list, opt, ctx):
    """
    Construct forward FLOPs symbols
    
    Arguments:
        sym_layer_list -- Layer's hyperparameter symbols
    
    Returns:
        Memory z3 symbols
    """
    fwd_FLOPs_whole_symbol = 0
    index = 0
    # simple use forward outputs
    for sym_layer in sym_layer_list:
        if "fwd_FLOPs" in sym_layer:

            layer_FLOPs = init_solver_variable("layer_{}_{}_FLOPs" \
                .format(sym_layer["name"], index), ctx)

            FLOPs = sym_layer["fwd_FLOPs"]
            fwd_FLOPs_whole_symbol += FLOPs

            opt.add(layer_FLOPs == FLOPs)
        index += 1
    return fwd_FLOPs_whole_symbol


def construct_edge_count_symbol(sym_layer_list, opt, ctx):
    """
    Construct edge count symbols
    
    Arguments:
        sym_layer_list -- Layer's hyperparameter symbols
    
    Returns:
        Memory z3 symbols
    """
    edge_count_symbol = 0

    for sym_layer in sym_layer_list:
        if "edges" in sym_layer:
            e = sym_layer["edges"]
            e_c = sym_layer["edge_counts"]
            for i in range(0, len(e)):
                logger.debug("edges {}, edge_counts {}".format(e, e_c))
                edge_count_symbol += e[i] * e_c[i]
                temp_cond = np.sum(e)
                opt.add(temp_cond <= 1)

    return edge_count_symbol


def construct_arithmetic_intensity_symbol(sym_layer_list, opt, ctx):
    """
    add arithemetc_intensity of roofline model

    Arguments:
        sym_layer_list -- 
        opt -- 
        ctx -- 
    """
    mem = construct_fwd_mem_symbol(sym_layer_list, opt, ctx)
    flops = construct_fwd_FLOPs_symbol(sym_layer_list, opt, ctx)
    return flops / mem


def construct_worst_case_fwd_exec_time_symbol(device_spec, sym_layer_list, opt,
                                              ctx):
    """
    add time estimation symbols

    Arguments:
        sym_layer_list -- 
        opt -- 
        ctx -- 
    """
    scale_factor = 1000 * 1000
    # ms us ns
    device = device_spec
    device_FLOPS = device.peek_gflop  #* 1024 * 1024 * 1024
    device_mem_band = device.mem_bandwidth  #* 1024 * 1024 * 1024
    fwd_FLOPs_time_whole_symbol = 0
    fwd_rw_time_whole_symbol = 0
    index = 0
    # simple use forward outputs
    for sym_layer in sym_layer_list:
        if "fwd_FLOPs" in sym_layer:

            layer_FLOPs_time = init_solver_variable("layer_{}_{}_FLOPs_time" \
                .format(sym_layer["name"], index), ctx)
            layer_input_r_time = init_solver_variable("layer_{}_{}_input_r_time" \
                .format(sym_layer["name"], index), ctx)
            layer_output_w_time = init_solver_variable("layer_{}_{}_output_w_time" \
                .format(sym_layer["name"], index), ctx)

            # layer_FLOPs_time = Real("layer_{}_{}_FLOPs_time" \
            #         .format(sym_layer["name"], index), ctx)
            # layer_input_r_time = Real("layer_{}_{}_input_r_time" \
            #     .format(sym_layer["name"], index), ctx)
            # layer_output_w_time = Real("layer_{}_{}_output_w_time" \
            #     .format(sym_layer["name"], index), ctx)

            FLOPs = sym_layer["fwd_FLOPs"]
            inputs = sym_layer["inputs"]
            outputs = sym_layer["outputs"]
            in_t = 1

            for i in inputs:
                in_t *= i

            out_t = 1

            for o in outputs:
                out_t *= o

            # should recover (this will avoid use real)
            opt.add(layer_input_r_time == \
                (in_t))
            opt.add(layer_FLOPs_time == (FLOPs))
            opt.add(layer_output_w_time == \
                (out_t))
            fwd_rw_time_whole_symbol += layer_input_r_time
            fwd_FLOPs_time_whole_symbol += layer_FLOPs_time
            fwd_rw_time_whole_symbol += layer_output_w_time

        index += 1
    return fwd_FLOPs_time_whole_symbol / (device_FLOPS) + \
        fwd_rw_time_whole_symbol / (device_mem_band), scale_factor


def gen_1to1_child_input_parent_output_shape_constraint(child_op_symbol, parent_op_symbol, opt, ctx):
    """
    Construct operator parent output and child input shape constraints
    
    Arguments:
        child_op_symbol -- Child operator symbols
        parent_op_symbol -- Parent operator symbols
        opt -- Z3 optimizer
    """
    child_inputs = child_op_symbol["inputs"]
    parent_outputs = []

    #if isinstance(parent_op_symbol, list) and len(parent_op_symbol) > 1:
    for item in parent_op_symbol:
        parent = []

        for item_sub in item:
            logger.debug("parent_op_symbol {}".format(parent_op_symbol))
            parent.append(item_sub["outputs"])

        parent_outputs.append(parent)

    logger.debug("parent_op_symbol {} \n child_op_symbol \n {}".format(
        parent_op_symbol, child_op_symbol))
    index = 0

    parents_count_array = []
    use_edge_constraint = True

    if (child_op_symbol["type"] == "matmul"):
        for parent in parent_outputs_array:
            o_i = 0
            logger.debug(
                "parent_outputs_array".format(parent_outputs_array))
            logger.debug("parent_outputs {}".format(parent))
            logger.debug("-------")
            # add matmul constraints
            opt.add(parent[0][2] == parent[1][1])
            opt.add(child_inputs[1] == parent[0][1])
            opt.add(child_inputs[2] == parent[1][2])

    if (child_op_symbol["type"] == "concat" or \
            child_op_symbol["type"] == "elementwise"):
        # logger.debug("child_op_symbol {}".format(child_op_symbol))
        parents_cond_list = []
        parent_outputs_array = parent_outputs
        # logger.debug("parent output array: ", parent_outputs_array)
        for parent in parent_outputs_array:
            cond_list = []
            if child_op_symbol["type"] == "concat":
                dim = child_op_symbol["dim"]
                logger.debug("concat dim: {} ".format(dim))
                # shape infer for concat
                # logger.debug("parent_outputs {}".format(parent))
                logger.debug("parent_outputs {}".format(parent))
                # add concat hw equal rule
                parent0 = parent[0]
                index = 0
                for parent_j in parent:
                    if index == 0:
                        index+= 1
                        continue
                    else:
                        index += 1
                    opt.add(parent0[0] == parent_j[0])  
                    opt.add(parent0[1] == parent_j[1])  
                    opt.add(parent0[2] == parent_j[2])  
                
                parents_outputs_concat = concate_output_shape(\
                    inputs_list = parent, dim = dim)
                logger.debug("parent output concat: {} ".format(parents_outputs_concat))
                logger.debug("-----------")
                parents_count_array.append(len(parent))

                o_i = 0

                for parent_j in parents_outputs_concat:
                    #if o_i != dim: # avoid concat dim ==
                    cond_list.append(child_inputs[o_i] == parent_j)
                    o_i += 1
                #opt.add(And(cond_list, ctx))
            elif child_op_symbol["type"] == "elementwise":
                o_i = 0
                logger.debug(
                    "parent_outputs_array".format(parent_outputs_array))
                logger.debug("parent_outputs {}".format(parent))
                logger.debug("-------")
                parent_num = len(parent)
                parents_count_array.append(len(parent))

                for parent_j in parent[0]:
                    cond_list.append(
                        child_inputs[o_i] == parent_j)  # peak first
                    o_i += 1

            else:
                raise AssertionError("multi parents search space only support \
                    concat and elementwise")

            # mark this parents choice is selected. For multi edge choice NAS
            if use_edge_constraint:
                #cond_list.append(child_op_symbol["edges"][index] == 1)
                logger.debug("cond_list".format(cond_list))
                parents_cond_list.append(And(cond_list, ctx))
            index += 1
        if use_edge_constraint:
            opt.add(And(parents_cond_list, ctx))
    elif len(parent_op_symbol) > 1:
        raise AssertionError("multi parents search space only support \
                concat and elementwise")
    else:
        logger.debug("in else gen_solver_constraint.py")
        logger.debug("child symbol type: {} ".format(child_op_symbol["type"]))
        cond_list = []
        parents_count_array.append(len(parent_outputs[0]))
        parent_outputs_array = parent_outputs[0][0]
        # logger.debug("parent_outputs_array {}".format(parent_outputs_array))
        # logger.debug("child_inputs {}".format(child_inputs))
        logger.debug("parent_outputs_array len({}) {} \n child_inputs len({}) {}"\
            .format(len(parent_outputs_array), parent_outputs_array, len(child_inputs), child_inputs))
        for i in range(len(parent_outputs_array)):
            logger.debug("child_inputs[i] {} == parent_outputs_array[i] {}".format(child_inputs[i], parent_outputs_array[i]))
            opt.add(child_inputs[i] == parent_outputs_array[i])
        #opt.add(And(cond_list, ctx))
        # mark this parents choice is selected
        if use_edge_constraint:
            if "edges" in child_op_symbol and index <= len(
                    child_op_symbol["edges"]) - 1:
                cond_list.append(child_op_symbol["edges"][index] == 1)
                opt.add(And(cond_list, ctx))

    # make all the input and output >= 0
    # to avoid conv2d valid padding to occur less zero shape
    # for parent_out in parent_outputs:
    #     for parent_dim in parent:
    #         for dim in parent_dim:
    #             opt.add(dim >= 0)
    output_shape_positive_shape_rules(opt, parent_outputs)
    #output_shape_positive_shape_rules(opt, [[child_inputs]])

    if refty_use_dataformat_datatype_rule:
        #if "dataformat" in params:
        if child_op_symbol["contains_dataformat_rule"]:
            gen_dataformat_dependency_constraints(child_op_symbol, parent_op_symbol, opt, ctx)
        #if "datatype" in params:
        if child_op_symbol["contains_datatype_rule"]:
            gen_datatype_dependency_constraints(child_op_symbol, parent_op_symbol, opt, ctx)

    return parents_count_array


def gen_op_parents_symbol(sym_name_dic, layer, search_space):
    parents_all_list = []
    if "layers" in search_space and (layer.name in search_space["layers"] and \
        "parents" in search_space["layers"][layer.name]):

        assert search_space["layers"][layer.name]["parents"]["_type"] == \
            "choice"
        index = 0

        for parents in search_space["layers"][layer.name]["parents"]["_value"]:
            parent_array = []
            logger.debug("parents {}".format(parents))
            for p in parents:
                parent_sym = sym_name_dic[p]
                parent_array.append(parent_sym)
                logger.debug("parent_array {}".format(parent_array))
            parents_all_list.append(parent_array)
            logger.debug("parents_all_list {}".format(parents_all_list))
    else:
        logger.debug("layer.parents {}".format(layer.parents))
        parent_array = []

        for parent_name in layer.parents:
            parent_sym = sym_name_dic[parent_name]
            parent_array.append(parent_sym)

        parents_all_list.append(parent_array)
        logger.debug("parents_all_list {}".format(parents_all_list))
    return parents_all_list


def gen_op_edge_constraints(op_symbol_dic, layer_spec, search_space, opt, ctx):
    layer = layer_spec.layer_op
    op_symbol_dic["edges"] = []

    if "layers" in search_space and (layer.name in search_space["layers"] and \
        "parents" in search_space["layers"][layer.name]):

        assert search_space["layers"][layer.name]["parents"]["_type"] \
            == "choice"
        index = 0

        for parent in search_space["layers"][layer.name]["parents"]["_value"]:
            edge = \
                init_solver_variable("{}_edge_{}".format(layer.name, index), ctx)
            logger.debug("edge for gen_op_dege_constraint: {}".format(edge))
            op_symbol_dic["edges"].append(edge)
            opt.add(
                Or([
                    op_symbol_dic["edges"][index] == 1,
                    op_symbol_dic["edges"][index] == 0
                ], ctx))
            index += 1

        sum_edge = 0

        for e in op_symbol_dic["edges"]:
            sum_edge += e

        logger.debug("search_space[layers] {} \n op_symbol_dic {}".format(
            search_space["layers"], op_symbol_dic))

        opt.add(sum_edge == 1)  # Only use 1 edges
    else:
        edge_0 = init_solver_variable("{}_edge_0".format(layer.name), ctx)
        logger.debug("edge 0: {} ".format(edge_0))
        #op_symbol_dic["edges"].append(edge_0)
        #opt.add(op_symbol_dic["edges"][0] == 1)  # use this edge
    return op_symbol_dic


def gen_batchnorm_op_constraint(op_symbol_dic, layer_spec, search_space, opt,
                                ctx):
    """
    Generate input operator constraint
    
    Arguments:
        op_symbol_dic -- Operator Z3 symbols
        layer_spec -- Layer specification
        search_space -- Search space
        opt -- Z3 optimizer
    """
    logger.debug("gen_batchnorm_op_constraint")
    return


def gen_elementwise_op_constraint(op_symbol_dic, layer_spec, search_space, opt,
                                  ctx):
    """
    Generate input operator constraint
    
    Arguments:
        op_symbol_dic -- Operator Z3 symbols
        layer_spec -- Layer specification
        search_space -- Search space
        opt -- Z3 optimizer
    """
    logger.debug("gen_elementwise_op_constraint")
    return


def gen_softmax_op_constraint(op_symbol_dic, layer_spec, search_space, opt,
                              ctx):
    """
    Generate softmax operator constraint
    
    Arguments:
        op_symbol_dic -- Operator Z3 symbols
        layer_spec -- Layer specification
        search_space -- Search space
        opt -- Z3 optimizer
    """
    return


def gen_dropout_op_constraint(op_symbol_dic, layer_spec, search_space, opt,
                              ctx):
    """
    Generate softmax operator constraint
    
    Arguments:
        op_symbol_dic -- Operator Z3 symbols
        layer_spec -- Layer specification
        search_space -- Search space
        opt -- Z3 optimizer
    """
    return

hyperparam_valid_range_dic = {
    "tensor": 1,
    "filter": 1, 
    "strides": 1, 
    "num_classes": 1, 
    "batch": 1, 
    "input_size": 1, 
    "seq_len": 1, 
    "num_layers": 1, 
    "num_directions": 1, 
    "hidden_size": 1, 
    "output_dim": 1, 
}

def gen_symbol_constraints(sym_name, symbol, spec, layer, search_space, opt,
                           ctx):
    if not isinstance(spec, list):
        spec = [spec]
    if not isinstance(symbol, list):
        symbol = [symbol]
    if "layers" in search_space and layer.name in search_space["layers"] and \
        sym_name in search_space["layers"][layer.name]:
        if search_space["layers"][layer.name][sym_name]["_type"] == "randint":
            interval = search_space["layers"][layer.name][sym_name]["_value"]
            interval_lower = interval[0]
            interval_upper = interval[1]
            logger.debug("assert symname {} interval {} search space {}".format(\
                sym_name,
                interval,
                search_space))
            assert_interval(interval_lower, interval_upper)
            cons_list = []
            for i in range(len(symbol)):
                if interval_lower[i] == interval_upper[i]:
                    cons_list.append(symbol[i] == interval_lower[i])
                else:
                    cons_list.append(And([symbol[i] >= interval_lower[i], \
                        symbol[i] <= interval_upper[i]], ctx))
            if use_constraint_merge:
                opt.add(And(cons_list, ctx))
            else:
                for con in cons_list:
                    opt.add(cons_list)
        elif search_space["layers"][layer.name][sym_name]["_type"] == "choice":
            logger.debug(" in gen constraint choice: {}".format(layer.name))
            choices = search_space["layers"][layer.name][sym_name]["_value"]
            logger.debug("choices: {}".format(choices))
            cons_list_all = []
            for choice in range(len(choices)):
                cons_list = []
                for i in range(len(symbol)):
                    cons_list.append(symbol[i] == choices[choice][i])
                cons_list_all.append(And(cons_list, ctx))

            opt.add(Or(cons_list_all, ctx))
        else:
            raise AssertionError("filters type should be choice or randint")
    else:
        if "layers" in search_space:
            logger.debug("symbol: {} layer name {}, sym name {}, search space[layers] {}"\
                .format(symbol, layer.name, sym_name, search_space["layers"]))
        if use_constraint_merge:
            cons = []
            for i in range(len(symbol)):
                # skip batch size
                # if i == 0 :
                #     continue
                cons.append(symbol[i] == spec[i])
            opt.add(And(cons, ctx))
        else:
            for i in range(len(symbol)):
                # skip batch size
                # if i == 0 :
                #    continue
                opt.add(symbol[i] == spec[i])
    
    # Add constraint of all the hyperparameters >= 1
    if sym_name in hyperparam_valid_range_dic:
        for i in range(len(symbol)):
            opt.add(symbol[i] >= hyperparam_valid_range_dic[sym_name])
    return


def gen_input_op_constraint(op_symbol_dic, layer_spec, search_space, opt, ctx):
    """
    Generate nochange operator constraint
    
    Arguments:
        op_symbol_dic -- Operator Z3 symbols
        layer_spec -- Layer specification
        search_space -- Search space
        opt -- Z3 optimizer
    """
    layer = layer_spec
    inputs = layer.inputs
    sym_inputs = op_symbol_dic["inputs"]

    # for i in range(len(sym_inputs)):
    #     opt.add(sym_inputs[i] == inputs[i])

    logger.debug("op_symbol_dic {}, inputs {}".format(op_symbol_dic, inputs))
    logger.debug("in generate input op constraint")
    gen_symbol_constraints(sym_name="tensor",
                           symbol=sym_inputs,
                           spec=layer.inputs,
                           layer=layer,
                           search_space=search_space,
                           opt=opt,
                           ctx=ctx)
    return


def assert_choices(hyper_list):
    index = 0
    for i in range(len(hyper_list) - 1):
        assert (hyper_list[i] <= hyper_list[i + 1])
    return


def assert_interval(left, right):
    """
    Generate interval of hyper cube
    
    Arguments:
        left -- lower value of hyperparam
        right -- upper value of hyperparam
    """
    assert len(left) == len(right)
    length = len(left)

    for i in range(length):
        logger.debug("i th {} left {} right {}".format(i, left, right))
        assert left[i] <= right[i]
    return

def gen_reshape_constraint(op_symbol_dic, layer_spec, search_space, opt,
                             ctx):
    logger.debug("op_symbol_dic {}".format(op_symbol_dic))
    layer = layer_spec.layer_op
    output_shape = layer.outputs
    sym_inputs   = op_symbol_dic["inputs"]
    sym_outputs  = op_symbol_dic["outputs"]
    if output_shape[1] == 1:
        opt.add(sym_inputs[0] == sym_outputs[0])
        opt.add(sym_outputs[1] == 1)
        opt.add(sym_outputs[2] == 1)
        opt.add(sym_outputs[3] == sym_inputs[1] * sym_inputs[2] * sym_inputs[3])
    else:
        opt.add(sym_inputs[0] == sym_outputs[0])
        opt.add(sym_outputs[1] == sym_inputs[1])
        opt.add(sym_outputs[2] == sym_inputs[2])
        opt.add(sym_outputs[3] == output_shape[-1])

def gen_conv2d_op_constraint(op_symbol_dic, layer_spec, search_space, opt,
                             ctx):
    """
    Generate conv2d constraints
    
    Arguments:
        op_symbol_dic -- operator symbols
        layer_spec -- layer specification
        search_space -- search spaces
        opt -- Z3 optimizer
        ctx -- Z3 context
    """    
    # logger.debug("op_symbol_dic {}".format(op_symbol_dic))
    init_start = time.time()
    layer = layer_spec.layer_op
    filters = layer.filters
    strides = layer.strides
    padding = layer.padding
    sym_filters = op_symbol_dic["filters"]
    # init_end = time.time()
    # filter_start = time.time()
    gen_symbol_constraints(sym_name="filter",
                           symbol=sym_filters,
                           spec=filters,
                           layer=layer,
                           search_space=search_space,
                           opt=opt,
                           ctx=ctx)
    # filter_end = time.time()
    # stride_start = time.time()
    sym_strides = op_symbol_dic["strides"]

    gen_symbol_constraints(sym_name="strides",
                           symbol=sym_strides,
                           spec=strides,
                           layer=layer,
                           search_space=search_space,
                           opt=opt,
                           ctx=ctx)
    # stride_end = time.time()
    # pad_start = time.time()
    sym_padding = op_symbol_dic["padding"]

    if "layers" in search_space and (layer.name in search_space["layers"] and \
        "padding" in search_space["layers"][layer.name]):
        if search_space["layers"][layer.name]["padding"]["_type"] == "choice":
            choices = search_space["layers"][layer.name]["padding"]["_value"]
            cons_list_all = []
            for choice in range(len(choices)):
                cons_list = []
                if choice == "VALID" or choice == "SAME":
                    cons_list.append(sym_padding[0] == 1)
                    cons_list.append(sym_padding[1] == 0)
                else:
                    real_padding = [padding[1], padding[2], padding[5], padding[6]]
                    for i in range(len(real_padding)):
                        cons_list.append(sym_padding[i] == real_padding[i])
                cons_list_all.append(And(cons_list, ctx))
            opt.add(Or(cons_list_all, ctx))
        else:  # choice
            raise AssertionError("padding search space should be choice")
    else:
        padding_conv_pool(padding, op_symbol_dic, sym_filters, sym_strides, sym_padding, opt, ctx)
    return

def padding_conv_pool(padding, op_symbol_dic, sym_filters, sym_strides, sym_padding, opt, ctx):
    logger.debug("padding {}".format(padding))
    cons_list = []
    if padding == "SAME":
        inputs  = op_symbol_dic["inputs"]
        # def floor_z3(a, b):
        #     return (2*a - b) / (2*b)
        # TF / stride, and Pytorch not / stride
        h = floor_z3(a = inputs[1], b = sym_strides[1])
        w = floor_z3(a = inputs[2], b = sym_strides[2])
        op_symbol_dic["outputs"] = [inputs[0], h, w, op_symbol_dic["filters"][3]]# batch size
    elif padding == "VALID":
        sym_inputs = op_symbol_dic["inputs"]
        opt.add(sym_inputs[1] >= sym_filters[0])
        opt.add(sym_inputs[2] >= sym_filters[1])
        # ValueError: Dimensions must be equal, but are 64 and 32 for 'Conv2D_1' (op: 'Conv2D') with input shapes: [?,7,8,64], [33,33,32,64].
        opt.add(sym_inputs[3] == sym_filters[2])

        # for item in op_symbol_dic["outputs"]:
        #    opt.add(item >= 0) 

        for i in range(len(sym_padding)):
            cons_list.append(sym_padding[i] == 0)
    else:
        real_padding = [padding[1], padding[2], padding[5], padding[6]]
        sym_inputs = op_symbol_dic["inputs"]
        opt.add(sym_inputs[1] >= sym_filters[0])
        opt.add(sym_inputs[2] >= sym_filters[1])
        # ValueError: Dimensions must be equal, but are 64 and 32 for 'Conv2D_1' (op: 'Conv2D') with input shapes: [?,7,8,64], [33,33,32,64].
        opt.add(sym_inputs[3] == sym_filters[2]) 
        
        # for item in op_symbol_dic["outputs"]:
        #    opt.add(item >= 0) 

        for i in range(len(real_padding)):
            cons_list.append(sym_padding[i] == real_padding[i])
    if len(cons_list) != 0:
        opt.add(And(cons_list, ctx))


def gen_rnn_op_constraint(op_symbol_dic, seq_len, batch_size, layer_spec, search_space, opt, ctx):
    """
    Generate rnn constraints
    
    Arguments:
        op_symbol_dic -- operator symbols
        layer_spec -- layer specification
        search_space -- search spaces
        opt -- Z3 optimizer
        ctx -- Z3 context
    """

    try:
        logger.debug("op_symbol_dic {}".format(op_symbol_dic))
        layer = layer_spec
        num_embeddings = layer.num_embeddings
        embedding_dim = layer.embedding_dim
        n_layers = layer.n_layers
        num_directions = [1]
        hidden_dim = layer.hidden_dim
        sym_seq_len        = op_symbol_dic["seq_len"]
        sym_batch          = op_symbol_dic["batch"]
        sym_num_embeddings = op_symbol_dic["num_embeddings"]
        sym_n_layers       = op_symbol_dic["n_layers"]
        sym_num_directions = op_symbol_dic["num_directions"]
        sym_hidden_dim     = op_symbol_dic["hidden_dim"]
        
        logger.debug("for seq len")
        gen_symbol_constraints(sym_name="seq_len",
                               symbol=sym_seq_len,
                               spec=seq_len,
                               layer=layer,
                               search_space=search_space,
                               opt=opt,
                               ctx=ctx)
        logger.debug("for batch")
        gen_symbol_constraints(sym_name="batch",
                               symbol=sym_batch,
                               spec=batch_size,
                               layer=layer,
                               search_space=search_space,
                               opt=opt,
                               ctx=ctx)
        logger.debug("for num_embeddings")
        gen_symbol_constraints(sym_name="num_embeddings",
                               symbol=sym_num_embeddings,
                               spec=num_embeddings,
                               layer=layer,
                               search_space=search_space,
                               opt=opt,
                               ctx=ctx)
        logger.debug("for n_layers")
        gen_symbol_constraints(sym_name="n_layers",
                               symbol=sym_n_layers,
                               spec=n_layers,
                               layer=layer,
                               search_space=search_space,
                               opt=opt,
                               ctx=ctx)
        logger.debug("for num_directions")
        gen_symbol_constraints(sym_name="num_directions",
                               symbol=sym_num_directions,
                               spec=num_directions,
                               layer=layer,
                               search_space=search_space,
                               opt=opt,
                               ctx=ctx)

        gen_symbol_constraints(sym_name="hidden_dim",
                               symbol=sym_hidden_dim,
                               spec=hidden_dim,
                               layer=layer,
                               search_space=search_space,
                               opt=opt,
                               ctx=ctx)
    except Exception as e:
        raise AssertionError("{}".format(e))
    return


def gen_pool2d_op_constraint(op_symbol_dic, layer_spec, search_space, opt,
                             ctx):
    """
    Generate pool2d constraints
    
    Arguments:
        op_symbol_dic -- operator symbols
        layer_spec -- layer specification
        search_space -- search spaces
        opt -- Z3 optimizer
        ctx -- Z3 context
    """
    #logger.debug("pooling op_symbol_dic {}".format(op_symbol_dic))
    layer = layer_spec.layer_op
    strides = layer.strides
    padding = layer.padding
    filters = layer.kernel
    sym_filters = op_symbol_dic["kernel"]

    gen_symbol_constraints(sym_name="ksize",
                           symbol=sym_filters,
                           spec=filters,
                           layer=layer,
                           search_space=search_space,
                           opt=opt,
                           ctx=ctx)
    
    # if not "strides" in op_symbol_dic:
    sym_strides = op_symbol_dic["strides"]

    gen_symbol_constraints(sym_name="strides",
                           symbol=sym_strides,
                           spec=strides,
                           layer=layer,
                           search_space=search_space,
                           opt=opt,
                           ctx=ctx)

    sym_padding = op_symbol_dic["padding"]

    if "layers" in search_space and (layer.name in search_space["layers"] and \
        "padding" in search_space["layers"][layer.name]):
        if search_space["layers"][layer.name]["padding"]["_type"] == "choice":
            choices = search_space["layers"][layer.name]["padding"]["_value"]
            cons_list_all = []

            for choice in range(len(choices)):
                cons_list = []
                if choice == "VALID":
                    cons_list.append(sym_padding[0] == 1)
                    cons_list.append(sym_padding[1] == 0)
                else:
                    cons_list.append(sym_padding[0] == 0)
                    cons_list.append(sym_padding[1] == 1)
                cons_list_all.append(And(cons_list, ctx))
            opt.add(Or(cons_list_all, ctx))
        else:
            raise AssertionError("padding search space should be choice")
    else:
        logger.debug("enter pool padding")
        cons_list = []
        if padding == "SAME":
            inputs  = op_symbol_dic["inputs"]
            # TF / stride, and Pytorch not / stride
            h = floor_z3(a = inputs[1], b = sym_strides[1])
            w = floor_z3(a = inputs[2], b = sym_strides[2])
            op_symbol_dic["outputs"] = [inputs[0], h, w, op_symbol_dic["filters"][3]]# batch size
        elif padding == "VALID":
            sym_inputs = op_symbol_dic["inputs"]
            opt.add(sym_inputs[1] >= sym_filters[0])
            opt.add(sym_inputs[2] >= sym_filters[1])
            for i in range(len(sym_padding)):
                cons_list.append(sym_padding[i] == 0)
        else:
            real_padding = [padding[1], padding[2], padding[5], padding[6]]
            sym_inputs = op_symbol_dic["inputs"]
            opt.add(sym_inputs[1] >= sym_filters[0])
            opt.add(sym_inputs[2] >= sym_filters[1])
            for i in range(len(real_padding)):
                cons_list.append(sym_padding[i] == real_padding[i])
        opt.add(And(cons_list, ctx))
    return


def add_mem_constraint(opt,
                       mem_constraint,
                       mem_whole_symbol,
                       sym="lt",
                       simplify_c=True):
    """
    Construct memory related constrant
    TODO: try simplify and tatic
    Arguments:
        opt -- [Z3 optimizer]
        mem_constraint -- memory constraint
        mem_whole_symbol -- z3 memory related symbols
    
    Keyword Arguments:
        sym -- Constraint types] (default: {"lt"})
    """
    if sym == "lt":
        if simplify_c:
            opt.add(simplify(mem_whole_symbol <= mem_constraint))
        else:
            opt.add(mem_whole_symbol <= mem_constraint)
    elif sym == "gt":
        if simplify_c:
            opt.add(simplify(mem_whole_symbol >= mem_constraint))
        else:
            opt.add(mem_whole_symbol >= mem_constraint)
    else:
        if simplify_c:
            opt.add(simplify(mem_whole_symbol == mem_constraint))
        else:
            opt.add(mem_whole_symbol == mem_constraint)
    return


def add_weight_constraint(opt,
                          weight_constraint,
                          weight_whole_symbol,
                          sym="lt",
                          simplify_c=True):
    """
    Construct weight constraint
    
    Arguments:
        opt -- Z3 optimizer
        weight_constraint -- Weight constraint
        weight_whole_symbol -- Z3 weight related symbols
    
    Keyword Arguments:
        sym {str} -- description (default: {"lt"})
    """
    if sym == "lt":
        if simplify_c:
            opt.add(simplify(weight_whole_symbol <= weight_constraint))
        else:
            opt.add(weight_whole_symbol <= weight_constraint)
    elif sym == "gt":
        if simplify_c:
            opt.add(simplify(weight_whole_symbol >= weight_constraint))
        else:
            opt.add(weight_whole_symbol >= weight_constraint)
    else:
        if simplify_c:
            opt.add(simplify(weight_whole_symbol == weight_constraint))
        else:
            opt.add(weight_whole_symbol == weight_constraint)
    return


def add_FLOPs_constraint(opt,
                         FLOPs_constraint,
                         FLOPs_whole_symbol,
                         sym="lt",
                         simplify_c=True):
    """
    Construct FLOPs related constraints
    
    Arguments:
        opt -- Z3 optimizer
        FLOPs_constraint -- FLOPs constraint
        FLOPs_whole_symbol -- Z3 FLOPs symbols
    
    Keyword Arguments:
        sym {str} -- Constraint types (default: {"lt"})
    """
    if sym == "lt":
        if simplify_c:
            opt.add(simplify(FLOPs_whole_symbol <= FLOPs_constraint))
        else:
            opt.add(FLOPs_whole_symbol <= FLOPs_constraint)
    elif sym == "gt":
        if simplify_c:
            opt.add(simplify(FLOPs_whole_symbol >= FLOPs_constraint))
        else:
            opt.add(FLOPs_whole_symbol >= FLOPs_constraint)
    else:
        if simplify_c:
            opt.add(simplify(FLOPs_whole_symbol == FLOPs_constraint))
        else:
            opt.add(FLOPs_whole_symbol == FLOPs_constraint)
    return


def add_edge_constraint(opt,
                        edge_constraint,
                        edge_whole_symbol,
                        sym="lt",
                        simplify_c=True):
    """
    Construct edge number constraint
    
    Arguments:
        opt -- Z3 optimizer
        edge_constraint -- CG edge constraint
        edge_whole_symbol -- CG Edge related symobles
    
    Keyword Arguments:
        sym {str} -- Constraint type (default: {"lt"})
    """
    if sym == "lt":
        if simplify_c:
            opt.add(simplify(edge_whole_symbol <= edge_constraint))
        else:
            opt.add(edge_whole_symbol <= edge_constraint)
    elif sym == "gt":
        if simplify_c:
            opt.add(simplify(edge_whole_symbol >= edge_constraint))
        else:
            opt.add(edge_whole_symbol >= edge_constraint)
    else:
        if simplify_c:
            opt.add(simplify(edge_whole_symbol == edge_constraint))
        else:
            opt.add(edge_whole_symbol == edge_constraint)
    return


def add_arithmetic_intensity_constraint(opt,
                                        ai_constraint,
                                        ai_whole_symbol,
                                        sym="lt",
                                        simplify_c=True):
    """
    Construct arithmetic_intensity related constraints
    
    Arguments:
        opt -- Z3 optimizer
        ai_constraint -- FLOPs constraint
        ai_whole_symbol -- Z3 FLOPs symbols
    
    Keyword Arguments:
        sym {str} -- Constraint types (default: {"lt"})
    """
    if sym == "lt":
        if simplify_c:
            opt.add(simplify(ai_whole_symbol <= ai_constraint))
        else:
            opt.add(ai_whole_symbol <= ai_constraint)
    elif sym == "gt":
        if simplify_c:
            opt.add(simplify(ai_whole_symbol >= ai_constraint))
        else:
            opt.add(ai_whole_symbol >= ai_constraint)
    else:
        if simplify_c:
            opt.add(simplify(ai_whole_symbol == ai_constraint))
        else:
            opt.add(ai_whole_symbol == ai_constraint)
    return


def add_exec_time_constraint(opt,
                             time_constraint,
                             time_whole_symbol,
                             scale_factor,
                             sym="lt",
                             simplify_c=True):
    """
    Construct exec time related constraints
    
    Arguments:
        opt-- Z3 optimizer
        time_constraint -- FLOPs constraint
        time_whole_symbol -- Z3 FLOPs symbols
    
    Keyword Arguments:
        sym {str} -- Constraint types (default: {"lt"})
    """
    if sym == "lt":
        if simplify_c:
            opt.add(
                simplify(time_whole_symbol <= time_constraint * scale_factor))
        else:
            opt.add(time_whole_symbol <= time_constraint * scale_factor)
    elif sym == "gt":
        if simplify_c:
            opt.add(
                simplify(time_whole_symbol >= time_constraint * scale_factor))
        else:
            opt.add(time_whole_symbol >= time_constraint * scale_factor)
    else:
        if simplify_c:
            opt.add(
                simplify(time_whole_symbol == time_constraint * scale_factor))
        else:
            opt.add(time_whole_symbol == time_constraint * scale_factor)
    return

def gen_tensor_datatype_search_space_constraints(op_symbol_dic, \
                                                 layer_spec, \
                                                 search_space, \
                                                 opt, \
                                                 ctx):
    logger.debug("op_symbol_dic {}".format(op_symbol_dic))
    layer = layer_spec.layer_op
    params = layer_spec.params

    logger.debug('datatype in op_symbol_dic')
    
    if refty_use_dataformat_datatype_rule:
        # it contains dependency at 1to1 parents, or will keep solving
        #assert "datatype" in params
        sym_datatype = op_symbol_dic["input_tensor_obj"].data_type

        if "datatype" in params:
            datatype_spec = [params["datatype"]]
            datatype_enum_list = []
            
            for datatype in datatype_spec:
                if datatype in datatype_dic:
                    datatype_enum_list.append(datatype_dic[datatype])
                else:
                    assert False, "the ir value of datatype is not at enumeration domain"
            logger.debug("datatype_enum_list {} sym_datatype {}".format(datatype_enum_list, sym_datatype))

            gen_symbol_constraints(sym_name="datatype",
                                symbol=sym_datatype,
                                spec=datatype_enum_list,
                                layer=layer,
                                search_space=search_space,
                                opt=opt,
                                ctx=ctx)
            op_symbol_dic["contains_datatype_rule"] = True
        else:
            op_symbol_dic["contains_datatype_rule"] = False
    else:
        op_symbol_dic["contains_datatype_rule"] = False
    return

def gen_tensor_dataformat_search_space_constraints(op_symbol_dic, \
                                                   layer_spec, \
                                                   search_space, \
                                                   opt, \
                                                   ctx):
    logger.debug("op_symbol_dic {}".format(op_symbol_dic))
    layer = layer_spec.layer_op
    params = layer_spec.params

    logger.debug('dataformat in op_symbol_dic')
    if refty_use_dataformat_datatype_rule:
        # it contains dependency at 1to1 parents, or will keep solving
        #assert "datatype" in params
        sym_dataformat = op_symbol_dic["input_tensor_obj"].data_format
        if "dataformat" in params:
            dataformat_spec = params["dataformat"]
            dataformat_enum_list = []

            for format in dataformat_spec:
                if format in dataformat_dic:
                    dataformat_enum_list.append(dataformat_dic[format])
                else:
                    assert False, "the ir value of dataformat is not at enumeration domain"
            
            gen_symbol_constraints(sym_name="dataformat",
                                symbol=sym_dataformat,
                                spec=dataformat_enum_list,
                                layer=layer,
                                search_space=search_space,
                                opt=opt,
                                ctx=ctx)
            op_symbol_dic["contains_dataformat_rule"] = True
        else:
            op_symbol_dic["contains_dataformat_rule"] = False
    else:
        op_symbol_dic["contains_dataformat_rule"] = False
    return


def gen_datatype_dependency_constraints(child_op_symbol, parent_op_symbol, opt, ctx):
    child_input_tensor_datatype = child_op_symbol["input_tensor_obj"].data_type
    for parent in parent_op_symbol[0]: # currently not consider nas
        parent_input_tensor_datatype = parent["input_tensor_obj"].data_type
        for i in range(len(parent_input_tensor_datatype)):  
            opt.add(parent_input_tensor_datatype[i] == child_input_tensor_datatype[i])
    return 


def gen_dataformat_dependency_constraints(child_op_symbol, parent_op_symbol, opt, ctx):
    child_input_tensor_dataformat = child_op_symbol["input_tensor_obj"].data_format
    for parent in parent_op_symbol[0]: # currently not consider nas
        parent_input_tensor_dataformat= parent["input_tensor_obj"].data_format
        logger.debug("parent_input_tensor_dataformat {} == child_input_tensor_dataformat {}" \
            .format(parent_input_tensor_dataformat, child_input_tensor_dataformat))
        for i in range(len(parent_input_tensor_dataformat)):
            opt.add(parent_input_tensor_dataformat[i] == child_input_tensor_dataformat[i])
    return