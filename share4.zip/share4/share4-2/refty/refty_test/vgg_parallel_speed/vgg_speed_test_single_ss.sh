
RPATH=.
EXPPATH=refty_test/vgg_parallel_speed
THREAD=10

for THREAD in 12 8 4 1   
do
    TASK=$THREAD
    time python $RPATH/refty/parallel_dist_launcher.py -di 1 -thn $THREAD -nf $EXPPATH/vgg_16.json -ss $EXPPATH/vgg_16_search_space.json -o thread_$THREAD_task_$TASK_diagnosis -tn $TASK 
done

for THREAD in 12 8 4 1   
do
    TASK=$THREAD
    time python $RPATH/refty/parallel_dist_launcher.py -thn $THREAD -nf $EXPPATH/vgg_16.json -ss $EXPPATH/vgg_16_search_space.json -o thread_$THREAD_task_$TASK -tn $TASK 
done


