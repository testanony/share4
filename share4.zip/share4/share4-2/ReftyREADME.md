# Refty Document

## Prerequisites

- Python 3.7.x
- z3-solver (tested with 4.8.7.0)
- pyspark (tested with 2.4.5)

## Installation

Refty can be directly executed through source code

1. Download and install Python 3.7.x [here](https://www.python.org/downloads/).

2. Install z3-solver and pyspark

    a. Run installation cmds:

        $ pip3 install --user z3-solver==4.8.7.0

        $ pip3 install --user pyspark==2.4.5  
         
        $ pip3 install --user click

    b. "--user" will install the package into Python "USER_BASE" directory. You could use "python3 -m site" to find where the directory is.
 
    c. Binaries "z3", "pyspark" are placed in the "bin" subfolder of the Python user base directory. Please make sure that it can be searched in $PATH or %Path% .
    
3. Clone Refty

    ``` $ git clone https://github.com/testanony/share4.git```

## Usage

To run Refty, users need to prepare the DL model/IR file.

#### Individual Mode

Prepare DL model IR JSON and constraint. 

Prepare a file tests/test.py
```python
import sys
sys.path.append('../refty')
import json
from refty.refty import Refty

tiny_net_error = json.loads("""{
                "name": "tiny net",
                "layers": {
                    "data": {
                        "parents": [],
                        "type": "Input",
                        "tensor": [128, 224, 224, 3]
                    },
                    "conv1-1": {
                        "parents": ["data"],
                        "type": "Convolution",
                        "filter": [3000, 3000, 3, 64],
                        "padding": "VALID",
                        "strides": [1, 1, 1, 1],
                        "activation_fn": "relu"
                    }
                }
            }
            """)

tiny_net_correct = json.loads("""{
                "name": "tiny net",
                "layers": {
                    "data": {
                        "parents": [],
                        "type": "Input",
                        "tensor": [128, 224, 224, 3]
                    },
                    "conv1-1": {
                        "parents": ["data"],
                        "type": "Convolution",
                        "filter": [3, 3, 3, 64],
                        "padding": "SAME",
                        "strides": [1, 1, 1, 1],
                        "activation_fn": "relu"
                    }
                }
            }
            """)

search_space = {}
refty = Refty(net=tiny_net_error)
sym_name_dic = refty.warm_up(device_name = "P100", search_space=search_space)
result = refty.interactive_check(device_name = "P100", search_space=search_space, sym_name_dic = sym_name_dic)
```

Then check by Refty individual mode. 

If we want analysis unsat core (config use_unsatcore = True at param.py) and config net with error case, it will show 
below messages: 

```bash
$ python tests/test.py
```

0:data:IN:input:1 represent op_id:op_name:hyperparam_or_tensor_dim:param_dim

```bash
[0:data:IN:input:1 == 224,
 1:data:IN:input:1 == 0:data:IN:input:1,
 1:conv2d:conv1-1:filter:0 == 3000,
 1:data:IN:input:1 >= 1:conv2d:conv1-1:filter:0]
```
This unsat core shows violation of constraints that filter (1:conv2d:conv1-1:filter:0 == 3000) should less than 1:data:IN:input:1 dim (0:data:IN:input:1 == 224) 

Analysis more DL model IR from the DL model file by front-end parser. For example [refty/utils/parse_dl_model_test.py](refty/utils/parse_dl_model_test.py)

Currently, Refty supported IR operators are listed at [ir_op_set.py](refty/refty/utils/ir_op_set.py)


#### Bulk Mode

1. Prepare DL model IR JSON file (e.g. [vgg16.json](nets/vgg16.json)) which contains the computation graph and init hyperparameters. 

```$ model.json```


***NOTE***: We provide a parser for parsing DL model file to the IR JSON file which was built upon MMdnn. 

2. Prepare the search space JSON file (e.g. [vgg16_search_space.json](nets/vgg16_search_space.json)) which contains the hyperparameters options and resource constraints.

```$ search_space.json```

3. Run and prune

For example VGG-16 search space pruning: 
```$ 
mkdir results
mkdir results/vgg16

python3 main.py nets/vgg16.json \ # DL model IR file
    --device_name=TITAN_X \ 
    --output_folder=results/vgg16 \
    --search_space_path=nets//vgg16_search_space.json >> results/vgg16/log
```

Refty will generate results at the folder:

sub_search_space_xx_xx_statistics.txt contains SAT hyperparameter combinations.
```
...
[test z3 solving] *** return the 75 model *** ...
op_id:op_name:hyperparam_or_tensor_dim:param_dim = XX
op_id:op_name:hyperparam_or_tensor_dim:param_dim = XX
...
```

```
global_statistic.txt # Contains search space pruning statistics.
sub_search_space_xx_xx_statistics.txt # Contains satisfied hyperparameters.
log # Contains debugging log.
```

# Experiment 

## RQ1 and RQ2

### concat
- TensorFlow && PyTorch
- Launch scripts: 
   - [refty_data/pythia_bench/gen_real_concat_net.sh](refty_data/pythia_bench/gen_real_concat_net.sh)
- Code file location: 
    - [refty_data/pythia_bench/concat_code_gen.py](refty_data/pythia_bench/concat_code_gen.py)
- Search space configuration location:
    - [refty_data/pythia_bench/concat_code_gen.py](refty_data/pythia_bench/concat_code_gen.py)
- Refty
  - Launch scripts: 
  - Code file location:
  - Search space configuration location:

### AlexNet

- TensorFlow && PyTorch
    - Launch scripts: 
      - [refty_data/pythia_bench/gen_real_alex_net.sh](refty_data/pythia_bench/gen_real_alex_net.sh)
    - Code file location: 
      - [refty_data/pythia_bench/base_code/vgg.py](refty_data/pythia_bench/base_code/vgg.py)
     - Search space configuration location:
      - [refty_data/pythia_bench/alexnet_code_gen.py](refty_data/pythia_bench/alexnet_code_gen.py)
    - Refty
      - Launch scripts: [refty/scripts/check_all_alexnet_err.sh](refty/scripts/check_all_alexnet_err.sh)

## RQ4 Compare with Baseline Pythia

Please refer [refty_data/pythia_bench](refty_data/pythia_bench/README.md)

### Pythia CNN

- Launch scripts: [refty_data/pythia_bench/refty_pythia_compare_bench_gen_test_case.py](refty_data/pythia_bench/refty_pythia_compare_bench_gen_test_case.py)
- Code file location: [refty_data/pythia_bench/refty_pythia_compare_bench_gen_test_case.py](refty_data/pythia_bench/refty_pythia_compare_bench_gen_test_case.py)
- Search space configuration location: [refty_data/pythia_bench/refty_pythia_compare_bench_gen_test_case.py](refty_data/pythia_bench/refty_pythia_compare_bench_gen_test_case.py)

### Refty


- Launch scripts: [../refty/scripts/check_pythia_mnist.sh](../refty/scripts/check_pythia_mnist.sh)

```
cd refty/scripts
./check_pythia_mnist.sh
```

- Code file location: Above section outputs
- Search space configuration location: Above section outputs

