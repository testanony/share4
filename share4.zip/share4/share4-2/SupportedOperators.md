Refty Support Operators

```
["input", "conv2d", "pool2d", "softmax", "innerproduct", "generic_Accuracy", \
"batchnorm2d", "generic_BatchNorm", "dropout", "dropout2d", "concat", \
"reshape", "squeeze", "transpose", "unsqueeze", "matmul", "elu", "hardshrink", \
"hardtanh", "leakyrelu", "logsigmoid", "multiheadattention", "prelu", "relu", \
"relu6", "rrelu", "selu", "celu", "gelu", "sigmoid", "softplus", "softshrink", \
"softsign", "tanh", "tanhshrink", "threshold", "softmin", "softmax", \
"softmax2d", "logsoftmax", "adaptivelogsoftmaxwithloss", "add", "addcdiv", \
"addcmul", "abs", "acos",  "angle", "asin", "atan", "atan2", "bitwise_not", \
"bitwise_xor", "ceil", "clamp", "conj", "cos", "cosh",  "digamma", "erf", \
"erfc", "erfinv", "exp", "expm1", "floor", "fmod", "frac", "imag", "lerp", \
"lgamma", "log", "log10", "log1p" "log2", "logical_not", "logical_xor", \
"mvlgamma", "neg", "polygamma", "pow", "real", "reciprocal", "remainder", \
"round", "rsqrt", "sigmoid", "sign", "sin", "sinh", "sqrt", "tan", "tanh", \
"trunc", "rnn", "lstm", "gru"]
```
